<?php
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('control-panel/layout/header.php');
$footer = inancap('control-panel/layout/footer.php');
$meta = inancap('control-panel/layout/meta.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $meta;?>
    </head>

    <body id="top">
        <?php echo $header;?>

        <main>
            <article id="mainsectionarticle">
                <div id="1SDFG0009IOL">
                    <div class="section product">
                        <div class="container">
                            <div class="product-list">
                                <div class="product-card"><div class="loader card-banner"></div></div>
                                <div class="product-card"><div class="loader card-banner"></div></div>
                                <div class="product-card"><div class="loader card-banner"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </main>
        <?php echo $footer;?>
    </body>
</html>