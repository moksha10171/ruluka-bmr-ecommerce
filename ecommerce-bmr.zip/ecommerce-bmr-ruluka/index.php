<?php
if (strpos($_SERVER['REQUEST_URI'], '.php') !== false || strpos($_SERVER['HTTP_HOST'], 'www.') !== 0) {
    $cleanPath = preg_replace('/\.php(\?.*)?$/', '', $_SERVER['REQUEST_URI']);
    header('Location: https://www.ruluka.com', true, 301);
    exit();
}
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('control-panel/layout/header.php');
$footer = inancap('control-panel/layout/footer.php');
$meta = inancap('control-panel/layout/meta.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $meta; ?>
</head>

<body id="top">
    <?php echo $header; ?>
    <main>
        <article id="mainsectionarticle">
            <div class="bfrntsec">
                <div class="bmr_mainsectl">
                    <div style="display: flex;min-height: 150px;align-items: flex-end;">
                        <div>
                <h1 class="bmr_title">Empowering Home-Grown Fashion Brands</h1>
                <a href="/shop" class="btnd">Shop Now</a>
                </div>
                    </div>
                </div>
            </div>
            <div id="2SDFG0009IOL">
                <div class="section product">
                    <div class="container">
                        <div class="product-list">
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="1SDFG0009IOL">
                <div class="section product">
                    <div class="container">
                        <div class="product-list">
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="5SDFG0009IOL">
                <div class="section product">
                    <div class="container">
                        <div class="product-list">
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                            <div class="product-card">
                                <div class="loader card-banner"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </main>
    <?php echo $footer; ?>
</body>
</html>