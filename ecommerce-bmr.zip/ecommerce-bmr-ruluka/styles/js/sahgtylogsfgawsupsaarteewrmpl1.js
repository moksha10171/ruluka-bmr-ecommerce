$('#showPassword3').click(function() {
        const passwordInput1 = $('#frgtpass_password');
        const passwordInput2 = $('#frgtpass_conform_password');
        const shp = $('#showPassword3');
        if (shp.prop("checked")) {
            passwordInput1.attr('type', 'text');
            passwordInput2.attr('type', 'text');
            shp.prop("checked", true);
        } else {
            passwordInput1.attr('type', 'password');
            passwordInput2.attr('type', 'password');
            shp.prop("checked", false);
        }
    });
$('#passc').css("opacity", '1');
var sdfdssdf = 0, dsdfdssdf = 0;
$('#passc').click(function() {
    if(sdfdssdf == 0){
    sdfdssdf = 1;
    $('#frgt_login_email').prop('disabled', true);
    $('#passc').css("opacity", '0.5');
    $('.errorp1').html('Validating email...');
    const email = $('#frgt_login_email').val().trim();

    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(email)) {
        sdfdssdf = 0;
        $('#passc').css("opacity", '1');
        $('#frgt_login_email').prop('disabled', false);
        $('.errorp1').html('Invalid email address');
        return;
    }
    var formData = new FormData();
    formData.append('email_gh_frgt', email);
    
    $.ajax({
        type: 'POST',
        url: '/control-panel/session/fpasswd',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if(response == 1){
                $('.errorp1').html('Connection Failed. Try again.');   
            } else if(response == 2){
                $('.errorp1').html('Given email is incorrect.');   
            } else if(response == 3){
                $('.errorp1').html('Can\'t validate. Try again.');   
            }  else if(response == 4){
                $('.errorp1').html('Email is not registered.');   
            } else {
                if(response == 'success') {
                    $('.errorp1').html('Check Your email for otp');
                    $('#frgtpass_otp').val('');
                    $('#frgtpass_password').val('');
                    $('#frgtpass_conform_password').val('');
                    $('#reset_form').hide();
                    $('#get_change_form').show();
                    $('#frgt_login_email').hide();
                    countdownInterval_fgt = setInterval(updateCountdownfgt, 1000);
                } else {
                    $('.errorp1').html('Can\'t validate. Try again.');
                }
            }
            sdfdssdf = 0;
            $('#frgt_login_email').prop('disabled', false);
            $('#passc').css("opacity", '1');
        },
        error: function() {
            sdfdssdf = 0;
            $('#frgt_login_email').prop('disabled', false);
            $('#passc').css("opacity", '1');
            $('.errorp1').html('Can\'t validate now. Try again Later.');
        }
    });
    } else {
        $('.errorp1').html('Please be patient. Validating email.');  
    }
});
    var countdown_fgt = 60, countdownInterval_fgt;
    function updateCountdownfgt() {
      $("#countdown_fgt").html("Resend in "+countdown_fgt);
      if (countdown_fgt === 0) {
        clearInterval(countdownInterval_fgt);
        $("#countdown_fgt").html('<u>Resend Again</u>')
      } else {
        countdown_fgt--;
      }
    }
    $("#fgt_time_b").click(function(event) {
        if(countdown_fgt==0){
            $('#passc').click();
            $('#countdown_fgt').html('<u>Resending OTP...</u>');  
            countdown_fgt = 60;
        }
    });
     $("#pass_c_f").click(function() {
        if(dsdfdssdf == 0){
              dsdfdssdf = 1;
        $('#pass_c_f').css("opacity", '0.5');
        
        const otp = $('#frgtpass_otp').val();
        const password = $('#frgtpass_password').val();
        const Cpassword = $('#frgtpass_conform_password').val();
        var regex = /^\d{6}$/;
        if (!regex.test(otp)) {
            dsdfdssdf = 0;
                $('#pass_c_f').css("opacity", '1');
                $('.errorp1').html('The otp should be in 6 digits.');
                return;
        }
         const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (!passwordRegex.test(password) || !passwordRegex.test(Cpassword)) {
            dsdfdssdf = 0;
            $('#pass_c_f').css("opacity", '1');
            $('.errorp1').html('Passwords must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character');
            return;
        }
        
        if(password != Cpassword){
            dsdfdssdf = 0;
            $('#pass_c_f').css("opacity", '1');
            $('.errorp1').html('Passwords doesn\'t match');
            return;
        }
        var formData1 = new FormData();
        formData1.append('sadsadawewwdcassdsd', otp);
        formData1.append('thjshanertyeasadsa', password);

        $.ajax({
            type: 'POST',
            url: '/control-panel/session/frgt_passwd_reg_eval',
            data: formData1,
            processData: false,
            contentType: false,
            success: function(res) {
                dsdfdssdf = 0;
                $('#pass_c_f').css("opacity", '1');
                if(res == 1){
                    $('.errorsup1').html('Connection Failed. Try again.');   
                } else if(res == 2){
                    $('.errorp1').html('Given otp is incorrect.');   
                } else if(res == 3){
                    $('#get_change_form').hide();
                    $('#reset_form').show();
                    $('#frgt_login_email').show();
                    $('.errorp1').html('Validation failed. Try again');
                } else if(res == 4){
                    $('.errorp1').html('Given Input fields are invalid.');   
                }  else if(res == 5){
                    $('#get_change_form').hide();
                    $('#reset_form').show();
                     $('#frgt_login_email').show();
                    $('.errorp1').html('Password Has been updated. Login in');   
                }  else if(res == 6){
                    $('#get_change_form').hide();
                    $('#reset_form').show();
                     $('#frgt_login_email').show();
                    $('.errorp1').html('Validation failed. Try again');   
                } else {
                    if(res == 'success'){
                        $('.errorp1').html('Password Updated Successfully.');
                        var newUrl = '/profile/';
                        window.location.href = newUrl;
                    } else {
                        $('.errorp1').html('Can\'t update right now. Try again.');
                    }
                }
            },
            error: function() {
                dsdfdssdf = 0;
                $('#pass_c_f').css("opacity", '1');
                $('.errorp1').html('An error occurred. Try again Later.');
            }
        });
     }
    });
  var lsdfdssdf = 0;
 $('#logc').css("opacity", '1');
$('#logc').click(function() {
    if(lsdfdssdf == 0){
        lsdfdssdf = 1;
    $('#logc').css("opacity", '0.5');
    $('#error').html('Logging in...');
    const email = $('#login_email').val().trim();
    const password = $('#login_password').val().trim();

    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(email)) {
         lsdfdssdf = 0;
        $('#logc').css("opacity", '1');
        $('#error').html('Invalid email address');
        return;
    }

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
        lsdfdssdf = 0;
        $('#logc').css("opacity", '1');
        $('#error').html('Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character');
        return;
    }
    var formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);

    $.ajax({
        type: 'POST',
        url: '/control-panel/session/login',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            lsdfdssdf = 0;
            $('#logc').css("opacity", '1');
            if(response == 1){
                $('#error').html('Connection Failed. Try again.');   
            } else if(response == 2){
                $('#error').html('Given credentials are incorrect.');   
            } else if(response == 3) {
                $('#error').html('Can\'t login. Try again Later.');   
            } else if(response == 4) {
                $('#error').html('Sign up to gain access.');   
            } else {
                if(response == 'success') {
                    $('#error').html('Sign up Successful');
                    var newUrl = '/profile/';
                    window.location.href = newUrl;
                } else {
                    $('#error').html('Can\'t login. Try again Later.');
                }
            }
        },
        error: function() {
            lsdfdssdf = 0;
            $('#logc').css("opacity", '1');
            $('#error').html('An error occurred. Try again Later.');
        }
    });
    } else {
        $('#error').html('Please be patient. Logging in.');  
    }
});
  $('#showPassword').click(function() {
        const passwordInput = $('#login_password');
        const shp = $('#showPassword');
        const currentType = passwordInput.attr('type');
        if (shp.prop("checked")) {
            passwordInput.attr('type', 'text');
            shp.prop("checked", true);
        } else {
            passwordInput.attr('type', 'password');
            shp.prop("checked", false);
        }
    });
    var suosdfdssdf = 0;
    var suosdfdssdf1 = 0;
    $('#logc1').click(function() {
        if(suosdfdssdf == 0){
            suosdfdssdf = 1;
        $('#logc1').css("opacity", '0.5');
        $('.errorsup1').html('Processing...');
        const email = $('#signup_email').val();
        const password = $('#signup_password').val();
        if (email == "" || password == "") {
              suosdfdssdf = 0;
             $('#logc1').css("opacity", '1');
            $('.errorsup1').html('No field should be empty.');
            return;
        }
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!emailRegex.test(email)) {
            suosdfdssdf = 0;
             $('#logc1').css("opacity", '1');
            $('.errorsup1').html('Invalid email address');
            return;
        }

        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (!passwordRegex.test(password)) {
            suosdfdssdf = 0;
             $('#logc1').css("opacity", '1');
            $('.errorsup1').html('Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character');
            return;
        }
     var formData = new FormData();
        formData.append('password_ijj', password);
        formData.append('email_gh', email);

        $.ajax({
            type: 'POST',
            url: '/control-panel/session/reg_verify',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                suosdfdssdf = 0;
                $('#logc1').css("opacity", '1');
                if(response == 1){
                 $('.errorsup1').html('Connection Failed. Try again.');   
                } else if(response == 3){
                    $('.errorsup1').html('Can\'t validate. Try again.');   
                } else if(response == 5){
                    $('.errorsup1').html('No Field should be empty.');   
                } else if(response == 6){
                    $('.errorsup1').html('Given Fields are not in correct format.');   
                }  else if(response == 8){
                    $('.errorsup1').html('This email is already Regstered.');
                } else {
                    if(response == 'success') {
                        $('.errorsup1').html('Check Your email for otp'); 
                        $('#log__c1').css("display", "none");
                        $('#otp_html').css("display", "block");
                        countdownInterval = setInterval(updateCountdown, 1000);
                    } else {
                        $('.errorsup1').html('Can\'t validate. Try again.');   
                    }
                }
            },
            error: function() {
                suosdfdssdf = 0;
                 $('#logc1').css("opacity", '1');
                $('.errorsup1').html('An error occurred. Try again Later.');
            }
        });
        } else {
            $('.errorsup1').html('Please be patient. Logging in.');  
        }
    });
    $('#showPassword1').click(function() {
        const passwordInput = $('#signup_password');
        const shp = $('#showPassword1');
        const currentType = passwordInput.attr('type');
        if (shp.prop("checked")) {
            passwordInput.attr('type', 'text');
            shp.prop("checked", true);
        } else {
            passwordInput.attr('type', 'password');
            shp.prop("checked", false);
        }
    });
    var countdown = 60;
    var countdownInterval;

    function updateCountdown() {
      $("#countdown").html("Resend in "+countdown);
      if (countdown === 0) {
        clearInterval(countdownInterval);
        $("#countdown").html('<u>Resend Again</u>')
      } else {
        countdown--;
      }
    }
    $("#time_b").click(function(event) {
        if(countdown==0){
            $('#logc1').click();
            $('#countdown').html('<u>Resending OTP...</u>');  
            countdown = 60;
        }
    });
    
    $("#logo_1").click(function() {
          if(suosdfdssdf1 == 0){
              suosdfdssdf1 =1;
        $('#logo_1').css("opacity", '0.5');
        
        const otp = $('#signup_otp').val();
        var regex = /^\d{6}$/;
        if (!regex.test(otp)) {
            suosdfdssdf1 =0;
                $('#logo_1').css("opacity", '1');
                $('.errorsup1').html('The otp should be in 6 digits.');
                return;
        }
        var formData1 = new FormData();
        formData1.append('sssadsadawewwdcassdsd', otp);

        $.ajax({
            type: 'POST',
            url: '/control-panel/session/reg_eval',
            data: formData1,
            processData: false,
            contentType: false,
            success: function(res) {
                suosdfdssdf1 =0;
                $('#logo_1').css("opacity", '1');
                if(res == 1){
                 $('.errorsup1').html('Connection Failed. Try again.');   
                } else if(res == 2){
                    $('.errorsup1').html('Given otp is incorrect.');   
                } else if(res == 3){
                    $('.errorsup1').html('Can\'t validate try again.');   
                } else if(res == 4){
                    $('.errorsup1').html('Can\'t Verify. Try again.');   
                } else if(res == 5){
                    $('.errorsup1').html('Email is not valid. Try again.');   
                } else if(res == 9){
                    $('.errorsup1').html('This email is already Regstered.');   
                } else if(res == 7){
                    $('.errorsup1').html('Can\'t Sign up. Try Sigining in again.');   
                } else {
                    if(res == 'success'){
                        $('.errorsup1').html('Verification Successfull. Redirecting...');
                        var newUrl = '/profile/';
                        window.location.href = newUrl;
                    } else {
                        $('.errorsup1').html('Can\'t Verify. Try again.');
                    }
                }
            },
            error: function() {
                suosdfdssdf1 = 0;
                $('#logo_1').css("opacity", '1');
                $('.errorsup1').html('An error occurred. Try again Later.');
            }
        });
          } else {
              $('.errorsup1').html('Please be patient. Logging in.');  
          }
    });