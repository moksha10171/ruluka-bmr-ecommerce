$(document).ready(function() {
    var currentURL = window.location.href;
    var fl = '';
    var baseURL = "https://www.ruluka.com/";
    currentURL = currentURL.replace(/\/+$/, "");
    var urlWithoutParams = currentURL.split(/[?#]/)[0];
    var currentFilename = urlWithoutParams.split('/').pop();

    if (currentFilename ===  'www.ruluka.com' || currentFilename ===  'ruluka.com') {
        fl = 'home';
        xhrRequest("/control-panel/product/list1", function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });

        xhrRequest("/control-panel/product/list2", function(response) {
            $('#2SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });

        xhrRequest("/control-panel/product/creator", function(response) {
            $('#4SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });

        xhrRequest("/control-panel/product/flc", function(response) {
            $('#5SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

    if (currentFilename === 'shop') {
        fl = 'shop';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

    if (currentFilename === 'about-us') {
        fl = 'about-us';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

    if (currentFilename === 'favourites') {
        fl = 'favourites';
        xhrRequest("/control-panel/product/favourites", function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

    if (currentFilename === 'cart') {
        fl = 'favourites';
        var myData = "CDBFAVLCLB=" + localStorage.getItem('CDBFAVLCLB');
        xhrRequestd("/control-panel/product/cart", myData, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

    if (currentFilename === "influencers") {
        fl = 'creator';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename === "seller") {
        fl = 'seller';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename === "men") {
        fl = 'men';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename === "women") {
        fl = 'women';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename === "collections") {
        fl = 'flc';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename === "studio") {
        fl = 'studio';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }
    if (currentFilename !== "studio") {
     var currentURL = window.location.href;
currentURL = currentURL.replace(/\/+$/, "");
var urlWithoutParams = currentURL.split(/[?#]/)[0];
var parsedUrl = new URL(currentURL);

if (parsedUrl.pathname.startsWith('/influencers/')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var fl = 'products';
    var currentURL = window.location.href;
    var parsedSearchUrl = new URL(currentURL);
    if (parsedSearchUrl.searchParams.has('id') && parsedSearchUrl.searchParams.get('id') === 'posts') {
        fl = 'influencers';
    } else {
        urlWithoutParams = currentURL.split(/[?#]/)[0];
    }

    var myData = "creator=" + basePath;
    xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
}
}

     var currentURL = window.location.href;
currentURL = currentURL.replace(/\/+$/, "");
var urlWithoutParams = currentURL.split(/[?#]/)[0];
var parsedUrl = new URL(currentURL);

if(parsedUrl.pathname.startsWith('/seller/')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var fl = 'seller_items';
    var myData = "creator=" + basePath;
    xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
}
if(parsedUrl.pathname.startsWith('/seller/')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var fl = 'seller_items';
    var myData = "creator=" + basePath;
    xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
}
if(parsedUrl.pathname.startsWith('/brands/')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var fl = 'brand_items';
    var myData = "creator=" + basePath;
    xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
}

if(parsedUrl.pathname.startsWith('/blog')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var fl = 'blog_b_bmr';
    xhrRequest("/control-panel/product/" + fl, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
}

        if (currentFilename === "brands") {
        fl = 'brands';
        xhrRequest("/control-panel/product/" + fl, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
            brwsrdimns();
        });
    }

urlWithoutParams = urlWithoutParams.replace(/\/+$/, "");
 var currentFilename1 = urlWithoutParams.split('/').pop();
    if (currentFilename1 == "products") {
     var currentURL = window.location.href;
currentURL = currentURL.replace(/\/+$/, "");
var urlWithoutParams = currentURL.split(/[?#]/)[0];
var parsedUrl = new URL(currentURL);

if (parsedUrl.pathname.startsWith('/products/')) {
    var basePath = parsedUrl.pathname.split('/').pop();
    basePath = basePath.replace(/\.[^/.]+$/, '');
    var currentURL = window.location.href;
    var parsedSearchUrl = new URL(currentURL);
    if (parsedSearchUrl.searchParams.has('id')) {
        var fl = 'items';
        var idValue = getParameterByName('id');
            var myData = "postid=" + idValue;
    xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
        $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        brwsrdimns();
    });
    }

}
}
brwsrdimns();
});
 function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

function CSTORINSNETW(num) {
    if (isFinite(num) && num != '') {
         var currentURL = window.location.href;
         currentURL = currentURL.replace(/\/+$/, "");
         var currentFilename = currentURL.split('/').pop();
        $('#C' + num).toggleClass("active");
        var action = $('#C' + num).hasClass("active") ? 'yes' : 'no';
        if(action == 'yes'){
            $('#IC' + num).text('Added to Cart');
        }else {
            $('#IC' + num).text('Add to Cart');
        }
        if (currentFilename === 'cart') {
            removeElementWithEffect('#IC' + num);
        }
        $.ajax({
            type: "POST",
            url: "/control-panel/store/cart",
            data: { action: action, value: num },
            success: function(response) {
                if (isFinite(response)) {
                    $("#cart_val_").attr('value',response);
                    $("#cart_val_").text(response);
                    if(response == 0){
                        $("#cart_val_").css('display','none');
                    } else {
                        $("#cart_val_").css('display','grid');
                    }
                }
            }
        });
    }
}
function FSTORINSNETW(num) {
    if (isFinite(num) && num != '') {
        var currentURL = window.location.href;
         currentURL = currentURL.replace(/\/+$/, "");
         var currentFilename = currentURL.split('/').pop();
        $('#F' + num).toggleClass("active");
        var action = $('#F' + num).hasClass("active") ? 'yes' : 'no';
        if(action == 'yes'){
            $('#IF' + num).text('Added to favorites');
        }else {
            $('#IF' + num).text('Add to favorites');
        }
        if (currentFilename === 'favourites') {
            removeElementWithEffect('#RMVIC' + num);
        }
        $.ajax({
            type: "POST",
            url: "/control-panel/store/favori",
            data: { action: action, value: num },
            success: function(response) {
                if (isFinite(response)) {
                    $("#favr_val_").attr('value',response);
                    $("#favr_val_").text(response);
                    if(response == 0){
                        $("#favr_val_").css('display','none');
                    } else {
                        $("#favr_val_").css('display','grid');
                    }
                }
            }
        });
    } 
}
function FOLLINFLUENCLISTRA(num){
    if (num != '') {
        $('.FLOW' + num).toggleClass("active");
        var action = $('.FLOW' + num).hasClass("active") ? 'yes' : 'no';
        if(action == 'yes'){
            $('.FLOW' + num).text('Following');
        }else {
            $('.FLOW' + num).text('Follow');
        }
        $.ajax({
            type: "POST",
            url: "/control-panel/store/followers",
            data: { action: action, value: num },
            success: function(response) {
                if (isFinite(response)) {
                    $("#follwr_cc").text(response+' Followers');
                }
            }
        });
    }
}

function LIKEINFLUENCLISTRA(num){
    if (num != '') {
        $('#LIKE' + num).toggleClass("active");
        var action = $('#LIKE' + num).hasClass("active") ? 'yes' : 'no';
        $.ajax({
            type: "POST",
            url: "/control-panel/store/likes",
            data: { action: action, value: num },
            success: function(response) {
                if (isFinite(response)) {
                    $('#CLIKE' + num).text(response+' Likes');
                }
            }
        });
    }
}
 
function BOOKINFLUENCLISTRA(num){
    if (num != '') {
        $('#BOOK' + num).toggleClass("active");
        var action = $('#BOOK' + num).hasClass("active") ? 'yes' : 'no';
        $.ajax({
            type: "POST",
            url: "/control-panel/store/bookmarks",
            data: { action: action, value: num },
            success: function(response) {
            }
        });
    }
}
function postsfetch(){
    var currentURL = window.location.href;
    currentURL = currentURL.replace(/\/+$/, "");
    var currentFilename = currentURL.split('/').pop();
    var urlWithoutParams = currentURL.split(/[?#]/)[0];
    var parsedUrl = new URL(urlWithoutParams);
    $('#infpostsec').addClass('active');
    $('#infprodsec').removeClass('active');
    if (parsedUrl.pathname.startsWith('/influencers/')) {
         var basePath = parsedUrl.pathname.split('/').pop();
        basePath = basePath.replace(/\.[^/.]+$/, '');
        fl = 'influencers';
        var myData = "creator=" + basePath;
        xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        });
        var newUrl = urlWithoutParams + '?id=posts';
        history.replaceState({}, document.title, newUrl);
    }
}
function productsfetch(){
    var currentURL = window.location.href;
    currentURL = currentURL.replace(/\/+$/, "");
    var currentFilename = currentURL.split('/').pop();
    var urlWithoutParams = currentURL.split(/[?#]/)[0];
    var parsedUrl = new URL(urlWithoutParams);
    $('#infpostsec').removeClass('active');
    $('#infprodsec').addClass('active');
    if (parsedUrl.pathname.startsWith('/influencers/')) {
         var basePath = parsedUrl.pathname.split('/').pop();
        basePath = basePath.replace(/\.[^/.]+$/, '');
        fl = 'products';
        var myData = "creator=" + basePath;
        xhrRequestd("/control-panel/product/"+ fl, myData, function(response) {
            $('#1SDFG0009IOL').html(response !== null && response !== "" && response !== "400" ? response : 'Error Occurred. Please try again.');
        });
    }
}
function shareLink(titl, txt, urls, shimg) {
    if (navigator.share) {
        navigator.share({
            title: titl,
            text: txt,
            url: urls
        })
        .then(() => console.log())
        .catch((error) => console.error());
    }
}
function removeElementWithEffect(element) {
        var currentURL = window.location.href;
         currentURL = currentURL.replace(/\/+$/, "");
         var currentFilename = currentURL.split('/').pop();
    if (currentFilename === 'favourites') {
         var productCardCount = $('.product-list').children('.product-card').length;
         
        $(element).css('opacity', '0');
        setTimeout(function() {
            $(element).remove();
        }, 500);
        if(productCardCount-1 == 0){
            $('#1SDFG0009IOL').html(`<section class="section product">
                        <div class="container" id="MAINSECHEI">
                            <h2 class="h2 section-title" style="display:flex;align-tems:center;justify-content:center;">
                                <ion-icon name="heart-outline" class="h1" style="border-radius: 50%;border: var(--border-black);padding: 5px;" aria-hidden="true"></ion-icon>
                            </h2>
                            <h2 class="h2 section-title">FAVOURITES</h2>
                            <h4 class="h4 section-title">Items added to your favourites will be saved here.
                                We’ll send you a reminder when a campaign in your favourites is about to end.</h4>
                                 <div class="prdt_active_bo"><a href="https://blog.bmreducation.com/shop" class="btn btn-primary"> SHOP NOW</a></div>
                        </div>
                    </section>`);
         }
    }
}