    const overlay = $("[data-overlay]");
    const navOpenBtn = $("[data-nav-open-btn]");
    const navbar = $("[data-navbar]");
    const navCloseBtn = $("[data-nav-close-btn]");

    const navElems = [overlay, navOpenBtn, navCloseBtn];

    for (let i = 0; i < navElems.length; i++) {
        navElems[i].on("click", function() {
            navbar.toggleClass("active");
            overlay.toggleClass("active");
        });
    }

    const header = $("[data-header]");
    const goTopBtn = $("[data-go-top]");

    $(window).scroll(function() {
        if ($(window).scrollTop() >= 80) {
            header.addClass("active");
            goTopBtn.addClass("active");
        } else {
            header.removeClass("active");
            goTopBtn.removeClass("active");
        }
    });

    const logsec = $('#SECBLOGINSNETW');
    const signupsec = $('#LOGINSEC');
    const signupregistersec = $('#SIGNUPSEC');
    const frgtpsw = $('#FRGTINSNETW');

    function BLOGINSNETW() {
        if (logsec.css('display') === 'none' || logsec.css('display') === '') {
            logsec.css('display', 'block');
        } else if (logsec.css('display') === 'block') {
            logsec.css('display', 'none');
        }
    }

    function FRGTINSNETW() {
        logsec.css('display', 'block');
        if (signupsec.css('display') === 'none') {
            signupsec.css('display', 'block');
            frgtpsw.css('display', 'none');
        } else if (signupsec.css('display') === 'block' || signupsec.css('display') === '') {
            signupsec.css('display', 'none');
            frgtpsw.css('display', 'block');
        }
    }

    function SIGNUPPAGE() {
        logsec.css('display', 'block');
        if (signupsec.css('display') === 'none') {
            signupsec.css('display', 'block');
            signupregistersec.css('display', 'none');
        } else if (signupsec.css('display') === 'block' || signupsec.css('display') === '') {
            signupsec.css('display', 'none');
            signupregistersec.css('display', 'block');
        }
    }

    function toggleSearch() {
           $("#mensectionbtn").removeClass("rotate");
    $("#mensectiontop").slideUp().promise().done(() => {
         $("#womensectionbtn").removeClass("rotate");
    $("#womensectiontop").slideUp().promise().done(() => {
        $("#search").toggleClass("rotate");
        $("#search").slideToggle();
    });
    });
        
    }