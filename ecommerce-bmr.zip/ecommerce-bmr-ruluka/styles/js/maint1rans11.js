function sremoveHashAndParams() {
    var url = window.location.href;
    if (url.includes('#')) {
        url = url.split('#')[0];
    }
    if (url.includes('?')) {
        url = url.split('?')[0];
    }
    history.replaceState({}, document.title, url);
}

function dimension() {
    var browserHeight = $(window).height(), browserWidth = $(window).width();
    $("#srhheight").height(browserHeight - 160);
    $("#srhheightmtmp").height(browserHeight - 90);
}

$(document).ready(function() {
    dimension();
});

$(window).on('resize', function() {
    dimension();
});

function xhrRequest(url, callback) {
    $.ajax({
        url: url,
        type: "POST",
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            callback(response);
        },
        error: function() {
            callback(null);
        }
    });
}
function xhrRequestd(url, data, callback) {
    $.ajax({
        url: url,
        type: "POST",
        data: data,
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            callback(response);
        },
        error: function() {
            callback(null);
        }
    });
}

if(localStorage.getItem('DBFAVLCLB') === null) {
    localStorage.setItem('DBFAVLCLB', '');
}
if(localStorage.getItem('CDBFAVLCLB') === null) {
    localStorage.setItem('CDBFAVLCLB', '');
}
var retrievedValue = localStorage.getItem('myKey');

function fhcfile(fl) {
    var currentURL = window.location.href;
    var baseURL = "https://www.ruluka.com/";
    currentURL = currentURL.replace(/\/+$/, "");
    var currentFilename = currentURL.split('/').pop();
    var title = "";

    if (currentFilename === fl) {
        return;
    }
    if (currentFilename + '/home' === '/' + fl) {
        return;
    }
    if (currentURL.includes("/")) {
        currentURL = baseURL + fl;
    } else {
        currentURL = baseURL + fl;
    }

    var getd = $('#mainsectionarticle');
    if (fl === "home") {
        currentURL = baseURL;
        getd.html(`<section class="section hero SDFDRUADS" style="background-image: url('https://img.freepik.com/free-photo/shirt-mockup-concept-with-plain-clothing_23-2149448749.jpg?size=626&ext=jpg')">
        <div class="container">

          <h2 class="h1 hero-title">
            <strong>RULUKA</strong>
          </h2>

          <p class="h3 hero-title">
               Empowering Home-Grown Fashion Brands
          </p>
          <br>
          <a href="/shop" style="width:fit-content;" class="btn btn-primary">
            <span>Shop Now</span>
            <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
          </a>

        </div>
      </section>
 <div id="2SDFG0009IOL">
      <div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div>
 </div>
 <div id="1SDFG0009IOL"><div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div></div>
 <div id="4SDFG0009IOL"><div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader r card-banner"></div></div><div class="product-card"><div class="loader r card-banner"></div></div><div class="product-card"><div class="loader r card-banner"></div></div></div></div></div></div>
 <div id="5SDFG0009IOL"><div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div></div>`);
        
        xhrRequest("/control-panel/product/list1", function(response) {
            var S1SDFG0009IOL = $('#1SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                S1SDFG0009IOL.html(response);
            } else {
                S1SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });

        xhrRequest("/control-panel/product/list2", function(response) {
            var S2SDFG0009IOL = $('#2SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                S2SDFG0009IOL.html(response);
            } else {
                S2SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });

        xhrRequest("/control-panel/product/creator", function(response) {
            var S4SDFG0009IOL = $('#4SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                S4SDFG0009IOL.html(response);
            } else {
                S4SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });

        xhrRequest("/control-panel/product/flc", function(response) {
            var S5SDFG0009IOL = $('#5SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                S5SDFG0009IOL.html(response);
            } else {
                S5SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });

        title = "RULUKA - Empowering Home-Grown Fashion Brands";
    }

    if (fl === "shop" || fl === "about-us") {
        if (fl === "shop") {
            title = "SHOP | RULUKA";
        } else {
            title = "ABOUT US | RULUKA";
        }

        getd.html('<div id="1SDFG0009IOL"><div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div></div>');

        xhrRequest("/control-panel/product/" + fl, function(response) {
            var SDFG0009IOL = $('#1SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                SDFG0009IOL.html(response);
            } else {
                SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });
    }

    if (fl === "favourites" || fl === "cart" || fl === "creators") {
        if (fl === "favourites") {
            title = "FAVOURITES | RULUKA";
        } else if (fl === "cart") {
            title = "CART | RULUKA";
        } else {
            title = "CREATORS | RULUKA";
        }

        getd.html('<div id="1SDFG0009IOL"><div class="section product"><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div></div>');

        var myData = "";
        if (fl === "favourites") {
            myData = "DBFAVLCLB=" + localStorage.getItem('DBFAVLCLB');
        } else if (fl === "cart") {
            myData = "CDBFAVLCLB=" + localStorage.getItem('CDBFAVLCLB');
        }

        xhrRequestd("/control-panel/product/" + fl, myData, function(response) {
            var SDFG0009IOL = $('#1SDFG0009IOL');
            if (response !== null && response !== "" && response !== "400") {
                SDFG0009IOL.html(response);
            } else {
                SDFG0009IOL.html('Error Occurred. Please try again.');
            }
        });
    }

    document.title = title;
    history.replaceState({}, title, currentURL);
}

$(window).on('popstate', function(event) {
    var currentURL = window.location.href;
    var baseURL = "https://blog.bmreducation.com/";
    currentURL = currentURL.replace(/\/+$/, "");
    var currentFilename = currentURL.split('/').pop();

    if (event.state) {
        document.title = event.state.title;
        window.history.replaceState(event.state, event.state.title, event.state.url);
    }

    if (currentFilename == '') {
        fhcfile('about-us');
        fhcfile('home');
    } else if (currentFilename == 'shop') {
        fhcfile('about-us');
        fhcfile('shop');
    } else if (currentFilename === 'about-us') {
        fhcfile('shop');
        fhcfile('about-us');
    }
});
var OLPBOG = "";
function GFD009W(n) {
    $("#3SDFG0009IOL").hide();
    $("#1SDFG0009IOLOAD").show();
    $("#1SDFG0009IOLOAD").html('<div><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div>');
    
    if (n == 1) {
        OLPBOG = "all";
        $("#sec1").addClass('active');
        $("#sec2, #sec3").removeClass('active');
    } else if (n == 2) {
        OLPBOG = "men";
        $("#sec2").addClass('active');
        $("#sec1, #sec3").removeClass('active');
    } else if (n == 3) {
        OLPBOG = "women";
        $("#sec3").addClass('active');
        $("#sec1, #sec2").removeClass('active');
    }
    
    if (n >= 1 && n <= 3) {
        $.ajax({
            url: "/control-panel/product/" + OLPBOG,
            type: "POST",
            contentType: "application/x-www-form-urlencoded",
            success: function(response) {
                if (response == 400 || response == "") {
                    $("#3SDFG0009IOL").html('Error Occurred. Please try again');
                } else {
                    $("#3SDFG0009IOL").html(response);
                }
                $("#1SDFG0009IOLOAD").hide();
                $("#3SDFG0009IOL").show();
            },
            error: function() {
                $("#3SDFG0009IOL").html('Error Occurred. Please try again');
                $("#1SDFG0009IOLOAD").hide();
                $("#3SDFG0009IOL").show();
            }
        });
    }
}

function SRHS00340() {
    var value = $("#ONINPUTSRH").val();
    $("#SRHSDFG0009IOL").hide();
    $("#SRHSDFG0009IOLOAD").show();
    $("#SRHSDFG0009IOLOAD").html('<div><div class="container"><div class="product-list"><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div><div class="product-card"><div class="loader card-banner"></div></div></div></div></div>');
    
    var formData = new FormData();
    formData.append('search', value);
    
    $.ajax({
        url: "/control-panel/product/search",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
            $("#SRHSDFG0009IOLOAD").hide();
            $("#SRHSDFG0009IOL").show();
            if (response == 400 || response == "") {
                $("#SRHSDFG0009IOL").html('Error Occurred. Please try again.');
            } else if (response == 314) {
                $("#SRHSDFG0009IOL").html('No results available');
            } else {
                $("#SRHSDFG0009IOL").html(response);
            }
        },
        error: function() {
            $("#SRHSDFG0009IOLOAD").hide();
            $("#SRHSDFG0009IOL").show();
            $("#SRHSDFG0009IOL").html('Error Occurred. Please try again.');
        }
    });
}    