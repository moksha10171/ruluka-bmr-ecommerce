<?php
session_start();
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('../control-panel/layout/header.php');
$footer = inancap('../control-panel/layout/footer.php');
$meta = inancap('../control-panel/layout/meta.php');
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $stmt11 = $conn->prepare("SELECT * FROM live_session_access WHERE eml_usr_f_ = ?");
                $stmt11->bind_param("s", $row['eml_usr_f_']);
                $stmt11->execute();
                $result1r = $stmt11->get_result();
                
                    $content= '<article>
                <section class="section product">
                <ul class="filter-list">
                    <li>
              <a class="filter-btn" href="/profile/" style="background: var(--smoky-white);">Dashboard</a>
            </li>

            <li>
              <a class="filter-btn" href="/profile/orders" style="background: var(--smoky-white);">Orders</a>
            </li>

            <li>
              <a class="filter-btn" href="/profile/address" style="background: var(--smoky-white);">Addresses</a>
            </li>
            <li>
              <a class="filter-btn" href="/profile/payments" style="background: var(--smoky-white);">Payments</a>
            </li>
            <li>
              <a class="filter-btn active" href="/profile/account" style="background: var(--smoky-white);">Account</a>
            </li>
            <li>
              <a href="/profile/logout" style="background: var(--smoky-white);" class="filter-btn">Logout</a>
            </li>
          </ul>
            <div class="container" id="articles">
                <h2 class="h2 section-title">ACCOUNT</h2>
                <div class="prf_sec">
                        <div class="prf_sec_tm">
                            <h3 class="h3 navbar-link">Account Details</h3>
                            <div style="margin-left:auto;"><div class="navbar-link" style="margin-left:auto;">Edit</div></div>
                        </div>
                    <div style="padding: 10px;">
                    <div class="prdo_drid navbar-link" style="gap: 10px;">
                        <div><b>User name:</b> '.$row1['disp_name_slk_dispn__'].'</div>
                        <div><b>Full Name:</b> '.$row1['name_slk_f__'].' '.$row1['last_slk_s__'].'</div>
                        <div><b>Email:</b> '.$row1['mail_id_slk'].'</div>
                        <div><b>Registered On:</b> '.$row1['Registered_on'].'</div>
                        <div><b>Total Orders:</b> '.$row1['total_ordrs'].'</div>
                        <div><b>Billing Details:</b> '.$row1['bill_addr_slk'].'</div>
                        <div><b>Shipping Details:</b> '.$row1['shipp_addr_slk'].'</div>
                        <div><b>Payment Details:</b> '.$row1['payment_details'].'</div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="prf_sec">
                        <div class="prf_sec_tm">
                            <h3 class="h3 navbar-link">Login Access</h3>
                            <div style="margin-left:auto;"><div class="navbar-link" style="margin-left:auto;" onclick="CURRNTSECBLOGINSNETW()">Change Password</div></div>
                        </div>
                    <div style="padding: 10px;">
                    <div class="prdo_drid navbar-link" style="gap: 10px;">
                        <div><b>Login Method:</b> Manual Sign in</div>
                        <div><b>Active Devices:</b> '.$result1r->num_rows.'</div>
                        <div><b>Last Password Change:</b> '.$row1['last_modif_date'].'</div>
                    </div>
                    </div>
                </div>
            </div>
        </section>
    </article>';
    
                } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
            } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
        } else {
                    header('Location: https://www.ruluka.com/profile/logout');
        }
        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $meta;?>
    </head>
    <body id="top">
        <?php echo $header;?>
        <style>
            footer{
                    display: none;
            }
        </style>
        <main>
            <?php echo $content;?>
        <div id="CURRNTSECBLOGINSNETW" style="display:none;">
            <div class="logincontainer">
                <div class="loginsection">
                    <div class="FLXRIGHT">
                        <ion-icon name="close-outline" onclick="CURRNTSECBLOGINSNETW()" class="h1"></ion-icon>
                    </div>
                <section class="section product">
                <div class="container">
                 <h2 class="h2 section-title">CHANGE PASSWORD</h2>
                  <div class="product-card" tabindex="0">
                     <div class="card-content">
                      <div id="CHANGPASS" class="newsletter-form">
                      <input type="password" name="Current Password" required placeholder="Current Password" id="currnt_acc_prfl__password" class="newsletter-input">
                      <br><br>
                      <input type="password" name="password" required placeholder="New Password" id="chage_to_new_password" class="newsletter-input">
                      <br><br>
                       <input type="password" name="password" required placeholder="Conform New Password" id="confirm_chage_to_new_password" class="newsletter-input">
                      <br><br>
                      <div class="">
                          <input type="checkbox" style="width:auto" name="showPasswordcurntfl" id="showPasswordcurntfl"> Check Password
                      </div>
                      <br>
                    </div>
                    <div id="error_change_pass"></div>
                    <br>
                    <div class="FLXRIGHT">
                        <button id="update_cpass" class="btn btn-primary">UPDATE</button>
                    </div>
                </div>
                </div>
            </div>
            </div>
            </div>
            </div>
        </main>
        <script>
            $('#showPasswordcurntfl').click(function() {
                const passwordInput1 = $('#currnt_acc_prfl__password');
                const passwordInput2 = $('#chage_to_new_password');
                const passwordInput3 = $('#confirm_chage_to_new_password');
                const shp = $('#showPasswordcurntfl');
                if (shp.prop("checked")) {
                    passwordInput1.attr('type', 'text');
                    passwordInput2.attr('type', 'text');
                    passwordInput3.attr('type', 'text');
                    shp.prop("checked", true);
                } else {
                    passwordInput1.attr('type', 'password');
                    passwordInput2.attr('type', 'password');
                    passwordInput3.attr('type', 'password');
                    shp.prop("checked", false);
                }
            });
    const changepasssec = $('#CURRNTSECBLOGINSNETW');

    function CURRNTSECBLOGINSNETW() {
        if (changepasssec.css('display') === 'none' || changepasssec.css('display') === '') {
            $('#CHANGPASS, #currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password, #update_cpass').show();
            changepasssec.css('display', 'block');
        } else if (changepasssec.css('display') === 'block') {
            changepasssec.css('display', 'none');
        }
    }
$('#update_cpass').css("opacity", '1');
var chpprsdfdssdf = 0;
$('#update_cpass').click(function() {
    if(chpprsdfdssdf == 0){
    chpprsdfdssdf = 1;
    $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', true);
    $('#update_cpass').css("opacity", '0.5');
    $('#error_change_pass').html('Validating email...');
    const oldpass = $('#currnt_acc_prfl__password').val().trim();
    const newpass = $('#chage_to_new_password').val().trim();
    const confirmnewpass = $('#confirm_chage_to_new_password').val().trim();
    
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (!passwordRegex.test(newpass) || !passwordRegex.test(confirmnewpass)) {
            chpprsdfdssdf = 0;
            $('#update_cpass').css("opacity", '1');
            $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', false);
            $('#error_change_pass').html('Passwords must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character');
            return;
        }
        
        if(newpass != confirmnewpass){
            chpprsdfdssdf = 0;
            $('#update_cpass').css("opacity", '1');
            $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', false);
            $('#error_change_pass').html('Passwords doesn\'t match');
            return;
        }
        if(newpass == oldpass){
            chpprsdfdssdf = 0;
            $('#update_cpass').css("opacity", '1');
            $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', false);
            $('#error_change_pass').html('Old Password and new Password should\'t match');
            return;
        }
    var formData = new FormData();
    formData.append('newthjsnsaergjeaasdwsa', oldpass);
    formData.append('ssoolsdfaskenrewerer', newpass);
    
    $.ajax({
        type: 'POST',
        url: '/control-panel/session/frgt_pssw_prf_lnk',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if(response == 1){
                $('#error_change_pass').html('Connection Failed. Try again.');   
            } else if(response == 2){
                $('#error_change_pass').html('Can\'t Verify the password.');   
            } else if(response == 3){
                $('#error_change_pass').html('Can\'t validate. Try again1.');   
            }  else if(response == 4){
                $('#error_change_pass').html('Invalid.');   
            } else {
                if(response == 'success') {
                    $('#error_change_pass').html('Successfully changed');
                    $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').val('');
                    $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password, #update_cpass, #CHANGPASS').hide();
                } else {
                    $('#error_change_pass').html('Can\'t validate. Try again2.'+response);
                }
            }
            chpprsdfdssdf = 0;
            $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', false);
            $('#update_cpass').css("opacity", '1');
        },
        error: function() {
            chpprsdfdssdf = 0;
            $('#currnt_acc_prfl__password, #chage_to_new_password, #confirm_chage_to_new_password').prop('disabled', false);
            $('#update_cpass').css("opacity", '1');
            $('#error_change_pass').html('Can\'t validate now. Try again Later.');
        }
    });
    } else {
        $('#error_change_pass').html('Please be patient. Validating email.');  
    }
});
        </script>
        <?php echo $footer;?>
    </body>
</html>