<?php
session_start();
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('../control-panel/layout/header.php');
$footer = inancap('../control-panel/layout/footer.php');
$meta = inancap('../control-panel/layout/meta.php');
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $email = $row['eml_usr_f_'];
                    if($row1['bill_addr_slk']=='no'){
                        $usr_bill_addr = 'No billing Address Available';
                    } else {
                        $stmt1bd = $conn->prepare("SELECT * FROM billing_address__f__ WHERE mail_id_slk = ?");
                        $stmt1bd->bind_param("s", $row['eml_usr_f_']);
                        $stmt1bd->execute();
                        $result1bd = $stmt1bd->get_result();
                        if ($result1bd->num_rows > 0) {
                         $row1bd = $result1bd->fetch_assoc();
                         if($row1bd['company_name'] != ''){
                             $cnop = $row1bd['company_name'].'<br><br>';
                         } else {
                              $cnop = '';
                         }
                         $fid = 'value="'.$row1bd['first_name_slk__'].'"';
                         $lid = 'value="'.$row1bd['last_name_slk'].'"';
                         $cno = 'value="'.$row1bd['company_name'].'"';
                         $cid = 'value="'.$row1bd['country__f_'].'"';
                         $staddr = 'value="'.$row1bd['street_address_'].'"';
                         $twnc = 'value="'.$row1bd['town__city__'].'"';
                         $pinc = 'value="'.$row1bd['pin_code'].'"';
                         $steid = 'value="'.$row1bd['state'].'"';
                         $phnid = 'value="'.$row1bd['phone__number__'].'"';
                         $usr_bill_addr = '<p>'.$cnop.''.$row1bd['first_name_slk__'].' '.$row1bd['last_name_slk'].'<br><br>'.$row1bd['street_address_'].'<br><br>'.$row1bd['town__city__'].' '.$row1bd['pin_code'].'<br><br>'.$row1bd['state'].'</p>';
                        } else {
                        $usr_bill_addr = 'No billing Address Available';
                        }
                    }
                    if($row1['shipp_addr_slk']=='no'){
                        $usr_ship_addr = 'No shipping Address Available';
                    } else {
                        $stmt1bd = $conn->prepare("SELECT * FROM shipping__address__f__ WHERE mail_id_slk = ?");
                        $stmt1bd->bind_param("s", $row['eml_usr_f_']);
                        $stmt1bd->execute();
                        $result1bd = $stmt1bd->get_result();
                        if ($result1bd->num_rows > 0) {
                         $row1bd = $result1bd->fetch_assoc();
                         if($row1bd['company_name'] != ''){
                             $cnop = $row1bd['company_name'].'<br><br>';
                         } else {
                              $cnop = '';
                         }
                         $fid1 = 'value="'.$row1bd['first_name_slk__'].'"';
                         $lid1 = 'value="'.$row1bd['last_name_slk'].'"';
                         $cno1 = 'value="'.$row1bd['company_name'].'"';
                         $cid1 = 'value="'.$row1bd['country__f_'].'"';
                         $staddr1 = 'value="'.$row1bd['street_address_'].'"';
                         $twnc1 = 'value="'.$row1bd['town__city__'].'"';
                         $pinc1 = 'value="'.$row1bd['pin_code'].'"';
                         $steid1 = 'value="'.$row1bd['state'].'"';
                         $usr_ship_addr = '<p>'.$cnop.''.$row1bd['first_name_slk__'].' '.$row1bd['last_name_slk'].'<br><br>'.$row1bd['street_address_'].'<br><br>'.$row1bd['town__city__'].' '.$row1bd['pin_code'].'<br><br>'.$row1bd['state'].'</p>';
                        } else {
                        $usr_ship_addr = 'No shipping Address Available';
                        }
                    }
                    $content= '<article>
                <section class="section product">
                <ul class="filter-list">
                    <li>
              <a class="filter-btn" href="/profile/" style="background: var(--smoky-white);">Dashboard</a>
            </li>

            <li>
              <a class="filter-btn" href="/profile/orders" style="background: var(--smoky-white);">Orders</a>
            </li>

            <li>
              <a class="filter-btn active" href="/profile/address" style="background: var(--smoky-white);">Addresses</a>
            </li>
            <li>
              <a class="filter-btn" href="/profile/payments" style="background: var(--smoky-white);">Payments</a>
            </li>
            <li>
              <a class="filter-btn" href="/profile/account" style="background: var(--smoky-white);">Account</a>
            </li>
            <li>
              <a href="/profile/logout" style="background: var(--smoky-white);" class="filter-btn">Logout</a>
            </li>
          </ul>
            <div class="container" id="articles">
                <h2 class="h2 section-title">ADDRESSES</h2>
                <div class="prf_sec">
                        <div class="prf_sec_tm">
                            <h3 class="h3 navbar-link">Billing Details</h3>
                            <div style="margin-left:auto;"><div class="navbar-link" style="margin-left:auto;" onclick="CURRNTSECBLOGINSNETW()">Edit</div></div>
                        </div>
                    <div class="prf_sec_body">
                        '.$usr_bill_addr.'
                    </div>
                </div>
                <br>
                 <div class="prf_sec">
                        <div class="prf_sec_tm">
                            <h3 class="h3 navbar-link">Shipping Details</h3>
                            <div style="margin-left:auto;"><div class="navbar-link" style="margin-left:auto;" onclick="CURRNTSECBLOGINSNETW1()">Edit</div></div>
                        </div>
                    <div class="prf_sec_body">
                        '.$usr_ship_addr.'
                    </div>
                </div>
            </div>
        </section>
    </article>';
    
                } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
            } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
        } else {
                    header('Location: https://www.ruluka.com/profile/logout');
        }
        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $meta;?>
        <style>
            footer{
                    display: none;
            }
        </style>
    </head>
    <body id="top">
        <?php echo $header;?>

        <main>
            <?php echo $content;?>
            <div id="CURRNTSECBLOGINSNETW" style="display:none;">
            <div class="logincontainer" style="padding: 10px;">
                <div class="loginsection" style="width: 100%;">
                    <div class="FLXRIGHT">
                        <ion-icon name="close-outline" onclick="CURRNTSECBLOGINSNETW()" class="h1"></ion-icon>
                    </div>
                <section class="section product">
                <div class="container">
                 <h2 class="h2 section-title">BILLING ADDRESS</h2>
                  <div class="product-card" tabindex="0">
                     <div class="card-content">
                      <div class="newsletter-form" id="BILLADDR" style="max-height: 400px;overflow-y: scroll;">
                      <input type="text" name="First Name" required <?php echo $fid;?> placeholder="First Name" id="first_name_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Last Name" required <?php echo $lid;?> placeholder="Last Name" id="last_name_id__" class="newsletter-input">
                      <br><br>
                       <input type="text" name="Company name (optional)" <?php echo $cno;?> placeholder="Company name (optional)" id="comapany_name_optional" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Country" required placeholder="Country" <?php echo $cid;?> id="country_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Street Address" required placeholder="Street Address" <?php echo $staddr;?>  id="street_addr_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Town/City" required placeholder="Town/City" <?php echo $twnc;?>  id="town_city_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="State" required placeholder="State" id="state_id__" <?php echo $steid;?>  class="newsletter-input">
                      <br><br>
                      <input type="text" name="pin code" required placeholder="PIN Code" <?php echo $pinc;?> id="pin_code_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Phone" required placeholder="Phone" id="phone_id__" <?php echo $phnid;?>  class="newsletter-input">
                      <br><br>
                      <input type="email" name="Email address" readonly value="<?php echo $email;?>" disabled placeholder="Email address" id="email_id__" class="newsletter-input">
                      <br><br>
                    </div>
                    <div id="error_change_pass"></div>
                    <br>
                    <div class="FLXRIGHT">
                        <button id="update_cpass" class="btn btn-primary">UPDATE</button>
                    </div>
                </div>
                </div>
            </div>
            </div>
            </div>
            </div>
            <div id="CURRNTSECBLOGINSNETW1" style="display:none;">
            <div class="logincontainer" style="padding: 10px;">
                <div class="loginsection" style="width: 100%;">
                    <div class="FLXRIGHT">
                        <ion-icon name="close-outline" onclick="CURRNTSECBLOGINSNETW1()" class="h1"></ion-icon>
                    </div>
                <section class="section product">
                <div class="container">
                 <h2 class="h2 section-title">SHIPPING ADDRESS</h2>
                  <div class="product-card" tabindex="0">
                     <div class="card-content">
                      <div class="newsletter-form" id="SHIPADDR" style="max-height: 400px;overflow-y: scroll;">
                      <input type="text" name="First Name" required <?php echo $fid1;?> placeholder="First Name" id="1first_name_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Last Name" required <?php echo $lid1;?> placeholder="Last Name" id="1last_name_id__" class="newsletter-input">
                      <br><br>
                       <input type="text" name="Company name (optional)" <?php echo $cno1;?> placeholder="Company name (optional)" id="1comapany_name_optional" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Country" required placeholder="Country" <?php echo $cid1;?> id="1country_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Street Address" required placeholder="Street Address" <?php echo $staddr1;?> id="1street_addr_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="Town/City" required placeholder="Town/City" <?php echo $twnc1;?> id="1town_city_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="State" required placeholder="State" <?php echo $steid1;?> id="1state_id__" class="newsletter-input">
                      <br><br>
                      <input type="text" name="pin code" required placeholder="PIN Code" <?php echo $pinc1;?> id="1pin_code_id__" class="newsletter-input">
                    </div>
                    <div id="error_change_pass1"></div>
                    <br>
                    <div class="FLXRIGHT">
                        <button id="update_cpass1" class="btn btn-primary">UPDATE</button>
                    </div>
                </div>
                </div>
            </div>
            </div>
            </div>
            </div>
        </main>
        <?php echo $footer;?>
    </body>
    <script>
    const changepasssec = $('#CURRNTSECBLOGINSNETW');

    function CURRNTSECBLOGINSNETW() {
        if (changepasssec.css('display') === 'none' || changepasssec.css('display') === '') {
            $('#BILLADDR').show();
            $('#error_change_pass').html('');
            $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__').prop('disabled', false).show();
            $('#update_cpass').show();
            changepasssec.css('display', 'block');
        } else if (changepasssec.css('display') === 'block') {
            changepasssec.css('display', 'none');
        }
    }
$('#update_cpass').css("opacity", '1');
var chpprsdfdssdf = 0;
$('#update_cpass').click(function() {
    if(chpprsdfdssdf == 0){
    chpprsdfdssdf = 1;
    $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__').prop('disabled', true);
    $('#update_cpass').css("opacity", '0.5');
    $('#error_change_pass').html('Validating email...');
        if ($('#first_name_id__').val() == '' || $('#last_name_id__').val() == ''|| $('#country_id__').val() == ''|| $('#street_addr_id__').val() == ''|| $('#town_city_id__').val() == ''|| $('#state_id__').val() == ''|| $('#pin_code_id__').val() == ''|| $('#phone_id__').val() == '') {
            chpprsdfdssdf = 0;
            $('#update_cpass').css("opacity", '1');
            $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__').prop('disabled', false);
            $('#error_change_pass').html('Please fill all the required fields');
            return;
        }
        
    var formData = new FormData();
    formData.append('input1val', $('#first_name_id__').val() );
    formData.append('input2val', $('#last_name_id__').val() );
    formData.append('input3val', $('#comapany_name_optional').val() );
    formData.append('input4val', $('#country_id__').val() );
    formData.append('input5val', $('#street_addr_id__').val() );
    formData.append('input6val', $('#town_city_id__').val() );
    formData.append('input7val', $('#state_id__').val() );
    formData.append('input8val', $('#pin_code_id__').val() );
    formData.append('input9val', $('#phone_id__').val() );
    
    $.ajax({
        type: 'POST',
        url: '/control-panel/session/details_billing_c',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if(response == 1){
                $('#error_change_pass').html('Connection Failed. Try again.');   
            } else if(response == 2){
                $('#error_change_pass').html('Can\'t Verify the details.');   
            } else if(response == 3){
                $('#error_change_pass').html('Can\'t validate. Try again.');   
            }  else if(response == 4){
                $('#error_change_pass').html('Invalid.');   
            } else {
                if(response == 'success') {
                    $('#error_change_pass').html('Successfully changed');
                    $('#BILLADDR').hide();
                    $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__,#email_id__').prop('disabled', false).hide();
                    $('#update_cpass').hide();
                } else {
                    $('#error_change_pass').html('Can\'t validate. Try again.'+response);
                }
            }
            chpprsdfdssdf = 0;
            $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__').prop('disabled', false);
            $('#update_cpass').css("opacity", '1');
        },
        error: function() {
            chpprsdfdssdf = 0;
            $('#first_name_id__,#last_name_id__,#comapany_name_optional,#country_id__,#street_addr_id__,#town_city_id__,#state_id__,#pin_code_id__,#phone_id__').prop('disabled', false);
            $('#update_cpass').css("opacity", '1');
            $('#error_change_pass').html('Can\'t validate now. Try again Later.');
        }
    });
    } else {
        $('#error_change_pass').html('Please be patient. Validating session.');  
    }
});

 const changepasssec1 = $('#CURRNTSECBLOGINSNETW1');

    function CURRNTSECBLOGINSNETW1() {
        if (changepasssec1.css('display') === 'none' || changepasssec1.css('display') === '') {
                $("#SHIPADDR").show();
                $('#error_change_pass1').html('');
                $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', false).show();
            $('#update_cpass1').show();
            changepasssec1.css('display', 'block');
        } else if (changepasssec1.css('display') === 'block') {
            changepasssec1.css('display', 'none');
        }
    }
$('#update_cpass1').css("opacity", '1');
var chpprsdfdssdf1 = 0;
$('#update_cpass1').click(function() {
    if(chpprsdfdssdf1 == 0){
        const input11 = $('#1first_name_id__');
                const input21 = $('#1last_name_id__');
                const input31 = $('#1comapany_name_optional');
                const input41 = $('#1country_id__');
                const input51 = $('#1street_addr_id__');
                const input61 = $('#1town_city_id__');
                const input71 = $('#1state_id__');
                const input81 = $('#1pin_code_id__');
    chpprsdfdssdf1 = 1;
    $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', true);
    $('#update_cpass1').css("opacity", '0.5');
    $('#error_change_pass1').html('Validating email...');
        if (input11.val() == '' || input21.val() == ''|| input41.val() == ''|| input51.val() == ''|| input61.val() == ''|| input71.val() == ''|| input81.val() == '') {
            chpprsdfdssdf1 = 0;
            $('#update_cpass1').css("opacity", '1');
            $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', false);
            $('#error_change_pass1').html('Please fill all the required fields');
            return;
        }
        
    var formData = new FormData();
    formData.append('input1val', $('#1first_name_id__').val() );
    formData.append('input2val', $('#1last_name_id__').val() );
    formData.append('input3val', $('#1comapany_name_optional').val() );
    formData.append('input4val', $('#1country_id__').val() );
    formData.append('input5val', $('#1street_addr_id__').val() );
    formData.append('input6val', $('#1town_city_id__').val() );
    formData.append('input7val', $('#1state_id__').val() );
    formData.append('input8val', $('#1pin_code_id__').val() );
    
    $.ajax({
        type: 'POST',
        url: '/control-panel/session/shipping_billing_c',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if(response == 1){
                $('#error_change_pass1').html('Connection Failed. Try again.');   
            } else if(response == 2){
                $('#error_change_pass1').html('Can\'t Verify the details.');   
            } else if(response == 3){
                $('#error_change_pass1').html('Can\'t validate. Try again.');   
            }  else if(response == 4){
                $('#error_change_pass1').html('Invalid.');   
            } else {
                if(response == 'success') {
                    $('#error_change_pass1').html('Successfully changed');
                    $("#SHIPADDR").hide();
                    $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', false).hide();
                    $('#update_cpass1').hide();
                } else {
                    $('#error_change_pass1').html('Can\'t validate. Try again.'+response);
                }
            }
            chpprsdfdssdf1 = 0;
            $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', false);
            $('#update_cpass1').css("opacity", '1');
        },
        error: function() {
            chpprsdfdssdf1 = 0;
            $('#1first_name_id__,#1last_name_id__,#1comapany_name_optional,#1country_id__,#1street_addr_id__,#1town_city_id__,#1state_id__,#1pin_code_id__').prop('disabled', false);
            $('#update_cpass1').css("opacity", '1');
            $('#error_change_pass1').html('Can\'t validate now. Try again Later.');
        }
    });
    } else {
        $('#error_change_pass1').html('Please be patient. Validating session.');  
    }
});
        </script>
</html>