<?php
session_start();
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('../control-panel/layout/header.php');
$footer = inancap('../control-panel/layout/footer.php');
$meta = inancap('../control-panel/layout/meta.php');
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("DELETE FROM live_session_access WHERE sess__id__bycpt = ?");
                $stmt1->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
                $stmt1->execute();
                if ($stmt1->affected_rows > 0) {
                   $_SESSION['sessss_id_sec_newt_k_sa_sa'] = '';
                   session_destroy();
                   header('Location: https://www.ruluka.com/');
                } else {
                    $conn->close();
                    $_SESSION['sessss_id_sec_newt_k_sa_sa'] = '';
                    session_destroy();
                    header('Location: https://www.ruluka.com/');
                }
            } else {
                $conn->close();
                $_SESSION['sessss_id_sec_newt_k_sa_sa'] = '';
                session_destroy();
                header('Location: https://www.ruluka.com/');
                }
        } else {
            $conn->close();
            $_SESSION['sessss_id_sec_newt_k_sa_sa'] = '';
            session_destroy();
            header('Location: https://www.ruluka.com/');
        }
        $conn->close();
    }
?>