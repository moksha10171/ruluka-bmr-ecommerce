<?php
session_start();
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('../control-panel/layout/header.php');
$footer = inancap('../control-panel/layout/footer.php');
$meta = inancap('../control-panel/layout/meta.php');
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    if($row1['total_ordrs']==0){
                        $accc_ord_sta = 'No orders Available';
                    }
                    $content= '<article>
                <section class="section product">
                <ul class="filter-list">
                    <li>
              <a class="filter-btn" href="/profile/" style="background: var(--smoky-white);">Dashboard</a>
            </li>

            <li>
              <a class="filter-btn active" href="/profile/orders" style="background: var(--smoky-white);">Orders</a>
            </li>

            <li>
              <a class="filter-btn" href="/profile/address" style="background: var(--smoky-white);">Addresses</a>
            </li>
            <li>
              <a class="filter-btn" href="/profile/payments" style="background: var(--smoky-white);">Payments</a>
            </li>
            <li>
              <a class="filter-btn" href="/profile/account" style="background: var(--smoky-white);">Account</a>
            </li>
            <li>
              <a href="/profile/logout" style="background: var(--smoky-white);" class="filter-btn">Logout</a>
            </li>
          </ul>
            <div class="container" id="articles">
                <h2 class="h2 section-title">MY ORDERS</h2>
                <div class="prf_sec">
                        <div class="prf_sec_tm">
                            <h3 class="h3 navbar-link">Recent Orders</h3>
                            <div style="margin-left:auto;"><a href="https://www.ruluka.com/shop" class="navbar-link" style="margin-left:auto;">Shop</a></div>
                        </div>
                    <div class="prf_sec_body">
                        '.$accc_ord_sta.'
                    </div>
                </div>
            </div>
        </section>
    </article>';
    
                } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
            } else {
                    header('Location: https://www.ruluka.com/profile/logout');
                }
        } else {
                    header('Location: https://www.ruluka.com/profile/logout');
        }
        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $meta;?>
        <style>
            footer{
                    display: none;
            }
        </style>
    </head>
    <body id="top">
        <?php echo $header;?>

        <main>
            <?php echo $content;?>
        </main>
        <?php echo $footer;?>
    </body>
</html>