<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
$mysqli = new mysqli("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
if ($mysqli->connect_errno) {
    $x = 'RULUKU';
} else {
    $cleanPath = $mysqli->real_escape_string(preg_replace('/\.php(\?.*)?$/', '', $_SERVER['REQUEST_URI']));
    $query = "SELECT * FROM page_details_session WHERE page_url = '{$cleanPath}'";
    $result = $mysqli->query($query);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $title = htmlentities($row['title'], ENT_QUOTES, 'UTF-8');
        $about = htmlentities($row['about'], ENT_QUOTES, 'UTF-8');
        $image = htmlentities($row['page_image'], ENT_QUOTES, 'UTF-8');
        $x = "";
    } else {
        $x = 'RULUKU';
    }
    $mysqli->close();
}
$titleToShow = ($title != "") ? $title : $x;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titleToShow; ?></title>
    <link rel="shortcut icon" href="/lr.png" type="image/svg+xml">
    <style>
    #changeword,
.btn,
.button,
.bword,
footer,
nav,
tr:nth-child(2n) {
    background-color: var(--col3);
}
.btn,
.prebook-btn,
label {
    font-weight: var(--fw-600);
}

.btn,
.carousel-dot,
.clrbtn,
a,
ion-icon {
    cursor: pointer;
}
.btn,
.button,
.container,
.prebook-btn {
    color: var(--col5);
}
* {
    font-family: var(--ff-monospace);
    font-style: normal;
}
footer,
header,
nav {
    width: 100%;
}
footer {
    border-top: 1px solid;
    margin-top: 40px;
}
header,
nav {
    top: 0;
    position: fixed;
}
nav {
    z-index: 1002;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    transform: translateX(-100%);
    transition: transform 0.4s;
    left: 0;
    max-width: 300px;
    height: 100%;
}
nav img{
    opacity:1 !important;
    transform: translateY(0) scale(1) rotate(0) !important;
}
.prebook-btn,
footer,
header {
    z-index: 1000;
}
header .container{
    background-color:white;
}
.open {
    transform: translateX(0);
}
#mensectiontop img,#womensectiontop img,
.prds img {
    width: 100% !important;
}
.contactgrid div,
.bfrntsec h1,
.secdivh,
td,
th,
tr {
    text-align: center;
}
:root {
    --col1: #f2f2f2;
    --col2: #ededed;
    --col3: #ffffff;
    --col4: #fafafa;
    --col5: black;
    --fw-300: 300;
    --fw-500: 500;
    --fw-600: 600;
    --fw-700: 700;
    --ff-monospace: monospace;
}
img {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    pointer-events: none;
}
.imgblg{
    position: relative;
    max-height: 350px;
    overflow: hidden;
    border-radius: 10px;
    cursor:pointer;
}
.getblginfo h4{
    font-weight:100;
}
.imgblg img{
        border-radius: 10px;
}
.imgblg:hover img{
    transform:scale(1.05);
    transition: var(--transition-1);
}
.getblginfo{
    position: absolute;
    width: 100%;
    bottom: 0;
    left: 0px;
    padding: 10px;
    min-height: 75px;
    color: white;
    background: linear-gradient(to bottom, #00000010, #3e3d3d);
    border-radius: 10px;
}
.getblginfo a{
    text-decoration:none;
}
.getblginfo a:hover{
    text-decoration:underline;
}
body {
    font-family: var(--ff-monospace);
    background-color: var(--col3);
    padding: 0;
    margin: 0;
}
h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: var(--ff-monospace);
}
a,
li,
ol,
p,
span {
    font-family: var(--ff-monospace);
}
.gridsecf div,.fcgrid div{
    width:fit-content;
}
main a,
main li,
main ol,
main p,
main span {
    font-family: var(--ff-monospace) !important;
}
.fa {
    font-size: var(--fs-5);
}
.btn,
.prebook-btn {
    text-decoration: none;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    font-size: var(--fs-9);
}
.clrbtn {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
#sideclose {
    width: 100%;
    height: 100%;
    z-index: 1001;
    position: fixed;
    display: none;
    transition: background-color 0.4s;
    background-color: #00000070;
}
.container h2 {
    margin-top: 0;
}
.container img{
    width: 100%;
}
.bmr_imgtop_drpd{
    text-align: center;
    overflow: hidden;
}

footer .gridsecf {
    display: grid;
    grid-auto-columns: 1fr;
}
.gridsecf div {
    padding: 5px;
}
.footerc,
.bmr_top_nav {
    background-color: var(--col3);
    padding: 15px 30px;
    display: grid;
    gap: 15px;
    grid-template-columns: 1fr auto 1fr;
}
.contactgrid,
.footerc {
    grid-template-columns: 1fr 1fr 1fr;
}
#offersec{
    padding: 5px;
    width: 100%;
    color: var(--col3);
    background-color: #000;
    text-align: center;
    font-size: var(--fs-7);
}
.imgsec,
nav,
nav .secnav div,
td,
th,
tr {
    padding: 10px;
}
nav a{
    width:fit-content !important;
}
#mensectiontop,
#womensectiontop,
#womensectionnav,
#mensectionnav,
.fa-bars,
nav {
    display: none;
}
nav img {
    width: 100% !important;
    margin-bottom: 20px;
}
.productgrid,
nav .secnav {
    display: grid;
}
footer .links {
    display: flex;
    gap: 10px;
}
header .logo {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
}

.flex2cntg{
    display: flex;
    align-items: center;
    justify-content: center;
    gap:10px;
}
header h1{
    margin: 0;
}
.imgsec img,
form,
label {
    width: 100%;
}
#navl,
.logo a {
    border-bottom: none !important;
}
#navl {
    width: 75%;
}
products{
    
   display: block;
}
subscribe{
   padding:30px; 
   display: block;
}
category{
    display: block;
}
.subscribef{
    display: flex;
    align-items: center;
    justify-content: center;
}
.subscribef .subform{
    text-align: center;
}
.copyright{
    padding: 5px;
    color: var(--col3);
    background-color: #000;
    text-align: center;
    font-size: var(--fs-7);
}
.bmr_h_category{
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    padding: 20px;
}
.bmr_disprdts{
    display: flex;
    overflow: scroll;
    gap: 10px;
    padding-top: 20px;
}
.bmr_category_prds{
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 10px;
    padding-top: 20px;
}
.bmr_m_prds{
    max-width: 300px;
    min-width: 200px;
    width: 100%;
    max-height: 450px;
    height: 100%;
    position: relative;
    background-color: var(--col1);
}
.bmr_m_prds .fa-heart{
    margin: 5px;
    padding: 5px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    font-size: var(--fs-10);
    right: 0;
    background-color: var(--col1);
    border-radius: 50%;
    border: 1px solid;
}
.bmr_m_prds .fa-heart:hover{
    color:white;
    background-color: black;
}
.bmr_category_prds .bmr_m_prds{
    max-width: 100%;
}
.bmr_category_prds .bmr_imgcont_sec{
    max-height: 100%;
}
.bmr_title{
    text-align: center;
}
.bmr_linksec .btn{
    padding: 12px 14px;
}
.bmr_linksec .alink{
    color: white !important;
}
.bmr_linksec .alink:hover{
    border-bottom: 2px solid white;
}
.bmr_linksec{
    position: absolute;
    bottom: 0;
    margin: 20px;
}
.bmr_linksec h2{
 color: white;

}
.bmr_imgcont_sec{
    width: 100%;
    height: 100%;
    max-height: 350px;
    overflow: hidden;
}
.grid_blg{
    display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px;
}
.bmr_imgcont_sec img{
    width: 100%;
}
.bmr_info_sec{
    min-height: 75px;
    height: 100%;
}
.bmr_info_sec .hd{
    font-weight: var(--fw-600);
    font-size: var(--fs-7);
}
.bmr_info_sec .hd,.bmr_info_sec p{ 
    margin: 10px;
    display: block;
}
.bmr_h_category div{
    cursor: pointer;
    font-size: var(--fs-8);
    border-bottom: 2px solid transparent;
}
.bmr_h_category div.active{
    border-bottom: 2px solid;
}
.bmr_h_category div:hover{
    border-bottom: 2px solid;
}
.timesx {
    margin-left: auto;
    padding: 0 !important;
    position: absolute;
    right: 15px;
    top: 15px;
}
header img {
    width: 160px;
}
header .links {
    display: flex;
    align-items: center;
    gap: 10px;
}
.alink,
footer a,
header a,
nav a {
    font-size: inherit;
    text-decoration: none;
    cursor: pointer;
    color: var(--col5);
    border-bottom: 2px solid transparent;
}
.active,
.alink:hover,
footer a:hover,
header a:hover,
nav a:hover {
    border-bottom: 2px solid var(--col5);
}
.pre-booking form {
    display: grid;
    grid-template-columns: 1fr;
}
.pre-booking form div {
    display: flex;
}
label {
    margin: 20px 0;
    display: block;
    font-size: var(--fs-7);
}
input,
select {
    width: 100%;
    padding: 15px;
    border-radius: 24px;
    border: 1px solid #000;
}
header .right {
    display: flex;
    align-items: center;
    justify-content: right;
    gap: 15px;
}
.links.right a{
    border-bottom:0px solid !important;
}
#mensectiontop .container, #womensectiontop .container {
    padding: 50px;
    display: grid;
    grid-template-columns: 1fr 2fr;
    gap: 10px;
}
#mensectiontop .gridsection .linksecp,#womensectiontop .gridsection .linksecp {
    padding: 15px;
    display: block;
}
.gridsection a{
    width:fit-content;
}
.rotate i {
    transform: rotate(180deg);
}
.section {
    padding: 10px 20px;
}
.clrbtn {
    height: 25px;
    width: 25px;
    border-radius: 5px;
}
.blue {
    background-color: #00f;
}
.clrbtn.blue:hover {
    box-shadow: 0 0 1px 1px #00f;
}
.red {
    background-color: red;
}
.clrbtn.red:hover {
    box-shadow: 0 0 1px 1px red;
}
.gold {
    background-color: gold;
}
.clrbtn.gold:hover {
    box-shadow: 0 0 1px 1px gold;
}
.black,
.carousel-dot.active {
    background-color: #000;
}

.aboutus h2{
    margin:0;
    text-align: left;
}
.ulcl{
    list-style-type: none;
    padding-left: 20px;
}
.ulcl li{
    margin-block: 15px;
}
.aboutus,
.carousel-dot,
.carousel-slide,
.prebook-btn {
    background-color: var(--col1);
}
.clrbtn.black:hover {
    box-shadow: 0 0 1px 1px #000;
}
.contactgrid {
    display: grid;
}
.contactgrid .fa {
    font-size: xxx-large;
}
.bfrntsec.gg{
    background-image: url('/images/pexels-vlada-karpovich-4050334.jpg') !important;
}
.bfrntsec {
    background-image: url('/images/fashionable-pale-brunette-long-green-dress-black-jacket-sunglasses-standing-street-daytime-against-wall-light-city-building.jpg');
    background-size: cover;
    overflow: hidden;
    max-height: fit-content;
    display: flex;
    align-items: flex-end;
}
.bfrntsec .bmr_mainsectl{
    padding:10px;
    margin-bottom: 10px;
    min-height: 200px;
}
.bfrntsec .bmr_title{
    color: var(--col3);
    padding:10px;
    text-align: left;
}
.bfrntsec span {
    font-size: inherit;
}
#srhheight{
    height:512px;overflow:scroll;
}
.bfrntsec span {
    font-size: inherit;
}
.fcgrid {
    display: grid;
    padding: 15px 30px;
}
.fcgrid .links{
    align-items: center;
    justify-content: right;
}
.fcgrid a{
    height: fit-content;
}
.productgrid{
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    padding: 30px 10px;
}
.bmr_grid_single,.fcgrid {
    display: grid;
    gap: 3px;
    grid-template-columns: 1fr 1fr;
}
.bmr_grid_single img{
    width: 100%;
    height: 100%;
}
.bmr_txt_g{
    background-color: #00000010;
}
.bmr_grid_single .bmr_txt_g{
    display: flex;
    align-items: center;
    width: 100%;
    justify-content: center;
}
.bmr_txt_g .bmr_txt{
    display: grid;
    gap: 15px;
    padding: 20px;
    align-items: center;
}
.bmr_txt_g h2,.bmr_txt_g h5{
    text-align: center;
    margin: 0;
}
.bmr_txt_g a,.bmr_txt_g p{
    font-size: var(--fs-8);
}
.bmr_txt_g .btn{
    padding: 12px 14px;
}
.linksnd{
    display: flex;
    width: 100%;
    justify-content: center;
}
.productgrid  .h1::after {
    content: '';
    display: block;
    background: black;
    width: 75px;
    height: 2px;
    margin-top: 10px;
}
.cntsec,
.flexsection {
    display: flex;
    align-items: center;
}
.prds {
    max-height: initial;
    grid-template-columns: 1fr 0.7fr;
}
.productgrid .cntsec.p1 {
    order: 0;
}
.imgsec img {
    height: 100%;
}
.productgrid {
    opacity: 0;
    transform: translateY(60px) scale(0.8) rotate(-5deg);
    transition: opacity 0.5s ease-out, transform 0.5s ease-out;
}

.productgrid.animated {
    opacity: 1;
    transform: translateY(0) scale(1) rotate(0);
}

.bword,.flexsection img,.flexsection h1 {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 1s ease-out, transform 1s ease-out;
}

.animated,.bword.animated,.flexsection img.animated,.flexsection h1.animated  {
    opacity: 1;
    transform: translateY(0) scale(1) rotate(0);
}

.carouselsection,.aboutus {
    opacity: 0;
    transform: translateY(120px);
    transition: opacity 1s ease-out, transform 1s ease-out;
}

.carouselsection.animated,.aboutus.animated {
    opacity: 1;
    transform: translateY(0) scale(1) rotate(0);
}

.cntsec {
    justify-content: center;
    height: 100%;
}
#changeword,
.bword {
    font-size: inherit;
    border-radius: 24px;
    padding: 4px 10px;
}
table {
    border: none;
    height: 100%;
    width: 100%;
}
tr:first-child th:first-child {
    border-top-left-radius: 24px;
}
tr:first-child th:last-child {
    border-top-right-radius: 24px;
}
tr:last-child th:first-child {
    border-bottom-left-radius: 24px;
}
tr:last-child td:last-child {
    border-bottom-right-radius: 24px;
}
tr:nth-child(odd) {
    background-color: var(--col4);
}
.btn {
    padding: 15px 25px;
    border-radius: 50px;
    border: 1px solid;
    transition: background-color 0.3s, box-shadow 0.3s;
}
.aboutus,
.carousel-slide {
    border-radius: 24px;
}
.flexsection {
    justify-content: center;
    padding: 10px;
    gap: 10px;
}
.aboutus {
    max-width: 750px;
    padding: 40px;
}

@media screen and (max-width: 992px){
    .grid_blg,.collection-list{
        grid-template-columns:1fr 1fr !important;
    }
    .bmr_category_prds{
        grid-template-columns: repeat(3,1fr);
    }
}
@media screen and (max-width: 768px) {
    .links.midsec {
        display: none !important;
    }
    .contactgrid {
        grid-template-columns: 1fr;
    }
    .fa-bars {
        display: block;
    }
    .bmr_top_nav {
        grid-template-columns: auto 1fr;
    }
    #mensectiontop .container,#womensectiontop .container,
    .productgrid {
        grid-template-columns: auto;
        grid-template-rows: 1fr auto;
    }
    .cntsec {
        display: initial;
    }
    .productgrid .cntsec.p1 {
        order: 1;
    }
    .bmr_category_prds{
        grid-template-columns: repeat(2,1fr);
    }
    .bmr_grid_single{
        grid-template-columns: 1fr;
    }
}
@media screen and (max-width: 500px) {
    a,
    li,
    ol,
    p,
    span {
        font-size: var(--fs-10);
    }
    .grid_blg,.collection-list{
        grid-template-columns:1fr !important;
    }
    .footerc {
        grid-template-columns: 1fr 1fr;
    }
    .carousel-slide {
        flex: 0 0 33.333% !important;
    }
    .bmr_category_prds{
        grid-template-columns: repeat(1,1fr);
    }
}

:root {
    --maximum-blue-green_10: hsl(200, 12%, 95%);
    --rich-black-fogra-29: hsl(217, 28%, 9%);
    --gray-x-11-gray: hsl(0, 0%, 74%);
    --oxford-blue_60: hsla(230, 41%, 14%, 0.6);
    --smoky-black: rgb(7, 6, 1);
    --gainsboro: hsl(0, 0%, 88%);
    --black_90: hsla(0, 0%, 0%, 0.9);
    --cultured: hsl(200, 12%, 95%);
    --smoky-white: whitesmoke;
    --white: hsl(0, 0%, 100%);
    --black: hsl(0, 0%, 0%);
    --onyx: hsl(0, 0%, 27%);
    --border-black: 2px solid rgb(7, 6, 1);
    --border-white: 2px solid whitesmoke;
    --border-radius: 10px;
    --margin: 10px;

    --ff-roboto: monospace;
    --ff-monospace: monospace;

    --fs-1: 3rem;
    --fs-2: 2.6rem;
    --fs-3: 2.2rem;
    --fs-4: 2rem;
    --fs-5: 1.8rem;
    --fs-6: 1.6rem;
    --fs-7: 1.4rem;
    --fs-8: 1.2rem;

    --fw-300: 100;
    --fw-500: 200;
    --fw-600: 300;
    --fw-700: 400;

    --transition-1: 0.25s ease;
    --transition-2: 0.5s ease;
    --cubic-out: cubic-bezier(0.51, 0.03, 0.64, 0.28);
    --cubic-in: cubic-bezier(0.33, 0.85, 0.56, 1.02);

    --section-padding: 40px;
}

*,
*::before,
*::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

li {
    list-style: none;
}

a {
    text-decoration: none;
}

a,
img,
span,
table,
tbody,
button,
ion-icon {
    display: block;
}

button {
    border: var(--border-black);
}
input {
    font: inherit;
    background: none;
    border: none;
}

input {
    width: 100%;
}
input[type="checkbox"]{
    width:fit-content !important;
}

button {
    cursor: pointer;
}

address {
    font-style: normal;
    line-height: 1.8;
}

html {
    font-family: var(--ff-monospace);
    font-size: 10px;
    scroll-behavior: smooth;
}

body {
    background: var(--white);
    font-size: 1.6rem;
    padding-block-start: 90px;
}

::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: hsl(0, 0%, 95%);
}

::-webkit-scrollbar-thumb {
    background: hsl(0, 0%, 80%);
}

::-webkit-scrollbar-thumb:hover {
    background: hsl(0, 0%, 70%);
}

.container {
    max-width: 100% !important;
}
.container.srcb {
    justify-content: right !important;
    gap: 10px !important;
}
.section {
    padding-block: var(--section-padding);
}

.section.end {
    padding-block: 0 var(--section-padding) !important;
}
.section.start{
    padding-block: var(--section-padding) 0 !important;
}
.section.inline{
    padding-inline: var(--section-padding) !important;
}
.section.inlines{
    padding-inline: 0 var(--section-padding) !important;
}
.section.inlinend{
    padding-inline: var(--section-padding) 0 !important;
}
.h1,
.h2,
.h3,
.h4 {
    line-break:anywhere;
    color: var(--rich-black-fogra-29);
}

.h1 {
    font-size: var(--fs-1);
    font-weight: var(--fw-300);
    line-height: 1.5;
}

.h2 {
    font-size: var(--fs-2);
    overflow: hidden;
}

.h3 {
    font-size: var(--fs-4);
}
h5,.h5{
    line-break:anywhere;
    font-weight:100 !important;
}

.h4 {
    font-size: var(--fs-5);
    text-transform: uppercase;
}

#fitlters{
    width: 100%;
    max-width: 325px;
    min-width: 225px;
height:100%;
padding:15px;
background-color:var(--smoky-white);
}
#fitlters h3{
    font-size:var(--fs-3);
}
#fitlters .h3::after{
    content:'';
    display: block;
    background: var(--smoky-black);
    width: 50px;
    height: 2px;
    margin-top: 10px;
}
.collectfil{
    margin-bottom:10px;
}
#fitlters .h4{
    margin-bottom:10px;
}
.collectfil input[type="checkbox"], .collectfil span{
    padding:3px;
}
.collectfil div{
    display:flex;
    gap:3px;
    margin-bottom: 5px;
}
.collectfil .cold{
       width: 12px;
    margin-block: 1px;
    border-radius: 3px;
}
.filsec {
    display: grid;
    gap:10px;
    grid-template-columns: auto auto;
}
.bottom_clf{
    width: 100%;text-align: center;padding: 10px;background: var(--smoky-white);color: var(--smoky-black);display:none;
}
.cta-card:hover .bottom_clf{
    display:block;
}
.btn {
    background: var(--background, var(--smoky-black));
    color: var(--color, var(--white));
    font-size: var(--fs-5);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    padding: 14px 25px;
    border-radius: var(--border-radius);
    border: var(--border-black);
}

.FLXRIGHT .btn {
    width: 100%;
}
.prdt_active_bo {
    cursor: pointer;
    margin: 10px;
}
.remove-effect {
    transition: opacity 0.5s ease;
}
.btn-primary:is(:hover, :focus) {
    --background: var(--smoky-white);
    --border-color: var(--smoky-black);
    --color: var(--smoky-black);
}

.star-rating-index {
    height: 3px;
    width: 100%;
}
.FLXDJUSTFC {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}
.TXTWRAP {
    text-wrap: nowrap;
}
.star-rate-bar {
    height: 100%;
    border-radius: var(--border-radius);
    background-color: var(--smoky-black);
}
.btn-secondary {
    --background: transparent;
    --border-color: var(--smoky-black);
    --color: var(--smoky-black);
}
.BRDCHK00 {
    width: 100%;
    border-block: var(--border-black);
    --color: var(--smoky-black);
    margin-block: var(--margin);
    padding-block: var(--margin);
}
.chkout {
    display:flex;
    justify-content: space-between;
}
.chkout .secdiv {
    width: 100%;
}
.btn-secondary:is(:hover, :focus) {
    --background: hsla(0, 0%, 0%, 0.1);
}

.has-scrollbar {
    display: flex;
    overflow-x: auto;
    gap:10px;
    padding-bottom: 20px;
    scroll-snap-type: inline mandatory;
}

.has-scrollbar > li {
    scroll-snap-align: start;
}

.has-scrollbar::-webkit-scrollbar {
    height: 10px;
}

#srhheight::-webkit-scrollbar {
    width: 0 !important;
    height: 0 !important;
}
.has-scrollbar::-webkit-scrollbar-track {
    background: var(--white);
    border-radius: 20px;
    outline: 2px solid var(--smoky-black);
}

.has-scrollbar::-webkit-scrollbar-thumb {
    background: var(--smoky-black);
    border: 2px solid var(--white);
    border-radius: 20px;
}

.has-scrollbar::-webkit-scrollbar-button {
    width: calc(25% - 40px);
}
.product-banner {
    width: 312px;
}
.card-banner {
    position: relative;
    height: 100%;
    margin-bottom: 10px;
    width: 100%;
    overflow: hidden;
}

.image-contain {
    width: 100%;
    height: 100%;
    max-height:500px;
    transition:var(--transition-2);
}

.product-card .image-contain.sc1{
    transition:var(--transition-1);
    display:block;
}
.collectionlist{
    margin:10px;
    display:grid;
    grid-template-columns:1fr;
    gap:10px;
}
#mensectionbtn,#womensectionbtn{
        display: flex;
    gap: 5px;
}
}
.collectionlist h4{
    font-weight:100;
}
.product-card:hover .image-contain.sc1{
    display:none;
}
.product-card .image-contain.sc2{
    display:none;
}
.product-card:hover .image-contain.sc2{
    display:block;
}
.saaaaaaaaaaaa{
    object-fit: contain;
    object-position: center;
}
@media (max-width: 992px) {
    #fitlters{
        display:none;
    }
    .filsec {
        grid-template-columns:auto;
    }
    .image-contain {
    width: 100%;
    height: 100%;
    max-height:500px;
    object-fit: contain;
    object-position: center;
    transition: var(--transition-2);
}
.product-card,
.product-item {
    width: 100% !important;
}
.spl_fld_ent .image-contain {
        width: 250px;
        height: 100% !important;
        object-fit: contain;
        object-position: center;
        transition: var(--transition-2);
    }
}
@media (max-width: 768px){
.container.chkout.r{
    display:block;
}
.spl_fld_ent .image-contain {
        width: 100% !important;
    height: 100% !important;
        max-height: 350px;
        object-fit: contain;
        object-position: center;
        transition: var(--transition-2);
    }
}
.creator-item .image-contain {
    border-radius: 50%;
}

.loader {
    width: 100%;
    height: 500px;
    margin: auto;
    position: relative;
    overflow: hidden;
}
.loader.card-banner{
    position: relative;
    margin-bottom: 10px;
    min-width: 312px;
    overflow: hidden;
}
.loader.r {
    max-width: 247px !important;
    height: 247px !important;
    border-radius: 50% !important;
}

.loader::after {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: calc(100% - 0px);
    height: calc(100% - 0px);
    background-color: hsl(200, 12%, 95%);
    background-image: linear-gradient(90deg, transparent, rgba(255, 255, 255, 1) 100%, transparent 10%), linear-gradient(hsl(200, 12%, 95%) 200px, transparent 100%);
    background-repeat: no-repeat;
    background-size: 100px 512px, 100% 500px;
    background-position: -100% 0, center 0;
    animation: 1.5s linear infinite animloader;
}
.loader::after.r {
    background-size: 100px 247px, 100% 500px !important;
}

.loader:nth-child(2)::after {
    animation-delay: 0.4s;
}

.loader:nth-child(3)::after {
    animation-delay: 0.6s;
}

@keyframes animloader {
    to {
        background-position: 100% 0, center 0;
    }
}
.card-action-btn.active {
    background: var(--smoky-black);
    color: var(--white);
}
.product-card:is(:hover, :focus) .image-contain {
    transform: scale(1.1);
}
ion-icon.heart.active,
ion-icon.book.active {
    color: red;
}
.fav-card-item{
        position: absolute;
    top: 10px;
    right: 10px;
}
.card-badge {
    position: absolute;
    top: 10px;
    left: 10px;
    background: var(--smoky-black);
    color: var(--white);
    padding: 5px 15px;
    font-family: var(--ff-roboto);
    font-size: var(--fs-7);
    border-radius: 25px;
}

.card-action-list {
    position: absolute;
    top: 20px;
    right: -20px;
    opacity: 0;
    transition: var(--transition-1);
}

.product-item {
    width: 250px !important;
}
.product-card{
    width:100%;
}
.product-card:is(:hover, :focus) .card-action-list {
    right: 20px;
    opacity: 1;
}
.FLXRIGHT,
.FLXCENTER,
.FLXLEFT {
    display: flex;
    align-items: center;
}

.dispgridourv{
    display:grid;grid-template-columns:1fr 1fr;min-height:500px;
}
.dispgridourv .FLXCENTER{
    padding:20px;
}
.FLXRIGHT {
    justify-content: right;
}
.FLXCENTER {
    justify-content: center;
}
.FLXLEFT {
    justify-content: left;
}

.btnd {
    padding: 12px 24px;
    border-radius: 50px;
    border: 1px solid;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: fit-content;
    transition: background-color 0.3s, box-shadow 0.3s;
}
.btnd.blc{
    color: var(--col5);
    border: 1px solid black;
}
.btnd:hover,.btnd.blc:hover {
    background-color: var(--col5);
    color: var(--col1);
}
.logincontainer {
    z-index: 11111;
    width: 100%;
    position: fixed;
    top: 0;
    background-color: #30303787;
    height: 100vh;
    margin-left: auto;
    display: flex;
    align-items: center;
    justify-content: center;
}
.loginsection {
    margin: auto;
    background: white;
    min-width: 250px;
    width:100%;
    max-width: 450px;
    border-radius: 10px;
    border: var(--border-black);
}
.card-action-item {
    position: relative;
}

.card-action-item:not(:last-child) {
    margin-bottom: 10px;
}

.card-action-btn {
    background: var(--white);
    color: var(--rich-black-fogra-29);
    font-size: 1.4rem;
    padding: 5px;
    border-radius: 50%;
    transition: var(--transition-1);
}

.card-action-btn ion-icon {
    --ionicon-stroke-width: 30px;
}

.card-action-btn:is(:hover, :focus) {
    background: var(--smoky-black);
    color: var(--white);
}

.card-action-tooltip {
    position: absolute;
    top: 50%;
    right: calc(100% + 5px);
    transform: translateY(-50%);
    width: max-content;
    background: var(--black_90);
    color: var(--white);
    font-family: var(--ff-roboto);
    font-size: var(--fs-7);
    padding: 4px 8px;
    border-radius: 4px;
    opacity: 0;
    pointer-events: none;
    transition: var(--transition-1);
}

.card-action-btn:is(:hover, :focus) + .card-action-tooltip {
    opacity: 1;
}

.card-content {
    min-height: 65px;
    padding: 5px;
    width: 250px;
    text-align: center;
}
.logincontainer .card-content,.logincontainer .product-card {
    width: 100% !important;
}
.card-cat {
    font-family: var(--ff-roboto);
    color: var(--onyx);
    font-size: var(--fs-7);
    margin-left: auto;
}

.prf_top {
    padding-block-start: 40px !important;
    padding-block-end: 0px !important;
}
.prf_top .special-product {
    width: 100% !important;
}
.prd_inst_ord_prf .insta-con-tai-ner {
    margin-top: 0px !important;
}
.prd_inst_ord_prf .brd_tinstaer,
.prd_inst_ord_prf .insta-statu-ses {
    padding: 15px 20px;
}
.card-cat-link {
    display: inline-block;
    color: inherit;
    transition: var(--transition-1);
}

.card-cat-link:is(:hover, :focus) {
    color: var(--smoky-black);
}

.product-card .card-title {
    margin-bottom: 5px;
}

.product-card .card-title > a {
    color: inherit;
    transition: var(--transition-1);
}

.product-card .card-title > a:is(:hover, :focus) {
    color: var(--smoky-black);
}

.card-price {
    color: var(--smoky-black);
    font-family: var(--ff-roboto);
    font-weight: var(--fw-600);
}

.card-price del {
    color: var(--gray-x-11-gray);
    margin-left: 8px;
}

.btn-link {
    --background: none;
    --border-color: none;
    padding: 0;
    margin-inline: auto;
    max-width: max-content;
    font-family: var(--ff-roboto);
    font-size: var(--fs-6);
    font-weight: var(--fw-500);
    padding-bottom: 6px;
    border-radius: 0px !important;
    border-top: 0 !important;
    border-left: 0 !important;
    border-right: 0 !important;
    border-bottom: 1px solid var(--white);
}
.btn-link.b {
    color: black;
    border-bottom: 1px solid var(--smoky-black);
    margin-left: 5px;
}

.btn-link:is(:hover, :focus) {
    border-color: transparent;
}

.header {
    background: var(--white);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    transition: var(--transition-1);
    z-index: 4;
}

.header.active {
    box-shadow: 0 2px 10px hsla(0, 0%, 0%, 0.1);
}

.header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-block: 14px;
}


.navbar {
    background: var(--white);
    position: fixed;
    top: 0;
    left: -280px;
    width: 100%;
    max-width: 270px;
    height: 100%;
    border-right: 3px solid var(--rich-black-fogra-29);
    font-family: var(--ff-roboto);
    overflow-y: auto;
    overscroll-behavior: contain;
    z-index: 2;
    visibility: hidden;
    transition: 0.25s var(--cubic-out);
}

.navbar.active {
    visibility: visible;
    transform: translateX(280px);
    transition: 0.5s var(--cubic-in);
}

.nav-close-btn {
    color: var(--rich-black-fogra-29);
    position: absolute;
    top: 0;
    right: 0;
    padding: 13px;
    font-size: 25px;
    transition: var(--transition-1);
}

.nav-close-btn ion-icon {
    --ionicon-stroke-width: 55px;
}

.nav-close-btn:is(:hover, :focus) {
    color: var(--smoky-black);
}

.navbar .logo {
    background: var(--maximum-blue-green_10);
    padding-block: 20px 20px;
}

.navbar .logo img {
    margin-inline: auto;
}

.navbar-list,
.nav-action-list {
    margin: 30px;
}

.navbar-list {
    padding: 20px;
    border-bottom: 1px solid var(--gainsboro);
}
.getprdtp .product-item {
     width: 100% !important;
}
.getprdtp .image-contain{
    max-height:initial!important;
}
.product-item {
    width: 312px;
}
.navbar-link {
    color: var(--rich-black-fogra-29);
    padding-block: 10px;
    transition: var(--transition-1);
}

.navbar-link:is(:hover, :focus) {
    color: var(--smoky-black);
}

.navbar-item:not(:last-child) {
    border-bottom: 1px solid var(--gainsboro);
}

.nav-action-list > li:first-child {
    display: none;
}
.nav-open-btn1{
    display:block;
}
.nav-action-btn,.nav-open-btn  {
    color: var(--rich-black-fogra-29);
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    padding-block: 10px;
    transition: var(--transition-1);
}

.nav-action-btn:is(:hover, :focus),.nav-open-btn:is(:hover, :focus) {
    color: var(--smoky-black);
}

.nav-action-btn ion-icon,.nav-open-btn ion-icon {
    font-size: 22px;
    --ionicon-stroke-width: 25px;
}

.nav-action-text strong {
    font-weight: initial;
    color: var(--smoky-black);
}

.nav-action-badge {
    margin-left: auto;
    font-size: var(--fs-8);
    background: var(--smoky-black);
    color: var(--white);
    width: 18px;
    height: 18px;
    display: grid;
    place-items: center;
    border-radius: 50%;
}

.overlay {
    position: fixed;
    inset: 0;
    background: hsla(0, 0%, 0%, 0.6);
    z-index: 1;
    opacity: 0;
    pointer-events: none;
    transition: var(--transition-1);
}

.overlay.active {
    opacity: 1;
    pointer-events: all;
}

.hero {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: left;
    min-height: 400px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
}

.hero-title {
    margin-bottom: 10px;
    color: var(--smoky-white);
}

.hero-title > strong {
    display: block;
}

.hero-text {
    color: var(--smoky-white);
    font-family: var(--ff-roboto);
    font-size: var(--fs-8);
    line-height: 1.8;
    max-width: 46ch;
    margin-bottom: 25px;
}
.section.collection,.section.special {
    padding-block: 20px !important;
}
.collection-card {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    height: 400px;
    min-width:500px;
    width:100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    transition: var(--transition-1);
}
.collection-card.r {
    min-width:50px !important;
}

products .fa{
        font-size: 1rem;
}
subscribe input{
        border: 2px solid;
}
.collection-card.brands{
    min-width:auto;
}
.collection-card:hover{
    transform: scale(1.1);
}
.collection-list{
  display: grid;
    grid-template-columns: 1fr 1fr 1fr ;
    gap: 10px;
}
.collection-list li{
    min-width:300px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    overflow: hidden;
}


.product .section-title {
    text-align: center;
    margin-bottom: 25px;
}

.filter-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-bottom: 30px;
}

.filter-btn {
    color: var(--onyx);
    padding: 10px 16px;
    font-family: var(--ff-roboto);
    font-size: var(--fs-7);
    font-weight: var(--fw-500);
    border: 1px solid var(--gainsboro);
    border-radius: 30px;
}
.prf_sec {
    border: var(--border-black);
    border-radius: var(--border-radius);
}
.prf_sec_tm {
    padding: 10px;
    border-bottom: var(--border-black);
    display: flex;
}

.prf_sec_body {
    padding: 10px;
}
.filter-btn.active {
    background: var(--smoky-black) !important;
    color: var(--white);
    border-color: var(--smoky-black);
}

.product-list {
    display: grid;
    gap: 10px;
}
.product-list li{
    overflow:hidden;
}

.cta-list {
    display: grid;
    gap: 30px;
}

.cta-card {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    color: var(--white);
    height: 650px;
    text-align: center;
}

.cta-card .card-subtitle {
    font-size: var(--fs-5);
    margin-bottom: 15px;
}
.card-title{
    text-align:left;
}
.cta-card .card-title {
    color: inherit;
    line-height: 1.3;
    margin-bottom: 20px;
}

.special-banner {
    height: 500px;
    background-color: var(--smoky-black);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
    padding: 50px 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
}

.special-banner .banner-title {
    color: var(--white);
    font-weight: var(--fw-600);
}
.text a{
    font-size: var(--fs-6);
    color: black;
}
.text a:hover{
    border-bottom:2px solid black;;
}
.special .section-title,
.cta .section-title,
.creator .section-title {
    margin-block: 40px;
    display: flex;
    align-items: center;
    gap: 20px;
}

.special .section-title .text {
    min-width: max-content;
}

.special .section-title .line,
.cta .section-title .line,
.creator .section-title .line {
    width: 100%;
    height: 1px;
    background: var(--gainsboro);
}

.service-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
}

.service-item {
    width: 220px;
}

.service-card {
    display: flex;
    align-items: center;
    gap: 10px;
}

.service-card .card-icon {
    background: var(--smoky-black);
    min-width: 55px;
    height: 55px;
    border-radius: 50%;
    display: grid;
    place-items: center;
}

.service-card .card-icon ion-icon{
    color:var(--smoky-white);
    font-size: var(--fs-3);
}
.service-card .card-icon img {
    filter: brightness(0) invert(1);
    width: 60%;
    height: auto;
}

.service-card .card-title {
    font-size: var(--fs-6);
    margin-bottom: 8px;
}

.service-card .card-text {
    color: var(--onyx);
    font-family: var(--ff-roboto);
    font-size: var(--fs-7);
}

.prdo_drid {
    display: grid;
    grid-template-columns: 1fr;
}

.prdo_drid1{
    display: grid;
    grid-template-columns: 1fr;
    gap:25px;
}
  .prdo_drid1 h3.h3.section-title.FLXLEFT{
        justify-content: center;
    }
.service-card .card-text span {
    display: inline-block;
    color: var(--smoky-black);
}

.creator-list {
    gap: 0;
}

.creator-list .creator-item {
    position: relative;
    min-width: 33.33%;
    margin: 20px;
    border-radius: 50%;
}

.creator-link {
    position: absolute;
    inset: 0;
    display: grid;
    place-items: center;
    border-radius: 50%;
    height: 100%;
    width: 100%;
    background: var(--oxford-blue_60);
    opacity: 0;
    color: var(--smoky-white);
    transition: var(--transition-1);
}

.creator-link ion-icon {
    color: var(--white);
    font-size: 40px;
}

.creator-link:is(:hover, :focus) {
    opacity: 1;
}

.footer {
    font-family: var(--ff-roboto);
}

.footer-top {
    background: var(--cultured);
}

.footer-brand {
    padding-bottom: 50px;
    border-bottom: 1px solid var(--gainsboro);
    margin-bottom: 50px;
}

.footer-brand .logo {
    margin-bottom: 15px;
}

.social-list {
    display: flex;
    align-items: center;
    gap: 8px;
}

.social-link {
    background: var(--gainsboro);
    color: var(--onyx);
    font-size: 20px;
    padding: 10px;
    border-radius: var(--border-radius);
    transition: var(--transition-1);
}

.social-link:is(:hover, :focus) {
    background: var(--smoky-black);
    color: var(--white);
}

.footer-list-title {
    position: relative;
    color: var(--rich-black-fogra-29);
    font-family: var(--ff-monospace);
    font-size: var(--fs-3);
    font-weight: var(--fw-700);
    margin-bottom: 25px;
}

.footer-list-title::after {
    content: "";
    display: block;
    background: var(--smoky-black);
    width: 50px;
    height: 2px;
    margin-top: 10px;
}

.footer-link {
    color: var(--onyx);
    display: flex;
    align-items: center;
    gap: 10px;
    padding-block: 6px;
    transition: var(--transition-1);
}

a.footer-link:is(:hover, :focus) {
    color: var(--smoky-black);
}

.footer-link-text {
    flex: 1;
}

.footer-list:not(:last-child) {
    margin-bottom: 30px;
}

.footer-list:first-child ion-icon {
    color: var(--smoky-black);
    font-size: 22px;
}

.table-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    text-align: left;
    padding-block: 6px;
}

.table-head {
    color: var(--rich-black-fogra-29);
    font-weight: var(--fw-500);
}

.table-data {
    color: var(--onyx);
}

.newsletter-text {
    color: var(--onyx);
    line-height: 1.7;
    margin-bottom: 20px;
}

.newsletter-form {
    position: relative;
}

.newsletter-input {
    background: var(--white);
    color: var(--onyx);
    padding: 15px 25px;
    padding-right: 120px;
    border: var(--border-black) !important;
    border-radius: var(--border-radius) !important;
}

.newsletter-form .btn-primary {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    font-family: var(--ff-monospace);
    font-size: var(--fs-6);
    font-weight: var(--fw-600);
    padding-inline: 20px;
}

.footer-bottom {
    background: var(--rich-black-fogra-29);
    padding-block: 20px;
}

.copyright {
    text-align: center;
    color: var(--white);
}

.copyright-link {
    display: inline-block;
    color: var(--smoky-white);
}

.go-top-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: var(--smoky-black);
    color: var(--white);
    font-size: 20px;
    padding: 10px;
    border: var(--border-black) !important;
    border-radius: 50%;
    opacity: 0;
    visibility: hidden;
    transition: var(--transition-1);
    z-index: 2;
}

.go-top-btn.active {
    opacity: 1;
    visibility: visible;
}

.go-top-btn:is(:hover, :focus) {
    background: var(--smoky-white);
    border: var(--border-black);
    color: var(--smoky-black);
}
.cta-card .btn-link.bl{
    color: var(--smoky-black);
}
.btn-link.bl{
        border-bottom: 1px solid var(--black);
}
.splh{
    font-size: var(--fs-5);
    color: white;
    text-align: center;
    margin-block: 20px;
}
.splh:hover{
    border-bottom:2px solid white;
}
@media (min-width: 500px) {
      .product-list {
    grid-template-columns: 1fr 1fr;
      }
}

@media (min-width: 650px) {
    :root {
        --fs-1: 4rem;
    }

    .container {
        max-width: 650px;
        width: 100%;
        margin-inline: auto;
    }
    .has-scrollbar > li {
        min-width: 250px;
    }

    .hero-text {
        font-size: var(--fs-7);
    }

    .product-list {
        grid-template-columns: 1fr 1fr;
    }

    .cta-card {
        text-align: left;
    }

    .cta-card .card-title {
        max-width: 14ch;
    }

    .cta-card .btn-link {
        margin-inline: 0;
    }

    .creator-list .creator-item {
        min-width: 25%;
    }

    .footer-brand .logo {
        margin-bottom: 0;
    }

    .footer-brand {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .footer-link-box {
        display: grid;
        grid-template-columns: 1fr 1fr;
        column-gap: 30px;
    }
}

@media (min-width: 768px) {
    :root {
        --fs-2: 3rem;
    }

    .container {
        max-width: 720px;
    }

    .h4 {
        --fs-5: 2rem;
    }

    .special-banner .banner-title {
        --fs-4: 2.2rem;
    }

    .special-product .has-scrollbar > li {
        min-width: fit-content;
    }

    .special .container {
        width: 100%;
        gap: 25px;
    }

    .special .container.ord {
        display: flex;
        gap: 25px;
        align-items: center;
        justify-content: center;
    }
    .prdo_drid {
        display: grid;
        grid-template-columns: 1fr 1fr !important;
    }
    .prdo_drid1 {
        display: grid;
        grid-template-columns: 1fr 2fr !important;
    }
    .prdo_drid1 h3.h3.section-title.FLXLEFT{
        justify-content: left;
    }

    .special .section-title {
        margin-block-start: 0;
    }

    .special-banner,
    .special-product {
        min-width: calc(50% - 12.5px);
    }

    .special-banner {
        height: auto;
    }

    .creator-list .creator-item {
        min-width: 20%;
    }

    .go-top-btn {
        padding: 15px;
        border-width: 6px;
        bottom: 30px;
        right: 30px;
    }
}
@media (min-width: 800px){
       .product-list {
        grid-template-columns: 1fr 1fr 1fr;
    }
}

@media (max-width: 500px){
    .image-contain{
        max-height: 500px;
    }
    .card-banner{
        width:100%;
    }
}
@media (max-width: 800px){
  .dispgridourv{
        grid-template-columns:1fr;
        grid-template-rows: 1fr .5fr;
        min-height: 600px;
    }
    .dispgridourv .rtv{
            order: 1;
    }
}
@media (min-width: 992px) {
    :root {
        --fs-3: 2.4rem;
    }

    .container {
        max-width: 970px;
    }

    .has-scrollbar > li {
        min-width: calc(33.33% - 16.66px);
    }

    .nav-open-btn1,
    .nav-close-btn,
    .navbar .logo,
    .nav-action-text,
    .overlay,
    .container.srcb {
        display: none;
    }

    .navbar,
    .navbar-list,
    .nav-action-list {
        all: unset;
    }

    .navbar-item:not(:last-child) {
        border: none;
    }

    .navbar-list,
    .nav-action-list {
        display: flex;
    }

    .nav-action-list {
        gap: 20px;
    }

    .navbar {
        display: flex;
        align-items: center;
        flex-grow: 1;
    }

    .navbar-list {
        margin-inline: auto;
        gap: 35px;
    }

    .navbar-link {
        font-family: var(--ff-roboto);
        font-weight: var(--fw-500);
    }

    .nav-action-list > li:first-child {
        display: block;
    }

    .nav-action-btn,.nav-open-btn {
        position: relative;
    }

    .nav-action-badge ion-icon {
        --ionicon-stroke-width: 30px;
    }

    .nav-action-badge {
        position: absolute;
        top: 5px;
        right: -12px;
    }

    .hero {
        height: 480px;
    }

    .product-list {
        grid-template-columns: repeat(3, 1fr);
    }

    .cta-list {
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .special-banner {
        min-width: calc(33.33% - 25px);
    }

    .special-product {
        min-width: 66.66%;
    }

    .special-product .has-scrollbar > li {
        min-width: 250px;
    }

    .creator-list .creator-item {
        min-width: 16.666%;
    }
}

@media (min-width: 1200px) {
    :root {
        --fs-1: 5rem;
        --fs-2: 3.6rem;
    }

    .container {
        max-width: 1280px;
    }

    .hero {
        height: 580px;
    }

    .hero .container {
        max-width: 1000px;
    }

    .hero-text {
        font-size: var(--fs-6);
        max-width: 50ch;
    }

    .product-list {
        grid-template-columns: repeat(4, 1fr);
    }

    .special-banner {
        min-width: calc(25% - 25px);
    }

    .special-product .has-scrollbar > li {
        min-width: 250px;
    }

    .special-banner .banner-title {
        --fs-4: 2.4rem;
    }

    .service-item {
        width: 275px;
    }

    .service-card .card-icon {
        min-width: 70px;
        height: 70px;
    }

    .service-card .card-title {
        --fs-6: 2rem;
    }

    .creator {
        padding-block-end: var(--section-padding);
    }

    .creator-list .creator-item {
        min-width: 12.5%;
    }

    .creator-list {
        padding-bottom: 0;
    }

    .footer-link-box {
        grid-template-columns: 1.5fr 1fr 1fr 1.5fr;
        gap: 50px;
    }
}

@media (min-width: 1600px) {
     .product-list {
        grid-template-columns: repeat(5, 1fr);
    }
}
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300;400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="/styles/fontawesome/css/fontawesome.css" rel="stylesheet" />
    <link href="/styles/fontawesome/css/brands.css" rel="stylesheet" />
    <link href="/styles/fontawesome/css/solid.css" rel="stylesheet" />
    <meta name="description" content="<?php echo $about; ?>">
    <meta name="keywords" content="fashion, style, clothing, trends">
    <meta property="og:title" content="<?php echo $title; ?>">
    <meta property="og:description" content="<?php echo $about; ?>">
    <meta property="og:image" content="<?php echo $image; ?>">
    <meta property="og:url" content="https://www.ruluka.com">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@yourtwitterhandle">
    <meta name="twitter:title" content="<?php echo $title; ?>">
    <meta name="twitter:description" content="<?php echo $about; ?>">
    <meta name="twitter:image" content="<?php echo $image; ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
