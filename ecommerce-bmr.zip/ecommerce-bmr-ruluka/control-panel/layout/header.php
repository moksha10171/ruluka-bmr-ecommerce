<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$accountfav = '';
$accountcart = '';
$conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
if ($conn->connect_error) {
    $accountLink = '<a onclick="BLOGINSNETW()"><ion-icon name="person-outline" aria-hidden="true"></ion-icon></a>';
} else {
if(isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
    $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
        $stmt1->bind_param("s", $row['eml_usr_f_']);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows > 0) {
            $rowbmr = $result1->fetch_assoc();
            if($rowbmr['live_favorites'] > 0){
                $accountfav = '<data class="nav-action-badge" id="favr_val_" value="'.$rowbmr['live_favorites'].'" aria-hidden="true">'.$rowbmr['live_favorites'].'</data>';
            } else {
                $accountfav = '<data class="nav-action-badge" style="display:none" id="favr_val_" value="'.$rowbmr['live_favorites'].'" aria-hidden="true">'.$rowbmr['live_favorites'].'</data>';
            }
            if($rowbmr['live_cart'] > 0){
                $accountcart = '<data class="nav-action-badge" id="cart_val_" value="'.$rowbmr['live_cart'].'" aria-hidden="true">'.$rowbmr['live_cart'].'</data>';
            } else {
                $accountcart = '<data class="nav-action-badge" style="display:none" id="cart_val_" value="'.$rowbmr['live_cart'].'" aria-hidden="true">'.$rowbmr['live_cart'].'</data>';
            }
            $accountLink = '<a href="/profile/"><ion-icon name="person-outline" aria-hidden="true"></ion-icon></a>';
        } else {
            $accountLink = '<a onclick="BLOGINSNETW()"><ion-icon name="person-outline" aria-hidden="true"></ion-icon></a>';
        }
    } else {
        $accountLink = '<a onclick="BLOGINSNETW()"><ion-icon name="person-outline" aria-hidden="true"></ion-icon></a>';
    }
} else {
    $accountLink = '<a onclick="BLOGINSNETW()"><ion-icon name="person-outline" aria-hidden="true"></ion-icon></a>';
}
}
   $sql1f = "SELECT DISTINCT prd_type FROM prouduct_section_1 WHERE prd_gender='M' OR prd_gender='A'";
        $result1f = mysqli_query($conn, $sql1f);
        $getfl = '';
         while ($row1f = mysqli_fetch_assoc($result1f)) {
        $getfl .= '<h4><a href="">'.$row1f['prd_type'].'</a></h4>';
         }
         $sql1fa = "SELECT DISTINCT prd_type FROM prouduct_section_1 WHERE prd_gender='W' OR prd_gender='A'";
                $result1fa = mysqli_query($conn, $sql1fa);
        $getfla = '';
         while ($row1fa = mysqli_fetch_assoc($result1fa)) {
        $getfla .= '<h4><a href="">'.$row1fa['prd_type'].'</a></h4>';
         }
?>
        <header>
            <div id="offersec">
                SHOP NOW 20% OFF
            </div>
            <div class="bmr_top_nav">
                <div class="links midsec">
                    <a href="/shop">Shop</a>
                    <a id="mensectionbtn" href="javascript:void(0)">Men <i class="fa fa-caret-down"></i></a>
                    <a id="womensectionbtn" href="javascript:void(0)">Women <i class="fa fa-caret-down"></i></a>
                    <a href="/brands/">Brands</a>
                    <a href="/about-us">About us</a>
                     <a href="/blog">Blog</a>
                </div>
                <div class="logo">
                    <h1><a href="https://www.ruluka.com/">RULUKA</a></h1>
                </div>
                <div class="links right">
                    <a onclick="toggleSearch()"><ion-icon name="search-outline" aria-hidden="true"></ion-icon></a>
                    <a href="/favourites"><ion-icon name="heart-outline" aria-hidden="true"></ion-icon></a>
                    <a href="/cart"><ion-icon name="bag-outline" aria-hidden="true"></ion-icon></a>
                    <?php echo $accountLink;?>
                    <a onclick="opennav()"><ion-icon name="menu-outline"></ion-icon></a>
                </div>
            </div>
            <div id="mensectiontop">
                <div class="container">
                    <div class="gridsection">
                        <h2><a href="/collections/men">Men's Fashion</a></h2>
                        <div class="collectionlist">
                        <?php echo $getfl;?>
                        </div>
                    </div>
                    <div class="bmr_imgtop_drpd">
                        <img id="imgsecv" src="/images/joe-gardner-NorYfP4rwmQ-unsplash (1).jpg" />
                    </div>
                </div>
            </div>
            <div id="womensectiontop">
                <div class="container">
                    <div class="gridsection">
                        <h2><a href="/collections/women">Women's Fashion</a></h2>
                        <div class="collectionlist">
                        <?php echo $getfla;?>
                        </div>
                    </div>
                    <div class="bmr_imgtop_drpd">
                        <img id="imgsecv" src="/images/womens_fashion.jpg" />
                    </div>
                </div>
            </div>
            <div id="search" style="display: none;">
    <div class="container" id="srch">
        <div style="padding:20px;">
            <div class="newsletter-form">
                <input type="text" name="search" required="" id="ONINPUTSRH" oninput='SRHS00340()' placeholder="Search..." class="newsletter-input">
                <a class="btn btn-primary"><ion-icon name="search-outline" aria-hidden="true"></ion-icon></a>
            </div>
        <div id="srhheight">
            <div id="SRHSDFG0009IOLOAD"></div>
            <div id="SRHSDFG0009IOL"></div>
        </div>
        </div>
    </div>
</div>
        </header>
        <nav>
            <div class="secnav">
                <div class="timesx"><a class="fa fa-times" onclick="closenav()"></a></div>
                <div class="logo">
                    <h1><a href="https://www.ruluka.com/">RULUKA</a></h1>
                </div>
                 <div><a href="/shop">Shop</a></div>
                <div><a onclick="$('#mensectionnav').slideToggle();">Men <i class="fa fa-caret-down"></i></a></div>
                <div id="mensectionnav">
                    <div class="container">
                        <div class="gridsection">
                            <h3><a href="/collections/men">Men Collections</a></h3>
                            <div class="collectionlist">
                        <?php echo $getfl;?>
                        </div>
                        </div>
                    </div>
                </div>
                <div><a onclick="$('#womensectionnav').slideToggle();">Women <i class="fa fa-caret-down"></i></a></div>
                <div id="womensectionnav">
                    <div class="container">
                        <div class="gridsection">
                            <h3><a href="/collections/women">Women Collections</a></h3>
                            <div class="collectionlist">
                        <?php echo $getfla;?>
                        </div>
                        </div>
                    </div>
                </div>
                <div><a href="/brands/">Brands</a></div>
                <div><a href="/about-us">About us</a></div>
                <div><a href="/blog">Blog</a></div>
            </div>
        </nav>