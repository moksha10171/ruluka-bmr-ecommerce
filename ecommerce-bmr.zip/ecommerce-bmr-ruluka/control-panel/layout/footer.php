<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$accountfav = '';
$accountcart = '';
$conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
if ($conn->connect_error) {
    $accountLink = '<a class="nav-action-btn" onclick="BLOGINSNETW()">
                      <ion-icon name="person-outline" aria-hidden="true"></ion-icon>
                      <span class="nav-action-text">Login / Register</span>
                    </a>';
} else {
if(isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
    $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
        $stmt1->bind_param("s", $row['eml_usr_f_']);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows > 0) {
            $rowbmr = $result1->fetch_assoc();
            if($rowbmr['live_favorites'] > 0){
                $accountfav = '<data class="nav-action-badge" id="favr_val_" value="'.$rowbmr['live_favorites'].'" aria-hidden="true">'.$rowbmr['live_favorites'].'</data>';
            } else {
                $accountfav = '<data class="nav-action-badge" style="display:none" id="favr_val_" value="'.$rowbmr['live_favorites'].'" aria-hidden="true">'.$rowbmr['live_favorites'].'</data>';
            }
            if($rowbmr['live_cart'] > 0){
                $accountcart = '<data class="nav-action-badge" id="cart_val_" value="'.$rowbmr['live_cart'].'" aria-hidden="true">'.$rowbmr['live_cart'].'</data>';
            } else {
                $accountcart = '<data class="nav-action-badge" style="display:none" id="cart_val_" value="'.$rowbmr['live_cart'].'" aria-hidden="true">'.$rowbmr['live_cart'].'</data>';
            }
            $accountLink = '<a  href="/profile/" class="footer-link">
                <ion-icon name="chevron-forward-outline"></ion-icon>

                <span class="footer-link-text">Login / Register</span>
              </a>';
        } else {
            $accountLink = '<a  onclick="BLOGINSNETW()" class="footer-link">
                <ion-icon name="chevron-forward-outline"></ion-icon>

                <span class="footer-link-text">Login / Register</span>
              </a>';
        }
    } else {
        $accountLink = '<a  onclick="BLOGINSNETW()" class="footer-link">
                <ion-icon name="chevron-forward-outline"></ion-icon>

                <span class="footer-link-text">Login / Register</span>
              </a>';
    }
} else {
    $accountLink = '<a  onclick="BLOGINSNETW()" class="footer-link">
                <ion-icon name="chevron-forward-outline"></ion-icon>

                <span class="footer-link-text">Login / Register</span>
              </a>';
}
}
?>
<div id="SECBLOGINSNETW" style="display:none;">
<div class="logincontainer">
    <div class="loginsection">
     <div class="FLXRIGHT">
             <ion-icon name="close-outline" onclick="BLOGINSNETW()" class="h1"></ion-icon>
            </div>
            <section class="section product">
              
        <div class="container">
          <div  id="LOGDFG0009IOLDIS">
           <div id="LOGLOADSECID"></div>
           <div id="LOGINSEC" style="display:block;">
               <h2 class="h2 section-title">SIGN IN</h2>
                <div class="product-card" tabindex="0">
                  <div class="card-content">
                    <div class="newsletter-form">
                       <input type="email" name="email" required placeholder="Email Address" id="login_email" class="newsletter-input">
                       <br><br>
                       <input type="password" name="password" required placeholder="Password" id="login_password" class="newsletter-input">
                      <br><br>
                      <div class="flex2cntg">
                          <input type="checkbox" style="width:auto" name="showPassword" id="showPassword"> Check password
                      </div>
                      <br>
                    </div>
                    <div id="error"></div>
                    <br>
                    <div class="FLXCENTER">
                        <p onclick="FRGTINSNETW()" style="text-decoration:underline;">Forgot password</p>
                    </div>
                    <br>
                    <div class="FLXRIGHT">
                        <button id="logc" class="btn btn-primary">SIGN IN</button>
                    </div>
                    <br>
                    <div class="FLXCENTER">
                        <p>Don’t have an account? <a onclick="SIGNUPPAGE()" style="text-decoration:underline;">Sign up</a></p>
                    </div>
                </div>

                </div>
            </div>
            <div id="SIGNUPSEC" style="display:none;">
                <div id="log__c1" style="display:block;">
                <h2 class="h2 section-title">SIGN UP</h2>
                <div class="product-card" tabindex="0">
                  <div class="card-content">
                    <div class="newsletter-form">
                       <input type="email" name="email" required placeholder="Email Address" id="signup_email" class="newsletter-input">
                       <br><br>
                       <input type="password" name="password" required placeholder="Password" id="signup_password" class="newsletter-input">
                      <br><br>
                      <div class="flex2cntg">
                          <input type="checkbox" style="width:auto" name="showPassword1" id="showPassword1"> Check password
                      </div>
                      <br>
                      <div class="errorsup1"></div>
                      <br>
                    </div>
                    <div class="FLXRIGHT">
                        <button id="logc1" class="btn btn-primary">GET STARTED</button>
                    </div>
                    <br>
                    <div class="FLXCENTER">
                        <p onclick="SIGNUPPAGE()" style="text-decoration:underline;">Return to Sign in</p>
                    </div>
                </div>
                </div>
                </div>
                <div id="otp_html" style="display:none;">
                    <h2 class="h2 section-title">JUST ONE MORE STEP</h2>
                <div class="product-card" tabindex="0">
                  <div class="card-content">
                    <div class="newsletter-form">
                    <input type="text" name="text" required placeholder="Enter OTP" id="signup_otp" class="newsletter-input">
                       <br><br>
                       
                </div>
                <span style="cursor: pointer;" id="time_b"><span id="countdown"></span></span>
                <br>
                       <div class="errorsup1"></div>
                       <br>
                       <div class="FLXRIGHT">
                        <button id="logo_1" class="btn btn-primary">VERFIY</button>
                    </div>
                    <br>
                    <div class="FLXCENTER">
                        <p onclick="SIGNUPPAGE()" style="text-decoration:underline;">Return to Sign in</p>
                    </div>
                </div>
                </div>
                </div>
            </div>
            <div id="FRGTINSNETW" style="display:none;">
                <h2 class="h2 section-title">RESET PASSWORD</h2>
                <div id="reset_form">
                    <div class="product-card" tabindex="0">
                  <div class="card-content">
                    <div class="newsletter-form">
                       <input type="email" name="email" required placeholder="Email Address" id="frgt_login_email" class="newsletter-input">
                       <br><br>
                    </div>
                    <div class="errorp1"></div>
                       <br>
                    <div class="FLXRIGHT">
                        <button id="passc" class="btn btn-primary">RESET</button>
                    </div>
                    <br>
                    <div class="FLXCENTER">
                        <p onclick="FRGTINSNETW()" style="text-decoration:underline;">Return to Sign in</p>
                    </div>
                </div>
                </div>
                </div>
                <div id="get_change_form" style="display:none;">
                    <div class="product-card" tabindex="0">
                  <div class="card-content">
                    <div class="newsletter-form">
                       <input type="text" name="text" required placeholder="Enter OTP" id="frgtpass_otp" class="newsletter-input">
                       <br><br>
                <input type="password" name="password" required placeholder="Enter Password" id="frgtpass_password" class="newsletter-input">
                       <br><br>
                <input type="password" name="password" required placeholder="Comform Password" id="frgtpass_conform_password" class="newsletter-input">
                       <br><br>
                        <div class="flex2cntg">
                          <input type="checkbox" style="width:auto" name="showPassword3" id="showPassword3"> Check password
                      </div>
                      <br>
                    </div>
                    <span style="cursor: pointer;" id="fgt_time_b"><span id="countdown_fgt"></span></span>
                    <br>
                    <div class="errorp1"></div>
                       <br>
                    <div class="FLXRIGHT">
                        <button id="pass_c_f" class="btn btn-primary">CHANGE PASSWORD</button>
                    </div>
                    <br>
                    <div class="FLXCENTER">
                        <p onclick="FRGTINSNETW()" style="text-decoration:underline;">Return to Sign in</p>
                    </div>
                </div>
                </div>
                </div>
            </div>
        </div>
      </section>
      </div>
      </div>
</div>
</div>
   <section class="section service disnoneftp">
 <div class="container" id="blog">
        <div class="special container">
        <h2 class="h2 section-title">
              <span class="text">Latest From us</span>

              <span class="line"></span>
              <span class="text"><a href="/blog/">Show more</a></span>
            </h2>
        </div>
    <div class="grid_blg">
        <div>
            <div class="imgblg">
                <a><img src="https://i0.wp.com/www.itscasualblog.com/wp-content/uploads/2023/05/unnamed-6.jpg?resize=1152%2C1536&ssl=1" /></a>
                <div class="getblginfo">
                <h4><a>Our Latest Products</a></h4>
            </div>
            </div>
        </div>

        <div>
            <div class="imgblg">
                <a><img src="https://i0.wp.com/www.itscasualblog.com/wp-content/uploads/2024/02/20230319_dana_soho-5449-2-scaled.jpg?resize=1024%2C1536&ssl=1" /></a>
                <div class="getblginfo">
                <h4><a>3 Words To Describe Your Style</a></h4>
            </div>
            </div>
        </div>

        <div>
            <div class="imgblg">
                <a><img src="https://images.pexels.com/photos/4350202/pexels-photo-4350202.jpeg?auto=compress&cs=tinysrgb&w=600" /></a>
                <div class="getblginfo">
                <h4><a>How To Put Together A Cool Corporate Outfit</a></h4>
            </div>
            </div>
        </div>
    </div>
</div>
</section>
   <section class="section service disnoneftp">
        <div class="container">

          <ul class="service-list">

            <li class="service-item">
              <div class="service-card">

                <div class="card-icon">
                  <ion-icon name="cart-outline"></ion-icon>
                </div>

                <div>
                  <h3 class="h4 card-title">Free Shiping</h3>

                  <p class="card-text">
                    All orders over <span>₹1999</span>
                  </p>
                </div>

              </div>
            </li>

            <li class="service-item">
              <div class="service-card">

                <div class="card-icon">
                  <ion-icon name="cash-outline"></ion-icon>
                </div>

                <div>
                  <h3 class="h4 card-title">Quick Payment</h3>

                  <p class="card-text">
                    100% secure payment
                  </p>
                </div>

              </div>
            </li>

            <li class="service-item">
              <div class="service-card">

                <div class="card-icon">
                  <ion-icon name="return-down-back-outline"></ion-icon>
                </div>

                <div>
                  <h3 class="h4 card-title">Free Returns</h3>

                  <p class="card-text">
                    Money back in 30 days
                  </p>
                </div>

              </div>
            </li>

            <li class="service-item">
              <div class="service-card">

                <div class="card-icon">
                 <ion-icon name="headset-outline"></ion-icon>
                </div>

                <div>
                  <h3 class="h4 card-title">24/7 Support</h3>

                  <p class="card-text">
                    Get Quick Support
                  </p>
                </div>

              </div>
            </li>

          </ul>

        </div>
      </section>


            <subscribe class="disnoneftp">
                <div class="subscribef">
                    <div class="subform">
                        <h1>GET THE NEWSLETTER</h1>
                        <p style="margin: 20px;">Sign up now</p>
                        <form action="" class="newsletter-form">
              <input type="email" name="email" required="" placeholder="Email Address" class="newsletter-input">

              <button type="submit" class="btn btn-primary">Subscribe</button>
            </form>
                    </div>
                </div>
            </subscribe>
            
    <footer class="disnoneftp">
            <div class="fcgrid">
                <div>
                    <h1><a href="https://www.ruluka.com/">RULUKA</a></h1>
                </div>
                <div class="links" style="margin-left: auto;">
                    <a href="https://www.linkedin.com/" target="_blank" class="fa fa-brands fa-linkedin"></a>
                    <a href="https://www.instagram.com/" target="_blank" class="fa fa-brands fa-instagram"></a>
                </div>
            </div>
            <div class="footerc">
                <div class="gridsecf">
                    <div><a>Privacy policy</a></div>
                    <div><a>Refund policy</a></div>
                    <div><a>Website policy</a></div>
                    <div><a>Contact us</a></div>
                </div>
                <div class="gridsecf">
                    <div><a href="/shop">Shop</a></div>
                    <div><a href="/collections/men">Men</a></div>
                    <div><a href="/collections/men">Women</a></div>
                    <div><a href="/about">About us</a></div>
                </div>
                <div class="gridsecf">
                    <div><a href="/profile">My account</a></div>
                    <div><a href="/collections/men">Favorates</a></div>
                    <div><a href="/collections/men">Cart</a></div>
                </div>
            </div>
            <div class="copyright">
                Ruluka &copy; 2024 All rights reserved
            </div>
        </footer>
  <a href="#top" class="go-top-btn" data-go-top>
    <ion-icon name="arrow-up-outline"></ion-icon>
  </a>
  <script src="/styles/js/scriptq11.js"></script>
  <script src="/styles/js/maint1rans11.js"></script>
  <script src="/styles/js/main_999999111.js"></script>
  <script src="/styles/js/sahgtylogsfgawsupsaarteewrmpl1.js"></script>
    <script>
 function isMobileDevice() {
    return /Mobi|Android|iPhone|iPad|iPod|Windows Phone|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

      function brwsrdimns() {
    var browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight, browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    browserHeight = browserHeight > 1000 ? 1000 : browserHeight > 800 ? 800 : browserHeight < 600 ? 600 : browserHeight;
    browserHeight = browserHeight - 90;
    if (browserWidth <= 300) {
        $(".SDFDRUADS1, #srhheightmtmp").css("height","300px");
    }else {
    $(".SDFDRUADS1, #srhheightmtmp").css("height",browserHeight+"px");
    }
    if (browserWidth >= 600) {
        $(".SDFDRUADS").css("height",browserHeight+"px");
    } else {
        $(".SDFDRUADS").css("height","auto");
    }
}
brwsrdimns();
$("#mensectionbtn").click(function () {
    $("#womensectionbtn").removeClass("rotate");
    $("#womensectiontop").slideUp().promise().done(() => {
    $("#search").slideUp().promise().done(() => {
        $("#mensectionbtn").toggleClass("rotate");
        $("#mensectiontop").slideToggle();
    });
    });
});

$("#womensectionbtn").click(function () {
    $("#mensectionbtn").removeClass("rotate");
    $("#mensectiontop").slideUp().promise().done(() => {
        $("#search").slideUp().promise().done(() => {
        $("#womensectionbtn").toggleClass("rotate");
        $("#womensectiontop").slideToggle();
        });
    });
});

var imgprdclt = 1;
function changeclr(num) {
    if (num != imgprdclt) {
        let images = ["./images/blue.png", "./images/red.png", "./images/golden.png", "./images/black.png"];
        if (num >= 1 && num <= images.length) {
            imgprdclt = num;
            $("#prdimgclr").fadeOut(250, function () {
                $(this)
                    .attr("src", images[num - 1])
                    .fadeIn(250);
            });
        }
    }
}
var imgn = 1;
function changeImage(num) {
    if (num != imgn) {
        let images = ["./images/blue.png", "./images/golden.png", "./images/black.png", "./images/copy-of-grp.png"];
        if (num >= 1 && num <= images.length) {
            imgn = num;
            $("#imgsecv").fadeOut(250, function () {
                $(this)
                    .attr("src", images[num - 1])
                    .fadeIn(250);
            });
        }
    }
}
function opennav() {
    $("nav").css("display", "block");
    setTimeout(() => $("nav").addClass("open"), 10);
    $("#sideclose").show();
}

function closenav() {
    $("nav").removeClass("open");
    setTimeout(() => $("nav").css("display", "none"), 500);
    $("#sideclose").hide();
}
var browserHeight = $(window).height(), browserWidth = $(window).width();
    $("#srhheightmtmp").height(browserHeight - 90);
    console.log(1);
function resize(){
    var height = (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth);
     var browserHeight = $(window).height(), browserWidth = $(window).width();
    $("#srhheightmtmp").height(browserHeight - 90);
    $("nav").css("height", (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) + "px");
    $(".bfrntsec").css("height", (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) -92 + "px");
    $(".bmr_imgtop_drpd").css("height", (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) -195 + "px");
    if(height >= '768'){
        closenav();
    }
    if(height <= '768'){
        $("#mensectionbtn").removeClass("rotate");
        $("#mensectiontop").slideUp();
        $("#womensectionbtn").removeClass("rotate");
        $("#womensectiontop").slideUp();
    }
}

$(window).resize(function () {
    resize();
});
resize();
  </script>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-7PX2FN11PP"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-7PX2FN11PP');
</script>
