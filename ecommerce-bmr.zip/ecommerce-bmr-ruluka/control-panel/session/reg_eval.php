<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));

function generateRandomString($length) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return substr(str_shuffle($characters), 0, $length);
}

function generateToken($otp) {
    return md5(time()) . md5(sha1($otp));
}

function generateOTP() {
    return rand(100000, 999999);
}

function generateReferralCode($conn) {
    do {
        $code = generateRandomString(3) . random_int(10, 99) . generateRandomString(3) .random_int(1, 9). generateRandomString(1) .random_int(100, 999);
        $result = $conn->query("SELECT uid_slk_v2 FROM users_da_f_s WHERE uid_slk_v2 = '$code'");
    } while ($result->num_rows > 0);
    return $code;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['sessss_tkn_sec_reg_pk_ww_ww']) && $_SESSION['sessss_tkn_sec_reg_pk_ww_ww'] != '' && isset($_POST['sssadsadawewwdcassdsd'])) {
    $tkn = $_SESSION['sessss_tkn_sec_reg_pk_ww_ww'];
    $otp = $_POST['sssadsadawewwdcassdsd'];
    $regexPatterntkn = '/[a-f0-9]/';
    $regexPatternotp = '/^\d{6}$/';
    $sixdigit = preg_match($regexPatternotp, $otp);
    $tknMatch = preg_match($regexPatterntkn, $tkn);
    
    if (!$sixdigit) {
        echo 4;
        exit();
    }
    if (!$tknMatch) {
        echo 4;
        exit();
    }
    if (empty($tkn) || empty($otp)) {
        echo 4;
        exit();
    }

    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($conn->connect_error) {
        echo 1;
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM register_det_lfs WHERE tkn_f10 = ? AND otp_info = ?");
    $stmt->bind_param("ss", $tkn, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $stmt = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
        $stmt->bind_param("s", $row['mail_id_slk']);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM register_det_lfs WHERE mail_id_slk='{$row['mail_id_slk']}'")) == 1) {
               $stmt19 = $conn->prepare("DELETE FROM register_det_lfs WHERE tkn_f10 = ? AND otp_info = ?");
               $stmt19->bind_param("ss", $tkn, $otp);
               $stmt19->execute();
               if ($stmt19->affected_rows > 0) { 
                $six_digit_random_number = generateReferralCode($conn);

                $Registered_on = date('Y-m-d h:i:s A');
                $time = date('Y-m-d H:i:s');
                $time11 = time();
                $mainName = substr($row['mail_id_slk'], 0, strpos($row['mail_id_slk'], "@"));
                $stmt = $conn->prepare("INSERT INTO users_da_f_s (mail_id_slk, uid_slk_v2, Registered_on, passwrd_id_slk, time_id,last_modif_date, disp_name_slk_dispn__) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssss", $row['mail_id_slk'], $six_digit_random_number, $Registered_on, $row['passwrd_id_slk'], $row['time_id'], $Registered_on, $mainName);
                $stmtba = $conn->prepare("INSERT INTO billing_address__f__ (mail_id_slk, uid_slk_v2) VALUES (?, ?)");
                $stmtba->bind_param("ss", $row['mail_id_slk'], $six_digit_random_number);
                $stmtsa = $conn->prepare("INSERT INTO shipping__address__f__ (mail_id_slk, uid_slk_v2) VALUES (?, ?)");
                $stmtsa->bind_param("ss", $row['mail_id_slk'], $six_digit_random_number);
                $client_info_for_log = $device_platform.' '.$device_type.' '.$id.' '.$Operating_system.' '.$Browser.' '.$client.' '.$row_api['regionName'].' '. $row_api['city'].' '.$row_api['country'];
                
                $stmtd = $conn->prepare("INSERT INTO register_log (mail_id_slk, uid_no__f__, Registered_on, time_id, ip, client_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmtd->bind_param("ssssss", $row['mail_id_slk'], $six_digit_random_number, $Registered_on, $time, $id, $client_info_for_log);
                $stmtd->execute();
                if ($stmt->execute() && $stmtba->execute() && $stmtsa->execute()) {
                    $tkn = md5(time()) . md5($row['mail_id_slk']);

                   $stmt1 = $conn->prepare("INSERT INTO live_session_access (eml_usr_f_,sess__id__bycpt,uid_no__f__,registration_date,time_id,device_platform__sqw3_,device_type,ip_address__fg__,operating_system__,browser__info__,client_id__info,region_p,city_p,country_p,acc_stus) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'yes')");
                    $stmt1->bind_param("ssssssssssssss", $row['mail_id_slk'],$tkn,$six_digit_random_number,$Registered_on,$time,$device_platform,$device_type,$id,$Operating_system,$Browser,$client,$row_api['regionName'], $row_api['city'],$row_api['country']);
                    
                    if ($stmt1->execute()) {
                        $_SESSION['sessss_id_sec_newt_k_sa_sa'] = $tkn;
                        echo 'success';
                    } else {
                        echo 7;
                    }
                } else {
                    echo 7;
                }
                
            } else {
                    echo 7;
                }
            } else {
                echo 3;
            }
        } else {
            echo 9;
        }
    } else {
        echo 2;
    }
    $conn->close();
} else {
    echo 3;
    exit();
}
?>