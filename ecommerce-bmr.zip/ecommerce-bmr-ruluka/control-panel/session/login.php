<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client)); 
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['password'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    if (empty($email) || empty($password)) {
        echo 4;
        exit();
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mssg = 2;
    } else {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
        if (!$conn) {
            $mssg = 2;
        } else {
            $stmt = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                if (password_verify($password, $row['passwrd_id_slk'])) {
                    $tkn = md5(time() . $row['mail_id_slk']) . md5($row['mail_id_slk']);
                    $stmt1 = $conn->prepare("INSERT INTO live_session_access (eml_usr_f_,sess__id__bycpt,uid_no__f__,registration_date,time_id,device_platform__sqw3_,device_type,ip_address__fg__,operating_system__,browser__info__,client_id__info,region_p,city_p,country_p,acc_stus) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'yes')");
                    $stmt1->bind_param("ssssssssssssss", $row['mail_id_slk'],$tkn,$row['uid_slk_v2'],$Registered_on,$time,$device_platform,$device_type,$id,$Operating_system,$Browser,$client,$row_api['regionName'], $row_api['city'],$row_api['country']);
                    if ($stmt1->execute()) {
                        $_SESSION['sessss_id_sec_newt_k_sa_sa'] = $tkn;
                        $mssg = 'success';
                    } else {
                        $mssg = 2;
                    }
                } else {
                    $mssg = 2;
                }
            } else {
                $mssg = 2;
            }
            $conn->close();
        }
    }
    echo $mssg;
} else {
    echo 2;
}
?>
