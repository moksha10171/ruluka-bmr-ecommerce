<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));

function generateRandomString($length) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return substr(str_shuffle($characters), 0, $length);
}

function generateToken($otp) {
    return md5(time()) . md5(sha1($otp));
}

function generateOTP() {
    return rand(100000, 999999);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && isset($_POST['input1val']) && isset($_POST['input2val']) && isset($_POST['input3val']) && isset($_POST['input4val']) && isset($_POST['input5val']) && isset($_POST['input6val']) && isset($_POST['input7val']) && isset($_POST['input8val'])) {
    $input1val = $_POST['input1val'];
    if($_POST['input2val'] ==''){
        $input2val = ' ';
    } else {
    $input2val = $_POST['input2val'];
    }
    $input3val = $_POST['input3val'];
    $input4val = $_POST['input4val'];
    $input5val = $_POST['input5val'];
    $input6val = $_POST['input6val'];
    $input7val = $_POST['input7val'];
    $input8val = $_POST['input8val'];

    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($conn->connect_error) {
        echo 1;
        exit();
    }
    $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
            $stmt2 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
            $stmt2->bind_param("s", $row['eml_usr_f_']);
            $stmt2->execute();
            $result2 = $stmt2->get_result();
            if ($result2->num_rows > 0) {
                $row2 = $result2->fetch_assoc();
               $stmt4 = $conn->prepare("UPDATE shipping__address__f__ SET first_name_slk__ = ?, last_name_slk = ?, company_name = ?, country__f_ = ?, street_address_ = ?, town__city__=?, state=?, pin_code=?, last_modif_date=? WHERE mail_id_slk = ?");
               $stmt4->bind_param("ssssssssss", $input1val, $input2val, $input3val, $input4val, $input5val, $input6val, $input7val, $input8val, $Registered_on, $row['eml_usr_f_']);
               $stmt4->execute();
               if ($stmt4->affected_rows > 0) {
                   if($row2['shipp_addr_slk'] == 'no'){
                   $valok='yes';
                   $stmt5 = $conn->prepare("UPDATE users_da_f_s SET shipp_addr_slk = ? WHERE mail_id_slk = ?");
               $stmt5->bind_param("ss", $valok, $row['eml_usr_f_']);
               $stmt5->execute();
               if ($stmt5->affected_rows > 0) {
                    echo 'success';
               }else {
                     echo 3;
                }
                   } else {
                     echo 'success';
                }
                
                } else {
                     echo 3;
                }
                
            } else {
                 echo 2;
            }
    } else {
        echo 2;
    }
    $conn->close();
} else {
    echo 3;
    exit();
}
?>