<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('d-m-Y H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email_gh']) && isset($_POST['password_ijj'])) {
    $email = filter_var($_POST['email_gh'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password_ijj'];

    if (!$email || empty($password)) {
        echo 5;
        exit();
    }

    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 1;
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo 8;
        exit();
    }
    
    $stmt = $conn->prepare("DELETE FROM register_det_lfs WHERE mail_id_slk = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    
    function generateRandomString($length) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        return substr(str_shuffle($characters), 0, $length);
    }

    function generateToken($email) {
        return md5(time()) . md5($email);
    }

    function generateOTP() {
        return rand(100000, 999999);
    }

    function generateMailID() {
        return random_int(1, 9) . generateRandomString(3) . random_int(10, 99) . generateRandomString(1) . random_int(10, 99) . generateRandomString(2) . random_int(10, 99);
    }

    $tkn = generateToken($email);
    $otp = generateOTP();
    $mail_id = generateMailID();

    $sql = "INSERT INTO register_det_lfs (mail_id_slk, Registered_on, passwrd_id_slk, tkn_f10, otp_info, time_id, mail_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt1 = $conn->prepare($sql);
    $stmt1->bind_param("sssssss", $email, $Registered_on, $hashedPassword, $tkn, $otp, $time, $mail_id);

    if ($stmt1->execute()) {
        $_SESSION['sessss_tkn_sec_reg_pk_ww_ww'] = $tkn;
    } else {
        $error_message = "Error executing SQL statement: " . $stmt1->error;
        error_log($error_message);
        echo 3;
        exit();
    }

    $conn->close();
} else {
    echo 3;
    exit();
}
      
require '../../vendor1/autoload.php';
 
use PHPMailer\PHPMailer\PHPMailer;
   
$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Host = 'smtp.hostinger.com';
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = 'login@bmreducation.com';
$mail->Password = 'Moksha@10171+10170';
$mail->setFrom('login@bmreducation.com', 'RULUKA');
$mail->addAddress($email);
$mail->isHTML(true); 
$mail->Subject = $otp.' - OTP for your Sign up';
$mail->Body = 
'<div style="background-color:whitesmoke;color:rgb(7, 6, 1);border-radius:20px;border:2px solid rgb(7, 6, 1);">
    <div style="margin:2%;">
    <div style="float:left;width:100%;">
    <div style="float:right;width:30%;text-align:right">
        <img src="https://blog.bmreducation.com/project/bglogo.png" width="80px" height="40px" style="margin:7.5px;">
        </div>
        <div style="float:left;width:70%;">
        <h2>Welcome to <span style="color:rgb(7, 6, 1);">RULUKA</span></h2>
        </div>
        </div>
         <p>Thank you for comming to ruluka. You are one step away for completing your sign up.</p>
         <p>Here is the OTP for verifying your account and complete your sign up.</p><br>
         <div style="text-align:center;padding:12px;border-radius:10px;background-color:whitesmoke;color:rgb(7, 6, 1);border:2px solid rgb(7, 6, 1);">
            <b>'.$otp.'</b>
        </div><br>
        <div style="border:2px solid rgb(7, 6, 1);background:rgb(7, 6, 1);"></div>
        <div style="font-size:14px;text-align: center;">
            <a href="https://blog.bmreducation.com/project/" style="color:rgb(7, 6, 1) !important;text-decoration:none;">ruluka.com</a> | 
            <a href="https://blog.bmreducation.com/project/terms-and-conditions" style="color:rgb(7, 6, 1)!important;text-decoration:none;">Terms and Conditions</a> | 
            <a href="https://blog.bmreducation.com/project/privacy-policy" style="color:rgb(7, 6, 1) !important;text-decoration:none;">Privacy policy</a><br><br>
            <p>Mail id: '.$mail_id.'</p>
        </div>
    </div>
</div>';
if (!$mail->send()) {
    $error_message = "Error sending email: " . $mail->ErrorInfo;
    error_log($error_message);
    echo 3;
} else {
    echo 'success';
}
?>