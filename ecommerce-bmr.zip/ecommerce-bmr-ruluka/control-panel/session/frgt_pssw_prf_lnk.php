<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
$ist_zone = new DateTimeZone('Asia/Kolkata');
$date = new DateTime('now', $ist_zone);
$Registered_on = $date->format('Y-m-d H:i:s');
$client = $_SERVER['HTTP_USER_AGENT'];
$Operating_system = explode(";", $client)[1] ?? "";
$Browser = end(explode(" ", $client));
$id = $_SERVER['REMOTE_ADDR'];
$time = time();

$data_api = file_get_contents("http://ip-api.com/json/{$id}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,currency,isp,org,as,query");
$row_api = json_decode($data_api, true);

$isMob = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile"));
$isTab = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "tablet"));
$isWin = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "windows"));
$isAndroid = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "android"));
$isIPhone = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "iphone"));
$isIPad = is_numeric(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "ipad"));
$isIOS = $isIPhone || $isIPad;

$device_platform = $isMob ? ($isTab ? 'Tablet' : 'Mobile') : 'Desktop';
$device_type = $isIOS ? 'iOS' : ($isAndroid ? 'ANDROID' : ($isWin ? 'WINDOWS' : 'OTHER'));

function generateRandomString($length) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return substr(str_shuffle($characters), 0, $length);
}

function generateToken($otp) {
    return md5(time()) . md5(sha1($otp));
}

function generateOTP() {
    return rand(100000, 999999);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_POST['newthjsnsaergjeaasdwsa']) && !empty($_POST['ssoolsdfaskenrewerer']) && isset($_POST['newthjsnsaergjeaasdwsa']) && isset($_POST['ssoolsdfaskenrewerer'])) {
    $oldhashedpass = password_hash($_POST['newthjsnsaergjeaasdwsa'], PASSWORD_BCRYPT);
    $hashedPassword = password_hash($_POST['ssoolsdfaskenrewerer'], PASSWORD_BCRYPT);

    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($conn->connect_error) {
        echo 1;
        exit();
    }
    $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
            $stmt2 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
            $stmt2->bind_param("s", $row['eml_usr_f_']);
            $stmt2->execute();
            $result2 = $stmt2->get_result();
            if ($result2->num_rows > 0) {
                $row11 = $result2->fetch_assoc();
                if(password_verify($_POST['newthjsnsaergjeaasdwsa'], $row11['passwrd_id_slk'])){
               $stmt4 = $conn->prepare("UPDATE users_da_f_s SET passwrd_id_slk = ?, last_modif_date = ? WHERE mail_id_slk = ?");
               $stmt4->bind_param("sss", $hashedPassword, $Registered_on, $row['eml_usr_f_']);
               $stmt4->execute();
               if ($stmt4->affected_rows > 0) { 
                    echo 'success';
                } else {
                     echo 1;
                }
                } else {
                 echo "sas".$oldhashedpass;
            }
            } else {
                 echo $oldhashedpass;
            }
    } else {
        echo 2;
    }
    $conn->close();
} else {
    echo 3;
    exit();
}
?>