<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    echo '<article id="mainsectionarticle">
                    <ul class="filter-list">
                    <li>
              <button class="filter-btn active">Dashboard</button>
            </li>

            <li>
              <button class="filter-btn">Orders</button>
            </li>

            <li>
              <button class="filter-btn">Addresses</button>
            </li>
            <li>
              <button class="filter-btn">Addresses</button>
            </li>
            <li>
              <button class="filter-btn">Account</button>
            </li>
            <li>
              <a href="/project/profile/logout" class="filter-btn">Logout</a>
            </li>
          </ul>
                    <div class="container">
            <section class="section special prf_top">
                    <div class="special-product">
                        <h2 class="h2 section-title">
                            <span class="text">MY ACCOUNT</span>
                            <span class="line"></span>
                        </h2>
                    </div>
                </div>
            </section>
        </article>';
                }
            }
        }
        $conn->close();
    }
}
?>