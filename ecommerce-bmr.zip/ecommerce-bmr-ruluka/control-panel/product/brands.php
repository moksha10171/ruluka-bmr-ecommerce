<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mysqli = new mysqli("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($mysqli->connect_errno) {
        $x = '<section class="section end product" style="padding:0;">
        <div class="container">
          <div>
           <div class="cta-card SDFDRUADS1" style="background-image: url(\'/images/brands_d_img.jpeg\');min-height: 400px;">
           <h2 class="h2 section-title" style="height: 100%;display: flex;align-items: center;justify-content: center;background: #3c3c3c70;"><div style="color: var(--smoky-white);padding: 15px;border-bottom: 2px solid;">BRANDS</div></h2>
              </div>
             </div>
        <ul class="product-list">';
    } else {
        $query = "SELECT * FROM brands__list_f_f";
        $result = $mysqli->query($query);

        if ($result) {
            $x = '<section class="section end product" style="padding:0;">
        <div class="container">
          <div>
           <div class="cta-card SDFDRUADS1" style="background-image: url(\'/images/01g8073z8qf3ymd22c5f05wvrj.jpg\');min-height: 400px;">
           <h2 class="h2 section-title" style="height: 100%;display: flex;align-items: center;justify-content: center;background: #3c3c3c70;"><div style="color: var(--smoky-white);padding-block: 15px;border-bottom: 2px solid;">BRANDS</div></h2>
              </div>
             </div>
        <ul class="product-list">';

            while ($row = $result->fetch_assoc()) {
                $name = htmlspecialchars($row['name']);
                $image_url = htmlspecialchars($row['img_url']);
                $url = htmlspecialchars($row['base_n_as_by_n']);

                $x .= '<li><a href="' . $url . '"><div class="collection-card r">
                  <div class="FLXCENTER" style="align-items: center;height: 100%;">
                     <img src="'.$image_url.'" alt="' . $name . '">
                </div>
            </div></a></li>';
            }

            $x .= '</ul>
                    </div>
                </section>';
            
            $result->free();
        } else {
            $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Server is busy Right now. Try again Later</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
        }
        echo $x;
        $mysqli->close();
    }
}