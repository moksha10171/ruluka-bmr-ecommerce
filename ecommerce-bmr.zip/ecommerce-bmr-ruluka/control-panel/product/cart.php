<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
    $token = $_SESSION['sessss_id_sec_newt_k_sa_sa'];

    $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['acc_stus'] == 'no') {
            $stmt1 = $conn->prepare("UPDATE live_session_access SET acc_stus='yes' WHERE sess__id__bycpt = ?");
            $stmt1->bind_param("s", $token);
            $stmt1->execute();

            if ($stmt1->affected_rows > 0) {
               $getloadsec = 'onclick="STORINSNETW()"';
            }
        } else {
            $getloadsec = 'onclick="STORINSNETW()"';
        }
    } else {
        $getloadsec = 'onclick="BLOGINSNETW()"'; 
    }
} else{
    $getloadsec = 'onclick="BLOGINSNETW()"'; 
}
        $json_data = $_POST['DBFAVLCLB'];
        $data_array = json_decode($json_data, true);

        if ($data_array !== null) {
            $x = '<section class="section product">
                    <div class="container">
                        <h2 class="h2 section-title">FAVOURITES</h2>
                        <ul class="filter-list">
                            <ul class="product-list">';

            foreach ($data_array as $item) {
                $data = $item['data'];
                $query = "SELECT * FROM prouduct_section_1 WHERE prd_id = ?";
                $stmt = $mysqli->prepare($query);

                if ($stmt) {
                    $stmt->bind_param("s", $data);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $cnt++;
                            $row = array_map('htmlspecialchars', $row);

                            $x .= '<div class="product-card" tabindex="0">
                                           <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                                        <div class="card-content">
                                            <h3 class="h3 card-title">
                                                <a href="/products/?id=' . $row['prd_id'] . '">'.$row['name'].'</a>
                                            </h3>
                                            <a href="/products/?id=' . $row['prd_id'] . '" class="card-price" value="'.$row['price_f'].'">'.$row['price_f'].'</a>
                                        </div>
                                    </div>';
                        }
                    }
                    $result->free();
                    $stmt->close();
                }
            }

            $x .= '</ul></div></section>';
            echo $x;
        }

        if ($cnt == 0) {
            echo '<section class="section special">
                    <div class="container chkout r" id="MAINSECHEI">
                        <div class="secdiv">
                            <h3 class="h3">SHOPPING BAG</h3>
                            <div class="BRDCHK00">
                                <p>There\'s nothing in your bag right now.<br>
                                <span onclick="fhcfile(\'shop\');" style="text-decoration: underline;">Let\'s find something!</span></p>
                            </div>
                        </div>
                        <div class="secdiv">
                            <h3 class="h3">SUMMARY</h3>
                            <div class="BRDCHK00">
                                <div class="container chkout" style="padding-block: var(--margin);">
                                    <p>SUBTOTAL</p>
                                    <p>---</p>
                                </div>
                                <div class="container chkout" style="padding-block: var(--margin);">
                                    <p>SHIPPING</p>
                                    <p>Calculated at checkout</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>';
        }
    }
} else {
    echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
}
?>