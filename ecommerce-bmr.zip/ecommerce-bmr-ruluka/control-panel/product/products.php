<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
$referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/influencers/') === 0) {
    $basePath = basename($urlComponents['path']);
    $basePath = preg_replace('/\\.[^.\\s]{3,4}$/', '', $basePath);
} else {
    echo 400;
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_follower = json_decode($row1['live_follower_list'], true);
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                    if ($json_data_loid === null) {
                        $json_data_loid = [];
                    }
                    if ($json_data_follower === null) {
                        $json_data_follower = [];
                    }
                    if ($json_data_fav === null) {
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
         $stmtc = $conn->prepare("SELECT * FROM creator_list WHERE base_n_as_by_n=?");
        $stmtc->bind_param('s', $basePath);
        $stmtc->execute();
        $resultc = $stmtc->get_result();
        if ($resultc->num_rows > 0) {
            $rowc = $resultc->fetch_assoc();
            $name = htmlspecialchars($rowc['name']);
            $image_url = htmlspecialchars($rowc['imag_url']);
            $url = htmlspecialchars($rowc['url']);
        }else {
            echo 400;
            $conn->close();
            exit();
        }
        if ($getlc == 1) {
        if (in_array($rowc['crt_id'], $json_data_follower)) {
            $addfggg = 'onclick="FOLLINFLUENCLISTRA(\''. $rowc['crt_id'] . '\')" ';
                    $mbflclsac = 'active';
                    $mbfl = 'Following';
        } else {
            $mbfl = 'Follow';
            $addfggg = 'onclick="BLOGINSNETW()"';
        }
         }else {
            $mbfl = 'Follow';
            $addfggg = 'onclick="BLOGINSNETW()"';
        }
        
        $x =
            '<div class="FLXCENTER" style="border-bottom: var(--border-black);">
        <div>
                            <img src="' .
            $image_url .
            '" width="100" height="100" style="border-radius: 50%;margin-block: 20px;padding: 2px;border: var(--border-black);max-width: 300px;min-height: 150px;min-width: 150px;max-height: 300px;" loading="lazy" alt="' .
            $name .
            '" class="creator-banner image-contain">
                        <div class="FLXCENTER">
                        <div class="h6" style="padding:10px;" id="follwr_cc">' .
            $rowc['tot_al_followers_s__s'] .
            ' Followers</div>
                        </div>
                             <div class="FLXCENTER">
                        <div class="h2" style="padding:10px;">' .
            $name .
            '</div>
                        </div>
                        <div class="FLXCENTER">
            <ul class="filter-list">

            <li>
              <button class="filter-btn active" onclick="productsfetch()" id="infprodsec">Shop</button>
            </li>

            <li>
              <button class="filter-btn" onclick="postsfetch()"  id="infpostsec">Posts</button>
            </li>
             <li>
              <button '.$addfggg.' class="filter-btn FLOW'. $rowc['crt_id'] . ' '.$mbflclsac.'">'.$mbfl.'</button>
            </li>

          </ul>
          </div>
                        </div>
                        </div>
            ';
$stmt = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE crt_id=?");
        $stmt->bind_param('s',$rowc['crt_id']);
        $stmt->execute();
        $result = $stmt->get_result();
         if ($result->num_rows > 0) {
            $x .= '<section class="section special">
                    <div class="container">
                        <div class="special-product">
                            <ul class="has-scrollbar">';
            while ($row = $result->fetch_assoc()) {
                if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
                $x .= '<li class="product-item">
                            <div class="product-card" tabindex="0">
                                   <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                        <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
                            </div>
                        </li>';
            }
            $result->free();
            $x .= '</ul>
                    </div>
                </div>
            </section>';
        } else {
            $x = 400;
        }
        echo $x;
        $conn->close();
    }
}