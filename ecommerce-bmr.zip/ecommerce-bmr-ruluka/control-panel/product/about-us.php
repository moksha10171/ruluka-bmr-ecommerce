<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo '<section class="section end product" style="padding:0;">
        <div class="container">
          <div>
           <div class="cta-card SDFDRUADS1" style="background-image: url(\'/images/brands_d_img.jpeg\');min-height: 400px;">
           <h2 class="h2 section-title" style="height: 100%;display: flex;align-items: center;justify-content: center;background: #3c3c3c70;"><div><div style="color: var(--smoky-white);padding: 15px;border-bottom: 2px solid;">RULUKA</div><span style="padding: 15px;color: white;
    font-size: var(--fs-5);">Empowering Home-Grown Fashion Brands</span></div></h2>
              </div>
             </div>
        <div>
        <div style="padding:20px;margin:20px;background-color:#00000005;border-radius:24px;">
                     <div class="container">
                    <div style="padding-block: var(--section-padding);text-align: center;">
                        <h1 class="h2" style="margin-block: 20px;    width: 100%;
    justify-content: center;
    display: flex;"><div style="border-bottom: 2px solid;">OUR VISION</div></h1>
                    </div>
                </div>
                <div class="container">
                                               <p class="h5" style="font-weight:100;">
                        Ruluka is a pioneering platform designed to empower home-grown fashion brands, providing them with a dynamic stage to showcase their unique creations. Our platform merges the essence of Instagram with the functionality of popular e-commerce applications, creating a seamless space where influencers, brands, and fashion enthusiasts converge.
                    </p>
                    <br>
                    <p class="h5" style="font-weight:100;">
                        Ruluka encompasses essential features found in leading e-commerce platforms such as Myntra and Ajio, ensuring a familiar and intuitive user experience.
                    </p>
                </div>
                </div>
        <div class="dispgridourv">
        <div style="background-image: url(\'/images/joe-gardner-NorYfP4rwmQ-unsplash.jpg\');    background-size: cover;"></div>
        <div class="FLXCENTER"><div><h1 class="h2">Men\'s FASHION</h1>
        <p style="margin-block: 15px;">Explore all the mens fashion collections from us</p>
        <a href="/collections/men" class="btnd  blc">Shop Now <ion-icon name="arrow-forward-outline"></ion-icon></a>
        </div></div>
        </div>
        <div class="dispgridourv">
        <div class="FLXCENTER rtv"><div><h1 class="h2">Women\'s FASHION</h1>
        <p style="margin-block: 15px;">Explore all the womens fashion collections from us</p>
        <a href="/collections/women" class="btnd  blc">Shop Now <ion-icon name="arrow-forward-outline"></ion-icon></a>
        </div></div>
         <div style="background-image: url(\'/images/womens_fashions.jpg\');    background-size: cover;"></div>
        </div>
                <div class="dispgridourv">
        <div style="background-image: url(\'/images/01g8073z8qf3ymd22c5f05wvrj.jpg\');    background-size: cover;"></div>
        <div class="FLXCENTER"><div><h1 class="h2">BRANDS</h1>
        <p style="margin-block: 15px;">Explore all the fashion collections from our trusted brands</p>
        <a href="/brands" class="btnd  blc">More <ion-icon name="arrow-forward-outline"></ion-icon></a>
        </div></div>
        </div>
                </div>
            </div>
        </section>';
}
?>