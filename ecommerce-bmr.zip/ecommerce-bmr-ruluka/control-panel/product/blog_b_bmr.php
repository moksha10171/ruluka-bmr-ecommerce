<?php
#blog code by bmr developers - Limited use of tech - bmreducation.com 
echo '<div class="bfrntsec gg" id="srhheightmtmp" style="margin-bottom:20px;">
                <div class="bmr_mainsectl">
                    <div style="display: flex;min-height: 150px;align-items: flex-end;">
                <h1 class="bmr_title">Find out What new at Ruluka</h1>
                </div>
                    </div>
                </div>
            </div>';
            
            
            
    echo '      <div style="padding:20px;margin:20px;background-color:#00000005;border-radius:24px;">
                     <div class="container">
                    <div style="padding-block: var(--section-padding);text-align: center;">
                        <h1 class="h2" style="margin-block: 20px;    width: 100%;
    justify-content: center;
    display: flex;"><div style="border-bottom: 2px solid;">OUR BLOG</div></h1>
                    </div>
                </div>
                <div class="container">
                          <div class="container" id="blog">
    <div class="grid_blg">
        <div>
            <div class="imgblg">
                <a><img src="https://i0.wp.com/www.itscasualblog.com/wp-content/uploads/2023/05/unnamed-6.jpg?resize=1152%2C1536&ssl=1" /></a>
                <div class="getblginfo">
                <h4><a>Our Latest Products</a></h4>
            </div>
            </div>
        </div>

        <div>
            <div class="imgblg">
                <a><img src="https://i0.wp.com/www.itscasualblog.com/wp-content/uploads/2024/02/20230319_dana_soho-5449-2-scaled.jpg?resize=1024%2C1536&ssl=1" /></a>
                <div class="getblginfo">
                <h4><a>3 Words To Describe Your Style</a></h4>
            </div>
            </div>
        </div>

        <div>
            <div class="imgblg">
                <a><img src="https://images.pexels.com/photos/4350202/pexels-photo-4350202.jpeg?auto=compress&cs=tinysrgb&w=600" /></a>
                <div class="getblginfo">
                <h4><a>How To Put Together A Cool Corporate Outfit</a></h4>
            </div>
            </div>
        </div>
    </div>
</div>                     
                </div>
                </div>
';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                    if ($json_data_loid === null || $json_data_fav === null) {
                        $json_data_loid = [];
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
         $sql11 = "SELECT * FROM featured_listing_category";
        $result11 = mysqli_query($conn, $sql11);
        $row11 = mysqli_fetch_assoc($result11);
           if ($result11->num_rows > 0) {
               $x = '<section class="section collection">
        <div class="container">
        <div class="special container">
        <h2 class="h2 section-title">
              <span class="text">Our Collections</span>

              <span class="line"></span>
            </h2>
        </div>
          <ul class="collection-list">';
               while ($row11 = $result11->fetch_assoc()) {
    $x .= '<li>
              <a href="'.$row11['url'].'"><div class="collection-card" style="background-image: url(\''.$row11['img_url'].'\')">
                  <div class="FLXCENTER" style="align-items: center;height: 100%;">
                <h3 class="h4 card-title" style="color: var(--smoky-white);">'.$row11['title'].'</h3>
                </div>
              </div></a>
            </li>';
               }
                  $x.='
          </ul>

        </div>
      </section>';      
           }
           $result11->free();
$stmt = $conn->prepare("SELECT * FROM prouduct_section_1 LIMIT 10");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
    $x .= '<section class="section special">
        <div class="container spl_fld_ent">
          <div class="special-product">

            <h2 class="h2 section-title">
              <span class="text">JUST DROPPED</span>

              <span class="line"></span>
            </h2>

            <ul class="has-scrollbar">';
    while ($row = $result->fetch_assoc()) {
        if($row['prd_listing'] == 'N'){
        if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat FLXRIGHT">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat FLXRIGHT">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat FLXRIGHT">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
        $x .= '<li class="product-item">
                <div class="product-card" tabindex="0">

                  <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                  <div class="card-content">
                   <h5 class="h5 card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
                </div>
              </li>';
    }
    }
    $result->free();
    $x.='</ul>

          </div>

        </div>
      </section>';
} else {
    $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
}
echo $x;
$conn->close();
}
}
            ?>