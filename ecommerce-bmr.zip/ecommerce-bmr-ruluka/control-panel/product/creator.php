<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mysqli = new mysqli("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($mysqli->connect_errno) {
        $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        $query = "SELECT * FROM creator_list";
        $result = $mysqli->query($query);

        if ($result) {
            $x = '<section class="section creator">
                    <div class="container">
                        <h2 class="h2 section-title FLXCENTER">INFLUENCERS
                        </h2>
                        <ul class="creator-list has-scrollbar">';

            while ($row = $result->fetch_assoc()) {
                $name = htmlspecialchars($row['name']);
                $image_url = htmlspecialchars($row['imag_url']);
                $url = htmlspecialchars($row['url']);

                $x .= '<li>
                        <div class="creator-item">
                            <img src="' . $image_url . '" width="100" height="100" loading="lazy" alt="' . $name . '" class="creator-banner" style="border-radius: 50%;width: 100%;height: 100%;">
                            <div class="FLXCENTER"><a href="' . $url . '" class="creator-link">' . $name . '</a></div>
                        </div>
                        <div class="FLXCENTER">
                        <a href="' . $url . '" class="h2">' . $name . '</a>
                        </div>
                    </li>';
            }

            $x .= '</ul>
                    </div>
                </section>';
            
            $result->free();
        } else {
            $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
        }

        echo $x;
        $mysqli->close();
    }
}
?>