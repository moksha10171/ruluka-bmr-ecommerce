<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mysqli = new mysqli("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($mysqli->connect_errno) {
        $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        $query = "SELECT * FROM seller_list";
        $result = $mysqli->query($query);

        if ($result) {
            $x = '<section class="section creator">
                    <div class="container">
                        <h2 class="h2 section-title">
                            <span class="text">SELLERS</span>
                            <span class="line"></span>
                        </h2>
                        <ul class="creator-list has-scrollbar">';

            while ($row = $result->fetch_assoc()) {
                $name = htmlspecialchars($row['name']);
                $image_url = htmlspecialchars($row['imag_url']);
                $url = htmlspecialchars($row['url']);

                $x .= '<li class="FLXCENTER">
                        <div>
                        <div class="FLXCENTER" style="width:100%;text-align: center;">
                        <div class="creator-item" style="max-width: 250px;max-height: 250px;">
                            <img src="' . $image_url . '" loading="lazy" style="max-width: 250px;max-height: 250px;" alt="' . $name . '" class="creator-banner image-contain">
                            <a href="' . $url . '" class="creator-link">' . $name . '</a>
                        </div>
                        </div>
                        <div class="FLXCENTER">
                        <a href="' . $url . '" class="h4">' . $name . '</a>
                        </div>
                        </div>
                    </li>';
            }

            $x .= '</ul>
                    </div>
                </section>';
            
            $result->free();
        } else {
            $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Sellers</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
        }
        echo $x;
        $mysqli->close();
    }
}
?>