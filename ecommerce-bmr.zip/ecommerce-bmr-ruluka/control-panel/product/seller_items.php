<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
$referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/seller/') === 0) {
    $basePath = basename($urlComponents['path']);
    $basePath = preg_replace('/\\.[^.\\s]{3,4}$/', '', $basePath);
} else {
    echo 400;
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                     if ($json_data_loid === null) {
                        $json_data_loid = [];
                    }
                    if ($json_data_fav === null) {
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
        
         $stmtc = $conn->prepare("SELECT * FROM seller_list WHERE base_n_as_by_n=?");
        $stmtc->bind_param('s', $basePath);
        $stmtc->execute();
        $resultc = $stmtc->get_result();
        if ($resultc->num_rows > 0) {
            $rowc = $resultc->fetch_assoc();
            $name = htmlspecialchars($rowc['name']);
            $image_url = htmlspecialchars($rowc['imag_url']);
            $url = htmlspecialchars($rowc['url']);
        }else {
            echo 400;
            $conn->close();
            exit();
        }
        
       echo '<article>
    <section class="section product">
        <div class="container" id="articles">
        <div class="">
        <div class="prdo_drid1" style="margin:25px 0;">
        <div class="FLXCENTER">
        <img src="'.$rowc['imag_url'].'" width="100" height="100" style="height: 100%;width: 100%;max-width: 250px;max-height: 250px;" loading="lazy" alt="'.$name.'" class="creator-banner image-contain">
        </div>
        <div class="FLXCENTER">
        <div>
            <h3 class="h3 section-title FLXLEFT">'.$name.'</h3>
            <h5>'.$rowc['about'].'</h5>
            <br>
            <h5 class="prdo_drid" style="gap: 10px;"><div class="FLXLEFT" style="gap: 5px;"><ion-icon name="mail"></ion-icon><a style="color: black;" href="mailto:'.$rowc['email__s__d'].'" class="h5">'.$rowc['email__s__d'].'</a></div> 
            <div class="FLXLEFT" style="gap: 5px;"><ion-icon name="call"></ion-icon> '.$rowc['phone__s_a_ph'].'</div>
            <div class="FLXLEFT" style="gap: 5px;"><ion-icon name="location"></ion-icon> '.$rowc['location__s_f_'].'</div>
            <div class="FLXLEFT" style="gap: 5px;"><ion-icon name="information-circle-outline"></ion-icon> Seller ID: '.$rowc['sell_id'].' </div>
            <div class="FLXLEFT" style="gap: 5px;"><ion-icon name="star-outline"></ion-icon> '.$rowc['total_reviews'].' Ratings</div>
            </h5>
            <br>
            <h5 class="FLXLEFT" style="text-align: left;">
                                    <div style="width: 100%;">
                                    <div>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">5 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$rowc['star_r_5p'].'%"></span></span> '.$rowc['star_r_5'].'</h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">4 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$rowc['star_r_4p'].'%"></span></span>'.$rowc['star_r_4'].'</h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">3 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$rowc['star_r_3p'].'%"></span></span>'.$rowc['star_r_3'].'</h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">2 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$rowc['star_r_2p'].'%"></span></span>'.$rowc['star_r_2'].'</h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">1 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$rowc['star_r_1p'].'%"></span></span>'.$rowc['star_r_1'].'</h5>
                                    </div>
                                    </h5>
            <br>
            <h5><b>Shipping:</b> This products is Fulfilled by Ruluka and ships based on Ruluka Shipping Rates and Policies.</h5>
            <br>
            <h5><b>Return Policy:</b> Please refer to the Ruluka Return Policy.</h5>
            </div>
            </div>
        </div>
        </div>
    
        </div>
    </section>';

 $stmt1 = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE seller_id =?");
        $stmt1->bind_param('s', $rowc['sell_id']);
        $stmt1->execute();
    $result1 = $stmt1->get_result();
    if ($result1->num_rows > 0) {
    $y = '<section class="section end product" id="products">
        <div class="container">
          <div style="padding-bottom: 20px;">
           <h2 class="h2 section-title">
              <span class="text">Products</span>

              <span class="line"></span>
            </h2>
        <ul class="product-list">';
    while ($row = $result1->fetch_assoc()) {
 if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
        $y .= '<div class="FLXCENTER"><div class="product-card" tabindex="0">

                   <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
             <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
        </div></div>';
    }
    $result1->free();
    $y.='</ul>
    </div>
      </section>';
} else {
    $y ='<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
}
        echo $y;
        $conn->close();
    }
}