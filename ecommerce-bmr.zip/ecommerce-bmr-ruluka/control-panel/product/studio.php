<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
 $fgg = '<section class="section product">
                        <div class="container" id="MAINSECHEI">
                            <h2 class="h2 section-title">Network Error. Refresh the page</h2>
                                <div class="prdt_active_bo"><a href="" class="btn btn-primary"> REFRESH PAGE</a></div>
                        </div>
                    </section>';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u291518478_project1", "Moksha@10171", "u291518478_project1");
    if (!$conn) {
        echo $fgg;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_follower = json_decode($row1['live_follower_list'], true);
                    $json_data_like = json_decode($row1['live_like_list'], true);
                    $json_data_bookmark = json_decode($row1['live_bookmark_list'], true);
                    if ($json_data_follower === null) {
                        $json_data_follower = [];
                    }
                    if ($json_data_like === null) {
                        $json_data_like = [];
                    }
                    if ($json_data_bookmark === null) {
                        $json_data_bookmark = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'INFLUENCLISTRA()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
                $x = '<main>
        <div class="insta-con-tai-ner">
		<div class="insta-col--9">
		<div class="brd_tinsta">
			<div class="insta-us-er-De-tails brd_tinstaer">
			Follow our Top Influencers
			</div>
			<div class="insta-statu-ses">
		';
	       $stmtsd = $conn->prepare("SELECT * FROM creator_list LIMIT 20");
        $stmtsd->execute();
        $resultsd = $stmtsd->get_result();
    if ($resultsd->num_rows > 0) {
    while ($rowsd = $resultsd->fetch_assoc()) {
        $x .= '<div class="insta-sta-tus">
						<div class="insta-im-age">
							<a href="'.$rowsd['url'].'"><img src="'.$rowsd['imag_url'].'" alt="'.$rowsd['name'].'"></a>
						</div>
					</div>';
    }
    $resultsd->free();
}
$x.='</div></div>';

        $stmt1 = $conn->prepare("SELECT * FROM post_list LIMIT 10");
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        if ($result1) {
            while ($row1 = $result1->fetch_assoc()) {
                if ($getlc == 1) {
                    $getloadsec = 'INFLUENCLISTRA(\''. $row1['post_id'] . '\')';
                    $getloadsecf = 'INFLUENCLISTRA(\''. $row1['crt_id'] . '\')';
                }
                $getloadsecfoll = $getloadsec;
                $getloadseclike = $getloadsec;
                $getloadsecbook = $getloadsec;
                $getclassfollower = '';
                $getclassfollowertext = 'Follow';
                $getclasslike = '';
                $getclassbookmark = '';
                if($account_access == 1){
                $getloadsecfoll = 'FOLL'.$getloadsecf;
                $getloadseclike = 'LIKE'.$getloadsec;
                $getloadsecbook = 'BOOK'.$getloadsec;
                $value_to_check_follower = $row1['crt_id'];
                $value_to_check_like = $row1['post_id'];
                $value_to_check_bookmark = $row1['post_id'];
                if (in_array($value_to_check_follower, $json_data_follower)) {
                    $getclassfollower = 'active';
                    $getclassfollowertext = 'Following';
                }
                if (in_array($value_to_check_like, $json_data_like)) {
                    $getclasslike = 'active';
                }
                if (in_array($value_to_check_bookmark, $json_data_bookmark)) {
                    $getclassbookmark = 'active';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
                $x .=
                    '	<div class="card">
					<div class="insta-t-o-p">
						<div class="insta-us-er-De-tails">
							<div class="insta-pro-filepic">
								<div class="insta-pro-file_img">
									<div class="insta-im-age">
											<a href="'.$row1['crt_url'].'"><img src="' .
                    $row1['image_url'] .
                    '"
											alt="' .
                    $row1['creator'] .
                    '"></a>
									</div>
								</div>
							</div>
							<h3>' .
                    $row1['creator'] .
                    '
								<br>
								<span>' .
                    convertTime($row1['create_time']) .
                    '</span>
						</h3>
						<a onclick="'.$getloadsecfoll.'" class="FLOW'. $row1['crt_id'] . ' '.$getclassfollower.'" style="margin-left: auto;" class="h3">'.$getclassfollowertext.'</a>
				
						</div>
						<div>
							<span class="dot">
								<i class="fas fa-ellipsis-h"></i>
							</span>
						</div>
					</div>
					<div class="imgBx">
						<img src="' .
                    $row1['post_image'] .
                    '"
							alt="' .
                    $row1['creator'] .
                    '" class="insta-co-ver">
					</div>
					<div class="bottom">
						<div class="insta-ac-ti-onBtns">
							<div class="left FLXLEFT">
								<div onclick="'.$getloadseclike.'"> <ion-icon name="heart-outline" class="h2 heart '.$getclasslike.'" id="LIKE'.$row1['post_id'].'" aria-hidden="true"></ion-icon></div>
								 <div  onclick="shareLink(\''.$row1['post_url'].'\',\''.htmlspecialchars($row1['about']).'\',\''.$row1['post_url'].'\')">
								 <ion-icon name="share-social-outline" class="h2" aria-hidden="true"></ion-icon></div>
							</div>
							<div class="right" onclick="'.$getloadsecbook.'">
								 <ion-icon name="bookmark-outline" class="h2 book '.$getclassbookmark.'" id="BOOK'.$row1['post_id'].'" aria-hidden="true"></ion-icon>
							</div>
						</div>
						<div>
							<p class="likes" id="CLIKE'.$row1['post_id'].'">' .
                    $row1['likes'] .
                    ' likes</p>
						</div>
						<a>
							<p class="insta-mes-sage">
							<b>' .
                    $row1['about'] .
                    '</b>
							</p>
						</a>
					</div>
				</div>';
            }
            $result1->free();
        }
        $x .= '</div></main>';
        echo $x;
        $conn->close();
    }
}