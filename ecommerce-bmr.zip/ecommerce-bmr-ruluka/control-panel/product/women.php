<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                    if ($json_data_loid === null || $json_data_fav === null) {
                        $json_data_loid = [];
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
        $sql1 = "SELECT * FROM featured_listing_category WHERE id = 3 LIMIT 1";
        $result1 = mysqli_query($conn, $sql1);
        $row1 = mysqli_fetch_assoc($result1);
        
        $sql1f = "SELECT DISTINCT prd_type FROM prouduct_section_1 WHERE prd_gender='W' OR prd_gender='A'";
        $result1f = mysqli_query($conn, $sql1f);
        $getfl = '';
         while ($row1f = mysqli_fetch_assoc($result1f)) {
        $getfl .= '<div><input type="checkbox" onclick="filterProducts()" value="'.$row1f['prd_type'].'" data-filter-type="category"><h5>'.$row1f['prd_type'].'</h5></div>';
         }
         $sql1fb = "SELECT * FROM brands__list_f_f";
        $result1fb = mysqli_query($conn, $sql1fb);
        $getflb = '';
         while ($row1fb = mysqli_fetch_assoc($result1fb)) {
        $getflb .= '<div><input type="checkbox" onclick="filterProducts()" data-filter-type="brand" value="'.$row1fb['name__'].'"><h5>'.$row1fb['name__'].'</h5></div>';
         }
          $sql1fc = "SELECT DISTINCT color FROM prouduct_section_1";
        $result1fc = mysqli_query($conn, $sql1fc);
        $getflc = '';
         while ($row1fc = mysqli_fetch_assoc($result1fc)) {
        $getflc .= '<div><input type="checkbox" onclick="filterProducts()" value="'.$row1fc['color'].'" data-filter-type="color"><span class="cold" style="background-color:'.$row1fc['color'].';"></span><h5>'.$row1fc['color'].'</h5></div>';
         }
                 $referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/collections/women') === 0) {
        $stmt = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE prd_gender='W' OR prd_gender='A'");
        $stmt->execute();
        $result = $stmt->get_result();
} else{
     $stmt = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE prd_gender='W' OR prd_gender='A' LIMIT 4");
        $stmt->execute();
        $result = $stmt->get_result();
}
    if ($result->num_rows > 0) {
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/collections/women') === 0) {
    $x = '<section class="section end product" style="padding: 0px;">
        <div class="container">
          <div style="padding-bottom: 20px;">
           <div class="cta-card SDFDRUADS1" style="background-image: url(\''.$row1['img_url'].'\');min-height: 400px;">
           <h2 class="h2 section-title" style="height: 100%;display: flex;align-items: center;justify-content: center;background: #3c3c3c70;"><div style="color: var(--smoky-white);padding-block: 15px;margin: 10px;border-bottom: 2px solid;">WOMEN\'S FASHION</div></h2>
              </div>
             </div>
        <div class="filsec">
        <div id="fitlters">
        <h3 class="h3">Filters</h3>
        <br>
        <h5 class="h4">Categories</h5>
        <div class="collectfil">
        '.$getfl.'
        </div>
        <h5 class="h4">Brands</h5>
        <div class="collectfil">
        '.$getflb.'
        </div>
        <h5 class="h4">Price</h5>
        <div class="collectfil">
        <div><input type="checkbox" onclick="filterProducts()" data-filter-type="price" value="r1"><h5>₹0 - ₹500</h5></div>
        <div><input type="checkbox" onclick="filterProducts()" data-filter-type="price" value="r2"><h5>₹500 - ₹1000</h5></div>
        <div><input type="checkbox" onclick="filterProducts()" data-filter-type="price" value="r3"><h5>₹1000 - ₹2500</h5></div>
        <div><input type="checkbox" onclick="filterProducts()" data-filter-type="price" value="r4"><h5>₹2500 - ₹5000</h5></div>
        <div><input type="checkbox" onclick="filterProducts()" data-filter-type="price" value="r5"><h5>₹5000 - ₹10000</h5></div>
        </div>
        <h5 class="h4">Colors</h5>
        <div class="collectfil">
        '.$getflc.'
        </div>
        </div>
        <ul class="product-list">';
        $dff = '</ul>
    </div>
        </div>
      </section>';
} else {
    $x = '';
    $dff ='';
}
    while ($row = $result->fetch_assoc()) {
        if($row['prd_gender'] == 'W'){
         if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
        $x .= '<div class="datalistsec" data-prdg="M" data-prdm="' . $row['price_f'] . '" data-prdn="' . $row['prd_type'] . '" data-prdb="' . $row['brd_name'] . '"><div class="FLXCENTER"><div class="product-card" tabindex="0">

                  <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                  <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
                </div></div></div>';
        }
    }
    $result->free();
    $x.=$dff;
} else {
    $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
}
echo $x;
$conn->close();
}
}