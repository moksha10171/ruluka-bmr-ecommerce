<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
$referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/products/') === 0) {
    $basePath = basename($urlComponents['path']); 
    $idValue = $_POST['postid'];
    $basePath = $idValue;
} else {
    echo $basePath;
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo $basePath; // Database connection error
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_follower = json_decode($row1['live_follower_list'], true);
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                    if ($json_data_loid === null) {
                        $json_data_loid = [];
                    }
                    if ($json_data_follower === null) {
                        $json_data_follower = [];
                    }
                    if ($json_data_fav === null) {
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
$stmt = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE prd_id=?");
        $stmt->bind_param('s',$basePath);
        $stmt->execute();
        $result = $stmt->get_result();
         if ($result->num_rows > 0) {
            $x .= '';
            while ($row = $result->fetch_assoc()) {
                if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'ADD TO FAVORITES';
                $getinfoupdatefav = 'ADD TO CART';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'ADDED TO FAVORITES';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'ADDED TO CART';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="FLXLEFT" style="gap: 5px;">
                                    <a href="/collections/men" class="h5 card-cat-link">Category: Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="FLXLEFT" style="gap: 5px;">
                                    <a href="/collections/women" class="h5 card-cat-link">Category: Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="FLXLEFT" style="gap: 5px;">
                                    <a href="#" class="h5 card-cat-link">Category: <a href="/collections/men" class="h5 card-cat-link">Men</a> / <a href="/collections/women" class="h5 card-cat-link">Women</a>
                                </div>';
                }
                $x .= '<section class="section special end getprdtp">
                    <div class="container ord">
                        <div class="special-product">
                            <ul class="prdo_drid">
                            <li class="product-item">
                            <div class="product-card" tabindex="0" style="width:100% !important;">
                                <figure class="card-banner" style="width:100%;">
                                    <img src="' . $row['url'] . '" width="312" height="350" loading="lazy"
                                        alt="' . $row['name'] . '" class="image-contain" style="style="height: 100%!important;width: 100%;">
                                    ' . $new . '
                                </figure>
                            
                            </div>
                            
                        </li>
                        <div class="card-content" style="padding:0px 15px 0;width:100%;">
                        <div>
                        <div class="FLXLEFT">
                         <h4 class="h4">' . $row['brd_name'] . '</h4>
                         </div>
                         <br>
                         <div class="FLXLEFT">
                        <h2 class="h2"style="text-align: left;">
                                    ' . $row['name'] . '
                                    </h2>
                                    </div>
                                    <br>
                                    <div class="FLXLEFT">
                                
                                    <h4 class="h4 card-price" value="' . $row['price_f'] . '">' . $row['price_f'] . '</h4>
                                    </div>
                                    
                                    <br>
                                    <div class="FLXLEFT" style="gap:10px;">
                                    <div class="newsletter-form"><input type="number" placeholder="Quantity" class="newsletter-input" min="1" max="50" style="min-width:150px;padding-right: 0;"></div>
                                    <div class="newsletter-form">
    <select class="newsletter-input" style="min-width:150px;padding-right: 0;">
        <option value="" disabled selected>Select Size</option>
        <option value="small">Small</option>
        <option value="medium">Medium</option>
        <option value="large">Large</option>
        <option value="xlarge">X-Large</option>
        <option value="xxlarge">XX-Large</option>
    </select>
</div>

                                    </div>
                                    <br>
                                    <div class="FLXLEFT">
                                    
                                    <h5 class="h5" style="align-items: center;display: flex;">Ships from: Ruluka</h5>
                                    
                                    </div>
                                    <br>
                                    <div class="FLXLEFT">
                                    
                                    <h5 class="h5" style="align-items: center;display: flex;gap:10px;">Sold by: <a style="color: black;" href="/seller/'.$row['seller_url'].'" class="h5">'.$row['seller_name'].'</a></h5>
                                    
                                    </div>
                                    <br>
                                    <div class="prdt_active_bo" style="margin:0;"><div class="btn btn-primary">BUY NOW</div></div>
                                    <br>
                                    <div style="display: grid;grid-template-columns: 1fr 1fr;gap: 10px;">
                                    <div class="prdt_active_bo" style="margin:0;"><div class="btn btn-primary ' . $getclassoid . '" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '"> <span id="IC'.$row['prd_id'].'"><div class="FLXCENTER"> <ion-icon name="heart-outline"></ion-icon> '.$getinfoupdateoid.'</span></div></div></div>
                                    <div class="prdt_active_bo" style="margin:0;"><div class="btn btn-primary ' . $getclassfav . '" id="C' . $row['prd_id'] . '" onclick="' . $getloadsecc . '"> <span id="IC'.$row['prd_id'].'"><div class="FLXCENTER"> <ion-icon name="cart-outline"></ion-icon> '.$getinfoupdatefav.'</span></div></div></div>
                                    </div>
                                    <br>
                                    <div class="FLXLEFT">
                                        <h4 class="h4">Product Description</h4>
                                    </div>
                                    <br>
                                    <h5 class="FLXLEFT" style="text-align: left;">
                                    ' . htmlspecialchars($row['about']) . '
                                    </h5>
                                    <br>
                                    <h5 class="prdo_drid" style="gap: 10px;">
                                    <div class="FLXLEFT" style="gap: 5px;">Color: ' . htmlspecialchars($row['color']) . '</div>
                                    <div class="FLXLEFT" style="gap: 5px;">Product Type: ' . htmlspecialchars($row['prd_type']) . '</div>
                                    <div class="FLXLEFT" style="gap: 5px;">Brand: ' . htmlspecialchars($row['brd_name']) . '</div>
                                    <div class="FLXLEFT" style="gap: 5px;">Product ID: ' . htmlspecialchars($row['prd_id']) . '</div>
                                    ' . $gender. '
                                    <div class="FLXLEFT" style="gap: 5px;">Material: ' . htmlspecialchars($row['material__s']) . '</div>
                                    </h5>
                                    <br>
                                    <div class="FLXLEFT">
                                        <h4 class="h4">Offers</h4>
                                    </div>
                                    <br>
                                    <h5 class="FLXLEFT" style="text-align: left;">
                                    No Offers Available
                                    </h5>
                                    <br>
                                    <div class="FLXLEFT">
                                        <h4 class="h4">Ratings</h4>
                                    </div>
                                    <br>
                                    <h5 class="FLXLEFT" style="text-align: left;">
                                    <div style="width: 100%;">
                                    <div>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">5 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$row['star_r_5p'].'%"></span></span><span style="min-width: 20px;">'.$row['star_r_5'].'</span></h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">4 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$row['star_r_4p'].'%"></span></span><span style="min-width: 20px;">'.$row['star_r_4'].'</span></h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">3 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$row['star_r_3p'].'%"></span></span><span style="min-width: 20px;">'.$row['star_r_3'].'</span></h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">2 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$row['star_r_2p'].'%"></span></span><span style="min-width: 20px;">'.$row['star_r_2'].'</span></h5>
                                        <h5 class="h5 navbar-link FLXDJUSTFC"><span class="TXTWRAP FLXLEFT" style="gap:5px;">1 <ion-icon name="star-outline"></ion-icon></span> <span class="star-rating-index"><span class="star-rate-bar" style="width:'.$row['star_r_1p'].'%"></span></span><span style="min-width: 20px;">'.$row['star_r_1'].'</span></h5>
                                    </div>
                                    </h5>
                                </div>
                            </div>
                        </ul>
                    </div>
                </div>
            </section>';
            }
            $result->free();
            $x .= '';
        } else {
            $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Product specified</h2>
                            <h4 class="h4 section-title">Check the url of this is correct try search the product</h4>
                                <div class="prdt_active_bo"><a href="https://blog.bmreducation.com/shop" class="btn btn-primary"> SHOP NOW</a></div>
                        </div>
                        </div>
                    </section>';
        }
        
        $stmt1 = $conn->prepare("SELECT * FROM prouduct_section_1 LIMIT 10");
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        
        if ($result1->num_rows > 0) {
            $y = '<section class="section special">
                    <div class="container">
                        <div class="special-product">
                            <h2 class="h2 section-title">
                                <span class="text">SHOP</span>
                                <span class="line"></span>
                            </h2>
                            <ul class="has-scrollbar">';
            while ($row1 = $result1->fetch_assoc()) {
                if($row1['prd_id'] != $basePath){
                if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row1['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row1['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row1['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row1['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row1['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row1['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
                $y .= '<li class="product-item">
                            <div class="product-card" tabindex="0">
                     <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row1['prd_id'] . '"> <img src="'.$row1['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row1['name'].'" class="image-contain sc1">
                      <img src="'.$row1['img_url_2'].'"  alt="'.$row1['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row1['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row1['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                               <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row1['prd_id'] . '">' . $row1['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row1['prd_id'] . '" value="' . $row1['price_f'] . '">' . $row1['price_f'] . '</a>
                                   </h5>
            </div>
                            </div>
                        </li>';
            }
            }
            $result1->free();
            $y .= '</ul>
                    </div>
                </div>
            </section>';
        } else {
            $y = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results</h4>
                                <div class="prdt_active_bo"><a href="https://blog.bmreducation.com/shop" class="btn btn-primary"> SHOP NOW</a></div>
                        </div>
                        </div>
                    </section>';
        }
        echo $x." ".$y;
        $conn->close();
    }
}