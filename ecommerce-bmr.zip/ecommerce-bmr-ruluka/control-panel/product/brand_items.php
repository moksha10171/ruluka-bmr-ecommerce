<?php
#Code by bmr developers - Limited use of tech - bmreducation.com
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
$referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/brands/') === 0) {
    $basePath = basename($urlComponents['path']);
    $basePath = preg_replace('/\\.[^.\\s]{3,4}$/', '', $basePath);
} else {
    echo 400;
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                     if ($json_data_loid === null) {
                        $json_data_loid = [];
                    }
                    if ($json_data_fav === null) {
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'STORINSNETW()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
        
         $stmtc = $conn->prepare("SELECT * FROM brands__list_f_f WHERE base_n_as_by_n=?");
        $stmtc->bind_param('s', $basePath);
        $stmtc->execute();
        $resultc = $stmtc->get_result();
        if ($resultc->num_rows > 0) {
            $rowc = $resultc->fetch_assoc();
            $name = htmlspecialchars($rowc['name__']);
            $image_url = htmlspecialchars($rowc['img_url']);
            $url = htmlspecialchars($rowc['base_n_as_by_n']);
        }else {
            echo 400;
            $conn->close();
            exit();
        }
   
 $stmt1 = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE brd_id =?");
        $stmt1->bind_param('s', $rowc['brd_id']);
        $stmt1->execute();
    $result1 = $stmt1->get_result();
    if ($result1->num_rows > 0) {
    $y = '<section class="section end product" id="products">
        <div class="container">
          <div style="padding-bottom: 20px;">
                 <div class="FLXCENTER" style="margin: 20px;">
        <img src="'.$image_url.'" width="100" height="100" style="border-radius: 50%;height: 150px;width: 150px;border: var(--border-black);padding: 2px;object-fit: contain;
        object-position: center;" loading="lazy" alt="'.$name.'" class="creator-banner image-contain">
        </div>
        <br>
           <h2 class="h2 section-title">
              <span class="text">'.$name.'</span>

              <span class="line"></span>
            </h2>
        <ul class="product-list">';
    while ($row = $result1->fetch_assoc()) {
 if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(\''. $row['prd_id'] . '\')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                    $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
        $y .= '<div class="FLXCENTER"><div class="product-card" tabindex="0">

                 <figure class="card-banner">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                            <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
        </div></div>';
    }
    $result1->free();
    $y.='</ul>
    </div>
      </section>';
} else {
    $y ='<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
}
        echo $y;
        $conn->close();
    }
}