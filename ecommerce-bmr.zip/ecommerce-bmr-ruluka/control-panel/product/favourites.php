<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        echo 400;
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_loid = json_decode($row1['live_order_id_favorites'], true);
                    $json_data_fav = json_decode($row1['live_order_id_cart'], true);
                    if ($json_data_loid === null) {
                        $json_data_loid = [];
                    }
                    if ($json_data_fav === null) {
                        $json_data_fav = [];
                    }
                    $getlc = 1;
                    $favc = $row1['live_favorites'];
                }
            }
        }

        if ($getlc == 1 && $favc>0) {
            $x = '<section class="section product">
                    <div class="container">
                        <h2 class="h2 section-title">FAVOURITES</h2>
                        <ul class="filter-list">
                            <ul class="product-list">';
            $cnt = 0;
            foreach ($json_data_loid as $data) {
                $stmt = $conn->prepare("SELECT * FROM prouduct_section_1 WHERE prd_id = ?");
                $stmt->bind_param("s", $data);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        if ($getlc == 1) {
                    $getloadsec = 'STORINSNETW(' . $row['prd_id'] . ')';
                }
                $getinfoupdateoid = 'Add to favorites';
                $getinfoupdatefav = 'Add to Cart';
                $getloadsecf = $getloadsec;
                $getloadsecc = $getloadsec;
                $getclassoid = '';
                $getclassfav = '';
                if($account_access == 1){
                $getloadsecf = 'F'.$getloadsec;
                $getloadsecc = 'C'.$getloadsec;
                $value_to_check_loid = $row['prd_id'];
                if (in_array($value_to_check_loid, $json_data_loid)) {
                    $getclassoid = 'active';
                     $getinfoupdateoid = 'Added to favorites';
                }
                if (in_array($value_to_check_loid, $json_data_fav)) {
                    $getclassfav = 'active';
                    $getinfoupdatefav = 'Added to Cart';
                }
                }
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
                        $cnt++;
                        $row = array_map('htmlspecialchars', $row);
                        $x .= '<div class="product-card remove-effect" tabindex="0" id="RMVIC' . $row['prd_id'] . '">
                                     <figure class="card-banner" style="height:auto;">
                   <a class="imghvrlink" href="/products/?id=' . $row['prd_id'] . '"> <img src="'.$row['url'].'" width="312" height="350" loading="lazy"
                      alt="'.$row['name'].'" class="image-contain sc1">
                      <img src="'.$row['img_url_2'].'"  alt="'.$row['name'].'" class="image-contain sc2">
                      </a>

                    ' . $new . '<div class="fav-card-item">
                                            <button class="card-action-btn ' . $getclassoid . '" aria-labelledby="card-label-2" id="F' . $row['prd_id'] . '" onclick="' . $getloadsecf . '">
                                                <ion-icon name="heart-outline"></ion-icon>
                                            </button>
                                            <div class="card-action-tooltip" id="IF'.$row['prd_id'].'">'.$getinfoupdateoid.'</div>
                                        </div>
                  </figure>
                                    <div class="card-content">
                   <h5 class="h5 FLXLEFT card-title">
                                        <a href="/products/?id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                    </h5>
                                    <h5 class="h5 FLXLEFT card-title">
                                    <a href="/products/?id=' . $row['prd_id'] . '" value="' . $row['price_f'] . '">' . $row['price_f'] . '</a>
                                   </h5>
                                </div>
                                </div>';
                    }
                }
            }
            $result->free();
            $stmt->close();
            $conn->close();
            $x .= '</ul></div></section>';
            echo $x;
        } else {
            $fgg = '<section class="section product">
                        <div class="container" id="MAINSECHEI">
                            <h2 class="h2 section-title" style="display:flex;align-tems:center;justify-content:center;">
                                <ion-icon name="heart-outline" class="h1" style="border-radius: 50%;border: var(--border-black);padding: 5px;" aria-hidden="true"></ion-icon>
                            </h2>
                            <h2 class="h2 section-title">FAVOURITES</h2>
                            <h4 class="h4 section-title">Items added to your favourites will be saved here.
                                We’ll send you a reminder when a campaign in your favourites is about to end.</h4>
                                <div class="prdt_active_bo"><a href="https://www.ruluka.com/shop" class="btn btn-primary"> SHOP NOW</a></div>
                        </div>
                    </section>';
            if ($cnt == 0) {
                echo $fgg;
            }
        }
    }
} else {
    echo "400";
}
?>