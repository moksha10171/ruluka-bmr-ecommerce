<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
function convertTime($timestamp)
{
    $now = time();
    $timeDiff = $now - $timestamp;

    if ($timeDiff < 60) {
        $seconds = $timeDiff;
        return $seconds . " " . ($seconds == 1 ? "second" : "seconds") . " ago";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " " . ($minutes == 1 ? "minute" : "minutes") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " " . ($hours == 1 ? "hour" : "hours") . " ago";
    } elseif ($timeDiff < 2592000) {
        $days = floor($timeDiff / 86400);
        return $days . " " . ($days == 1 ? "day" : "days") . " ago";
    } elseif ($timeDiff < 31536000) {
        $months = floor($timeDiff / 2592000);
        return $months . " " . ($months == 1 ? "month" : "months") . " ago";
    } else {
        $years = floor($timeDiff / 31536000);
        return $years . " " . ($years == 1 ? "year" : "years") . " ago";
    }
}
$referrerUrl = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$urlComponents = parse_url($referrerUrl);
if (isset($urlComponents['path']) && strpos($urlComponents['path'], '/project/influencers/') === 0) {
    $basePath = basename($urlComponents['path']);
    $basePath = preg_replace('/\\.[^.\\s]{3,4}$/', '', $basePath);
} else {
    echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");
    if (!$conn) {
        $x = '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
    } else {
        if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
            $getlc = 0;
            $account_access = 0;
            $stmt = $conn->prepare("SELECT * FROM live_session_access WHERE sess__id__bycpt = ?");
            $stmt->bind_param("s", $_SESSION['sessss_id_sec_newt_k_sa_sa']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt1 = $conn->prepare("SELECT * FROM users_da_f_s WHERE mail_id_slk = ?");
                $stmt1->bind_param("s", $row['eml_usr_f_']);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    $account_access = 1;
                    $json_data_follower = json_decode($row1['live_follower_list'], true);
                    $json_data_like = json_decode($row1['live_like_list'], true);
                    $json_data_bookmark = json_decode($row1['live_bookmark_list'], true);
                    if ($json_data_follower === null) {
                        $json_data_follower = [];
                    }
                    if ($json_data_like === null) {
                        $json_data_like = [];
                    }
                    if ($json_data_bookmark === null) {
                        $json_data_bookmark = [];
                    }
                    $getlc = 1;
                    $getloadsec = 'INFLUENCLISTRA()';
                } else {
                    $getloadsec = 'BLOGINSNETW()';
                }
            } else {
                $getloadsec = 'BLOGINSNETW()';
            }
        } else {
            $getloadsec = 'BLOGINSNETW()';
        }
        
        $stmtc = $conn->prepare("SELECT * FROM creator_list WHERE base_n_as_by_n=?");
        $stmtc->bind_param('s', $basePath);
        $stmtc->execute();
        $resultc = $stmtc->get_result();
        if ($resultc->num_rows > 0) {
            $rowc = $resultc->fetch_assoc();
            $name = htmlspecialchars($rowc['name']);
            $image_url = htmlspecialchars($rowc['imag_url']);
            $url = htmlspecialchars($rowc['url']);
        }else {
            echo '<section class="section product">
                        <div class="container" style="justify-content: center !important;" id="MAINSECHEI">
                        <div>
                            <h2 class="h2 section-title">Can\'t find the Produts</h2>
                            <h4 class="h4 section-title">Refresh this page to see any results in this section</h4>
                        </div>
                        </div>
                    </section>';
            $conn->close();
            exit();
        }
        if ($getlc == 1) {
        if (in_array($rowc['crt_id'], $json_data_follower)) {
            $addfggg = 'onclick="FOLLINFLUENCLISTRA(\''. $rowc['crt_id'] . '\')" ';
                    $mbflclsac = 'active';
                    $mbfl = 'Following';
        } else {
            $mbfl = 'Follow';
            $addfggg = 'onclick="FOLLINFLUENCLISTRA(\''. $rowc['crt_id'] . '\')" ';
        }
         }else {
            $mbfl = 'Follow';
            $addfggg = 'onclick="BLOGINSNETW()"';
        }
        
        $x =
            '<div class="FLXCENTER" style="border-bottom: var(--border-black);">
        <div>
                            <img src="' .
            $image_url .
            '" width="100" height="100" style="border-radius: 50%;margin-block: 20px;padding: 2px;border: var(--border-black);max-width: 300px;min-height: 150px;min-width: 150px;max-height: 300px;" loading="lazy" alt="' .
            $name .
            '" class="creator-banner image-contain">
                        <div class="FLXCENTER">
                        <div class="h6" style="padding:10px;" id="follwr_cc">' .
            $rowc['tot_al_followers_s__s'] .
            ' Followers</div>
                        </div>
                             <div class="FLXCENTER">
                        <div class="h2" style="padding:10px;">' .
            $name .
            '</div>
                        </div>
                        <div class="FLXCENTER">
            <ul class="filter-list">

            <li>
              <button class="filter-btn" onclick="productsfetch()" id="infprodsec">Shop</button>
            </li>

            <li>
              <button class="filter-btn active" onclick="postsfetch()"  id="infpostsec">Posts</button>
            </li>
             <li>
              <button '.$addfggg.' class="filter-btn FLOW'. $rowc['crt_id'] . ' '.$mbflclsac.'">'.$mbfl.'</button>
            </li>

          </ul>
          </div>
                        </div>
                        </div>
        <main>
        <div class="insta-con-tai-ner">
		<div class="insta-col--9">';

        $stmt1 = $conn->prepare("SELECT * FROM post_list LIMIT 10");
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        if ($result1) {
            while ($row1 = $result1->fetch_assoc()) {
                if ($getlc == 1) {
                    $getloadsec = 'INFLUENCLISTRA(\''. $row1['post_id'] . '\')';
                    $getloadsecf = 'INFLUENCLISTRA(\''. $row1['crt_id'] . '\')';
                }
                $getloadsecfoll = $getloadsec;
                $getloadseclike = $getloadsec;
                $getloadsecbook = $getloadsec;
                $getclassfollower = '';
                $getclassfollowertext = 'Follow';
                $getclasslike = '';
                $getclassbookmark = '';
                if($account_access == 1){
                $getloadsecfoll = 'FOLL'.$getloadsecf;
                $getloadseclike = 'LIKE'.$getloadsec;
                $getloadsecbook = 'BOOK'.$getloadsec;
                $value_to_check_follower = $row1['crt_id'];
                $value_to_check_like = $row1['post_id'];
                $value_to_check_bookmark = $row1['post_id'];
                if (in_array($value_to_check_follower, $json_data_follower)) {
                    $getclassfollower = 'active';
                    $getclassfollowertext = 'Following';
                }
                if (in_array($value_to_check_like, $json_data_like)) {
                    $getclasslike = 'active';
                }
                if (in_array($value_to_check_bookmark, $json_data_bookmark)) {
                    $getclassbookmark = 'active';
                }
                }
                
                $new = ($row['prd_listing'] == 'N') ? '<div class="card-badge">New</div>' : '';
                $gender = '';
                if ($row['prd_gender'] == 'M') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a>
                                </div>';
                } else if ($row['prd_gender'] == 'W') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                } else if ($row['prd_gender'] == 'B') {
                    $gender = '<div class="card-cat">
                                    <a href="#" class="card-cat-link">Men</a> /
                                    <a href="#" class="card-cat-link">Women</a>
                                </div>';
                }
                $x .=
                    '	<div class="card">
					<div class="insta-t-o-p">
						<div class="insta-us-er-De-tails">
							<div class="insta-pro-filepic">
								<div class="insta-pro-file_img">
									<div class="insta-im-age">
										<img src="' .
                    $row1['image_url'] .
                    '"
											alt="' .
                    $row1['creator'] .
                    '">
									</div>
								</div>
							</div>
							<h3>' .
                    $row1['creator'] .
                    '
								<br>
								<span>' .
                    convertTime($row1['create_time']) .
                    '</span>
						</h3>
				
						</div>
						<div>
							<span class="dot">
								<i class="fas fa-ellipsis-h"></i>
							</span>
						</div>
					</div>
					<div class="imgBx">
						<img src="' .
                    $row1['post_image'] .
                    '"
							alt="' .
                    $row1['creator'] .
                    '" class="insta-co-ver">
					</div>
					<div class="bottom">
						<div class="insta-ac-ti-onBtns">
							<div class="left FLXLEFT">
								<div onclick="'.$getloadseclike.'"> <ion-icon name="heart-outline" class="h2 heart '.$getclasslike.'" id="LIKE'.$row1['post_id'].'" aria-hidden="true"></ion-icon></div>
								 <div  onclick="shareLink(\''.$row1['post_url'].'\',\''.htmlspecialchars($row1['about']).'\',\''.$row1['post_url'].'\')">
								 <ion-icon name="share-social-outline" class="h2" aria-hidden="true"></ion-icon></div>
							</div>
							<div class="right" onclick="'.$getloadsecbook.'">
								 <ion-icon name="bookmark-outline" class="h2 book '.$getclassbookmark.'" id="BOOK'.$row1['post_id'].'" aria-hidden="true"></ion-icon>
							</div>
						</div>
						<div>
							<p class="likes" id="CLIKE'.$row1['post_id'].'">' .
                    $row1['likes'] .
                    ' likes</p>
						</div>
						<a>
							<p class="insta-mes-sage">
							<b>' .
                    $row1['about'] .
                    '</b>
							</p>
						</a>
					</div>
				</div>';
            }
            $result1->free();
        }
        $x .= '</div></main>';
        echo $x;
        $conn->close();
    }
}