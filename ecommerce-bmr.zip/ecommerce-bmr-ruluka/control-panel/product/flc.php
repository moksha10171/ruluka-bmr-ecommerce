<?php 
echo '
<div style="padding-block: 40px;">
 <div class="cta-card SDFDRUADS1">
<div class="FLXCENTER" style="height: 100%;">
<div>
<h1 class="h1">UPTO 20% OFF</h1>
<p style="color:black;">plus free shipping over ₹1999</p>
<br>
<br>
<div class="linksnd"><a class="btnd blc">Shop Now <i class="fa fa-arrow-right"></i></a></div>
</div>
</div>
</div>
</div>
<div style="padding-block: 40px;">
    <div class="cta-card SDFDRUADS1" style="background-image: url(\'/images/01g8073z8qf3ymd22c5f05wvrj.jpg\'); min-height: 400px;">
       <div style="height:100%;">
        <h2 class="h2 section-title" style="height: 100%; display: flex; align-items: center; justify-content: center; background: #3c3c3c70;">
        <div><div style="color: var(--smoky-white); padding-block: 15px; border-bottom: 2px solid;">Find your Fashion</div>
        <div class="FLXCENTER">
        <a href="/brands/" class="alink splh">OUR BRANDS <i class="fa fa-arrow-right"></i></a>
    </div>
        </div>
        </h2>
       </div>
    </div>
</div>';