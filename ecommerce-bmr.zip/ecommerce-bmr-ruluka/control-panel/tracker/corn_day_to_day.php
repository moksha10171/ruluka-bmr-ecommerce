<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
#corn job database
$servername = "localhost";
$username = "u291518478_project1";
$password = "Moksha@10171";
$dbname = "u291518478_project1";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function updateDailyAnalytics($conn) {
    $currentDate = date("Y-m-d");
    $deleteQuery = "DELETE FROM daily_analytics_updates WHERE date = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param("s", $currentDate);
    $deleteStmt->execute();
    $deleteStmt->close();
    $insertQuery = "INSERT INTO daily_analytics_updates (page_url, date, pageviews, unique_visitors, sessions, conversion_rate, goal_completions, average_order_value)
                    SELECT page_url,
                           ? AS date,
                           SUM(pageviews) AS pageviews,
                           SUM(unique_visitors) AS unique_visitors,
                           SUM(sessions) AS sessions,
                           AVG(conversion_rate) AS conversion_rate,
                           SUM(goal_completions) AS goal_completions,
                           AVG(average_order_value) AS average_order_value
                    FROM (
                        SELECT page_url, COUNT(*) AS pageviews, COUNT(DISTINCT user_ip) AS unique_visitors, COUNT(DISTINCT session_id) AS sessions
                        FROM user_engagement_metrics
                        WHERE DATE(date_time) = ?
                        GROUP BY page_url
                    ) AS engagement
                    LEFT JOIN (
                        SELECT page_url, AVG(conversion_rate) AS conversion_rate, SUM(goal_completions) AS goal_completions, AVG(average_order_value) AS average_order_value
                        FROM conversion_metrics
                        WHERE DATE(date_time) = ?
                        GROUP BY page_url
                    ) AS conversion ON engagement.page_url = conversion.page_url
                    GROUP BY page_url";
    
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bind_param("sss", $currentDate, $currentDate, $currentDate);
    $insertStmt->execute();
    $insertStmt->close();
}

updateDailyAnalytics($conn);
$conn->close();
?>