<?php
#Code by bmr developers - Limited use of tech - bmreducation.com 
session_start();
if (isset($_SESSION['sessss_id_sec_newt_k_sa_sa']) && !empty($_SESSION['sessss_id_sec_newt_k_sa_sa'])) {
    $conn = mysqli_connect("localhost", "u494233728_ruluka_db_bmr", "Ruluka_bmr_12345", "u494233728_ruluka_db_bmr");

    if ($conn->connect_error) {
        echo "invalid";
        exit();
    }

    $sess_id = $_SESSION['sessss_id_sec_newt_k_sa_sa'];

    $stmt = $conn->prepare("SELECT eml_usr_f_ FROM live_session_access WHERE sess__id__bycpt = ?");
    $stmt->bind_param("s", $sess_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_email = $row['eml_usr_f_'];

        $stmt1 = $conn->prepare("SELECT live_like_list, live_like_count FROM users_da_f_s WHERE mail_id_slk = ?");
        $stmt1->bind_param("s", $user_email);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows > 0) {
            $rowbmr = $result1->fetch_assoc();
            $json_data = json_decode($rowbmr['live_like_list'], true);

            if ($json_data === null) {
                $json_data = [];
            }
            $cvl =0;
            $favorites_count = count($json_data);

            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['value'])) {
                $action = $_POST['action'];
                $value = $_POST['value'];

                if ($action == 'yes') {
                    if (!in_array($value, $json_data)) {
                        $stmt1c = $conn->prepare("SELECT * FROM post_list WHERE post_id = ?");
                        $stmt1c->bind_param("s", $value);
                        $stmt1c->execute();
                        $result1c = $stmt1c->get_result();
                        if ($result1c->num_rows > 0) {
                            $rowbmrv = $result1c->fetch_assoc();
                            $cvl = $rowbmrv['likes']+1;
                            $stmt2c = $conn->prepare("UPDATE post_list SET likes=? WHERE post_id=?");
                            $stmt2c->bind_param("is", $cvl, $value);
                            $stmt2c->execute();
                            if ($stmt2c->affected_rows > 0) {
                                $json_data[] = $value;
                                $favorites_count++;
                            }
                        }
                    }
                } elseif ($action == 'no') {
                    $index = array_search($value, $json_data);
                    if ($index !== false) {
                        $stmt1c = $conn->prepare("SELECT * FROM post_list WHERE post_id = ?");
                        $stmt1c->bind_param("s", $value);
                        $stmt1c->execute();
                        $result1c = $stmt1c->get_result();
                        if ($result1c->num_rows > 0) {
                            $rowbmrv = $result1c->fetch_assoc();
                            $cvl = $rowbmrv['likes']-1;
                            $stmt2c = $conn->prepare("UPDATE post_list SET likes=? WHERE post_id=?");
                            $stmt2c->bind_param("is", $cvl, $value);
                            $stmt2c->execute();
                            if ($stmt2c->affected_rows > 0) {
                                unset($json_data[$index]);
                                $favorites_count--;
                                $json_data = array_values($json_data);
                            }
                        }
                    }
                }

                $json_encoded = json_encode($json_data);
                $stmt2 = $conn->prepare("UPDATE users_da_f_s SET live_like_list=?, live_like_count=? WHERE mail_id_slk=?");
                $stmt2->bind_param("sis", $json_encoded, $favorites_count, $user_email);
                $stmt2->execute();

                if ($stmt2->affected_rows > 0) {
                    echo $cvl;
                }
            }
        }
    }
    $stmt->close();
    $stmt1->close();
    $stmt2->close();
    $conn->close();
}
?>