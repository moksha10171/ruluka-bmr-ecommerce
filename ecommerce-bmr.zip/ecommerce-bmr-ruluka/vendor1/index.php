<?php
header("Location: https://www.bmreducation.com/");
?>
<html>
   <body> 
   <div style="display:flex;align-items:center;justify-content:center;text-align:center;height:100%;">
       <h1>403</h1><br>
       <h1>Access is forbidden</h1>
   </div>
   </body>
</html>