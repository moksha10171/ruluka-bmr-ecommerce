<?php
function inancap($f) {
    ob_start();
    include $f;
    return ob_get_clean();
}
$header = inancap('control-panel/layout/header.php');
$footer = inancap('control-panel/layout/footer.php');
$meta = inancap('control-panel/layout/meta.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $meta;?>
    </head>
    <body id="top">
        <?php echo $header;?>

        <main>
            <article id="mainsectionarticle">
                <div id="1SDFG0009IOL">
                    <div class="section product">
                        <div class="container">
                            <div class="product-list">
                                <div class="product-card"><div class="loader card-banner"></div></div>
                                <div class="product-card"><div class="loader card-banner"></div></div>
                                <div class="product-card"><div class="loader card-banner"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </main>
        <?php echo $footer;?>
         <script >
         $(window).resize(function () {
    var browserWidth;
    isMobileDevice() ? ((browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth), browserWidth > 550 ? brwsrdimns() : null) : brwsrdimns();
});

  $('input[type="checkbox"]').on('change', function() {
                filterProducts();
            });

            function filterProducts() {
                let selectedFilters = {
                    categories: [],
                    brands: [],
                    prices: [],
                    genders: []
                };

                $('input[type="checkbox"]:checked').each(function() {
                    let filterType = $(this).data('filter-type');
                    let filterValue = $(this).val();

                    if (filterType === 'category') {
                        selectedFilters.categories.push(filterValue);
                    } else if (filterType === 'brand') {
                        selectedFilters.brands.push(filterValue);
                    } else if (filterType === 'price') {
                        selectedFilters.prices.push(filterValue);
                    } else if (filterType === 'color') {
                        selectedFilters.genders.push(filterValue);
                    }
                });

                $('.datalistsec').each(function() {
                    let category = $(this).data('prdn');
                    let brand = $(this).data('prdb');
                    let price = parseInt($(this).data('prdm').replace('₹', ''));
                    let gender = $(this).data('prdg');

                    let matchCategory = selectedFilters.categories.length === 0 || selectedFilters.categories.includes(category);
                    let matchBrand = selectedFilters.brands.length === 0 || selectedFilters.brands.includes(brand);
                    let matchGender = selectedFilters.genders.length === 0 || selectedFilters.genders.includes(gender);
                    let matchPrice = selectedFilters.prices.length === 0 || 
                                    (selectedFilters.prices.includes('r1') && price >= 0 && price <= 500) ||
                                    (selectedFilters.prices.includes('r2') && price > 500 && price <= 1000) ||
                                    (selectedFilters.prices.includes('r3') && price > 1000 && price <= 2500) ||
                                    (selectedFilters.prices.includes('r4') && price > 2500 && price <= 5000) ||
                                    (selectedFilters.prices.includes('r5') && price > 5000 && price <= 10000);

                    if (matchCategory && matchBrand && matchGender && matchPrice) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }
            filterProducts();
    </script>
    </body>
</html>